# **App Name**: Firestorm Arena

## Core Features:

- Tournament Listing: Display upcoming and ongoing Free Fire tournaments with details like date, time, entry fee, and prize pool.
- Tournament Registration: Allow players to register for tournaments by providing their Free Fire ID and team details.
- AI-Powered Team Formation: Suggest potential teammates to a user based on their skill level, play style, and availability, using an AI tool.
- Real-time Results: Update tournament results in real-time, including scores, standings, and match schedules.
- News and Announcements: Publish news, announcements, and updates related to Free Fire and the tournaments.
- Contact Form: Provide a form for users to submit inquiries or requests to the tournament organizers.

## Style Guidelines:

- Primary color: Deep, saturated red (#C41E3A), evoking the intensity and heat of competition.
- Background color: Very dark grey (#1A1A1A), providing a high-contrast backdrop to make key content pop.
- Accent color: Electric purple (#BE29EC), for highlights, calls to action, and interactive elements.
- Font: 'Space Grotesk', sans-serif, for a modern and technical feel, suitable for headlines and body text.
- Use sharp, minimalist icons to represent tournament features and game elements.
- A dynamic and responsive layout optimized for both desktop and mobile devices.
- Subtle animations and transitions to enhance user experience, such as loading screens and hover effects on interactive elements.