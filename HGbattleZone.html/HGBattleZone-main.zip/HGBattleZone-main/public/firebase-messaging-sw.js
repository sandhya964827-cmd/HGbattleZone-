
// This file needs to be in the public directory.

// Scripts for firebase and firebase messaging
importScripts("https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/10.12.2/firebase-messaging-compat.js");

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBCBxvCe1x8bO6TwDSfedlM4VCh9J8EUd4",
  authDomain: "hgbattlezone-admins-1.firebaseapp.com",
  projectId: "hgbattlezone-admins-1",
  storageBucket: "hgbattlezone-admins-1.appspot.com",
  messagingSenderId: "63823764959",
  appId: "1:63823764959:web:2ada38ab91e5e09438b86a",
  measurementId: "G-ZZ3LV1YR6S"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Retrieve an instance of Firebase Messaging so that it can handle background
// messages.
const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  console.log(
    "[firebase-messaging-sw.js] Received background message ",
    payload
  );
  // Customize notification here
  const notificationTitle = payload.notification.title;
  const notificationOptions = {
    body: payload.notification.body,
    icon: "/icon-192x192.png",
  };

  self.registration.showNotification(notificationTitle, notificationOptions);
});
