

"use client";

import { useState, useEffect } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm, useFieldArray } from "react-hook-form";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, PlusCircle, Trash2, Award, Sparkles, Copy, RadioTower, Edit, XCircle } from "lucide-react";
import { onTournamentsUpdate, addOrUpdateResult, onResultsUpdate, realtimeDB, deleteResult as deleteResultFromDB } from "@/lib/firebase";
import { ref, onValue } from "firebase/database";
import type { Tournament, TournamentResult, LiveMatch, TeamResult } from "@/lib/types";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  SelectGroup,
  SelectLabel,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { generateHighlights } from "@/ai/generate-highlights-flow";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Textarea } from "@/components/ui/textarea";

const playerSchema = z.object({
  name: z.string(),
  kills: z.coerce.number().default(0),
  isAlive: z.boolean().default(true),
});

const standingSchema = z.object({
  rank: z.coerce.number().min(1, "Rank is required."),
  teamName: z.string().min(1, "Team name is required."),
  prize: z.string().optional(),
  players: z.array(playerSchema).optional(),
});

const formSchema = z.object({
  tournamentId: z.string().min(1, "Please select a tournament."),
  standings: z.array(standingSchema).min(1, "At least one team standing is required."),
});

type FormData = z.infer<typeof formSchema>;

export default function ManageResultsPage() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [allResults, setAllResults] = useState<TournamentResult[]>([]);
  const [liveMatches, setLiveMatches] = useState<LiveMatch[]>([]);
  const [generatedHighlights, setGeneratedHighlights] = useState('');
  const [editingResultId, setEditingResultId] = useState<string | null>(null);


  useEffect(() => {
    const unsubTournaments = onTournamentsUpdate(setTournaments);
    const unsubResults = onResultsUpdate(setAllResults);
    
    const liveMatchesRef = ref(realtimeDB, 'liveMatches');
    const unsubLiveMatches = onValue(liveMatchesRef, (snapshot) => {
      const data = snapshot.val();
      const loadedMatches = data ? Object.keys(data).map(key => ({ id: key, ...data[key] })) : [];
      setLiveMatches(loadedMatches);
    });

    return () => {
        unsubTournaments();
        unsubResults();
        unsubLiveMatches();
    };
  }, []);

  const completedTournaments = tournaments.filter(t => t.status === 'Completed');
  
  const liveTournamentsForSelect = liveMatches.map(lm => {
    const tournamentDetails = tournaments.find(t => t.id === lm.tournamentId);
    return {
        id: lm.tournamentId,
        name: tournamentDetails?.name || lm.title,
    };
  }).filter((t): t is { id: string; name: string } => !!t.id && !!t.name);


  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      tournamentId: "",
      standings: [{ rank: 1, teamName: "", prize: "" }],
    },
  });

  const { fields, append, remove, replace } = useFieldArray({
    control: form.control,
    name: "standings"
  });
  
  const resetForm = () => {
    form.reset({
      tournamentId: "",
      standings: [{ rank: 1, teamName: "", prize: "" }],
    });
    setEditingResultId(null);
    setGeneratedHighlights('');
  }

  async function onSubmit(values: FormData) {
    setIsLoading(true);
    try {
      const selectedTournament = tournaments.find(t => t.id === values.tournamentId);
      if (!selectedTournament) {
        throw new Error("Selected tournament not found.");
      }
      
      const resultData = {
          tournamentId: values.tournamentId,
          tournamentName: selectedTournament.name,
          date: selectedTournament.date,
          standings: values.standings.sort((a, b) => a.rank - b.rank)
      };
      
      await addOrUpdateResult(resultData as any, editingResultId);
      
      toast({
        title: editingResultId ? "Result Updated!" : "Result Added!",
        description: `Leaderboard for "${selectedTournament.name}" has been saved.`,
      });
      resetForm();

    } catch (error) {
       console.error("Error saving results:", error);
       toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to save the results.",
      });
    } finally {
        setIsLoading(false);
    }
  }
  
  const handleEdit = (result: TournamentResult) => {
    setEditingResultId(result.id);
    form.reset({
        tournamentId: result.tournamentId,
        standings: result.standings,
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
    toast({
        title: "Editing Result",
        description: `Now editing the leaderboard for "${result.tournamentName}".`
    });
  }
  
  const handleDelete = async (resultId: string) => {
    try {
        await deleteResultFromDB(resultId);
        toast({
            variant: "destructive",
            title: "Result Deleted",
            description: "The result has been successfully removed.",
        });
    } catch(err) {
        console.error("Error deleting result: ", err);
        toast({
            variant: "destructive",
            title: "Deletion Failed",
            description: "Could not delete the result.",
        });
    }
  }


  const handleGenerateHighlights = async (result: TournamentResult) => {
    setIsGenerating(true);
    setGeneratedHighlights('');
    try {
        const standingsForAI = result.standings.map(team => ({
            rank: team.rank,
            teamName: team.teamName,
            kills: (team.players || []).reduce((acc, p) => acc + (p.kills || 0), 0),
            prize: team.prize
        }));

        const aiResult = await generateHighlights({
            tournamentName: result.tournamentName,
            standings: standingsForAI,
        });
        setGeneratedHighlights(aiResult.highlights);
    } catch(e) {
        console.error("Error generating highlights:", e);
        toast({ variant: "destructive", title: "AI Error", description: "Could not generate highlights."});
    } finally {
        setIsGenerating(false);
    }
  };
  
  const handleCopyHighlights = () => {
    navigator.clipboard.writeText(generatedHighlights).then(() => {
        toast({ title: "Copied!", description: "Highlights copied to clipboard." });
    });
  }

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-headline font-bold">Manage Tournament Results</h1>
        <p className="text-muted-foreground mt-3 max-w-2xl mx-auto">
          Add, edit, or delete final standings for all tournaments.
        </p>
      </div>

      <div className="max-w-4xl mx-auto space-y-12">
        <Card>
            <CardHeader>
                <CardTitle>{editingResultId ? "Edit Leaderboard" : "Add New Leaderboard"}</CardTitle>
                <CardDescription>Select a live or completed tournament and enter the final standings.</CardDescription>
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <FormField
                            control={form.control}
                            name="tournamentId"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Tournament</FormLabel>
                                <Select onValueChange={field.onChange} value={field.value} disabled={isLoading || editingResultId !== null}>
                                    <FormControl>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select a tournament" />
                                    </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                        {liveTournamentsForSelect.length > 0 && (
                                            <SelectGroup>
                                                <SelectLabel>Live Matches</SelectLabel>
                                                {liveTournamentsForSelect.map(t => (
                                                    <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                                                ))}
                                            </SelectGroup>
                                        )}
                                        {completedTournaments.length > 0 && (
                                            <SelectGroup>
                                                <SelectLabel>Completed Matches</SelectLabel>
                                                {completedTournaments.map(t => (
                                                    <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                                                ))}
                                            </SelectGroup>
                                        )}
                                        {liveTournamentsForSelect.length === 0 && completedTournaments.length === 0 && (
                                            <div className="p-4 text-sm text-muted-foreground">No tournaments found.</div>
                                        )}
                                    </SelectContent>
                                </Select>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                        
                        <Separator/>

                        <div>
                            <div className="flex justify-between items-center mb-4">
                                <h3 className="text-lg font-medium">Standings</h3>
                                <Button type="button" size="sm" variant="outline" onClick={()={() => append({ rank: fields.length + 1, teamName: "", prize: "" })}>
                                    <PlusCircle className="mr-2 h-4 w-4"/> Add Team
                                </Button>
                            </div>
                            <div className="space-y-4">
                            {fields.map((field, index) => (
                                <div key={field.id} className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 border rounded-lg relative">
                                    <FormField control={form.control} name={`standings.${index}.rank`} render={({ field }) => ( <FormItem><FormLabel>Rank</FormLabel><FormControl><Input type="number" placeholder="#" {...field} /></FormControl></FormItem>)} />
                                    <FormField control={form.control} name={`standings.${index}.teamName`} render={({ field }) => ( <FormItem><FormLabel>Team Name</FormLabel><FormControl><Input placeholder="e.g., Team Inferno" {...field} /></FormControl></FormItem>)} />
                                    <FormField control={form.control} name={`standings.${index}.prize`} render={({ field }) => ( <FormItem><FormLabel>Prize</FormLabel><FormControl><Input placeholder="$1,000" {...field} /></FormControl></FormItem>)} />
                                    {fields.length > 1 && (
                                    <Button type="button" variant="ghost" size="icon" className="absolute top-1 right-1 text-destructive hover:text-destructive" onClick={() => remove(index)}>
                                        <Trash2 className="h-4 w-4" />
                                    </Button>
                                    )}
                                </div>
                            ))}
                            <FormMessage>{form.formState.errors.standings?.message}</FormMessage>
                            </div>
                        </div>

                        <div className="flex flex-col sm:flex-row gap-2">
                           <Button type="submit" className="w-full" disabled={isLoading}>
                             {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Award className="mr-2 h-4 w-4"/>}
                             {isLoading ? (editingResultId ? "Updating..." : "Saving...") : (editingResultId ? "Update Result" : "Save Result")}
                           </Button>
                           {editingResultId && (
                             <Button type="button" variant="outline" className="w-full" onClick={resetForm}>
                               <XCircle className="mr-2 h-4 w-4" />
                               Cancel Edit
                             </Button>
                           )}
                        </div>
                    </form>
                </Form>
            </CardContent>
        </Card>

        <Card>
            <CardHeader>
                <CardTitle>Result History</CardTitle>
                <CardDescription>Edit or delete past results, or generate AI highlights.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                {allResults.length === 0 && <p className="text-center text-muted-foreground p-4">No past results found.</p>}
                {allResults.map(result => (
                    <div key={result.id} className="flex items-center justify-between p-3 bg-muted rounded-lg flex-wrap gap-2">
                        <div>
                            <p className="font-medium">{result.tournamentName}</p>
                            <p className="text-sm text-muted-foreground">{result.date}</p>
                        </div>
                        <div className="flex items-center gap-2">
                             <Button variant="ghost" size="icon" onClick={()={() => handleEdit(result)}>
                                <Edit className="h-4 w-4" />
                             </Button>
                             <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive">
                                      <Trash2 className="h-4 w-4"/>
                                    </Button>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent>
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        This will permanently delete the result for {result.tournamentName}. This action cannot be undone.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                                      <AlertDialogAction onClick={() => handleDelete(result.id)}>
                                        Delete
                                      </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                              </AlertDialog>
                            <AlertDialog>
                                <AlertDialogTrigger asChild>
                                    <Button onClick={()={() => handleGenerateHighlights(result)} variant="outline">
                                        <Sparkles className="mr-2 h-4 w-4 text-primary" /> AI Highlights
                                    </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                    <AlertDialogHeader>
                                        <AlertDialogTitle>AI Generated Highlights</AlertDialogTitle>
                                        <AlertDialogDescription>
                                            Here is the summary for {result.tournamentName}. You can copy this for social media posts.
                                        </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <div className="relative">
                                        <Textarea 
                                            readOnly
                                            value={isGenerating ? "Generating, please wait..." : generatedHighlights} 
                                            className="h-48 resize-none"
                                        />
                                        {isGenerating && <Loader2 className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-6 w-6 animate-spin"/>}
                                    </div>
                                    <AlertDialogFooter>
                                        <AlertDialogCancel onClick={() => setGeneratedHighlights('')}>Close</AlertDialogCancel>
                                        <Button onClick={handleCopyHighlights} disabled={!generatedHighlights || isGenerating}>
                                            <Copy className="mr-2 h-4 w-4"/> Copy Text
                                        </Button>
                                    </AlertDialogFooter>
                                </AlertDialogContent>
                            </AlertDialog>
                        </div>
                    </div>
                ))}
            </CardContent>
        </Card>
      </div>
    </div>
  );
}

