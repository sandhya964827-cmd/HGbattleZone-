

import { initializeApp } from "firebase/app";
import { getFirestore, collection, doc, setDoc, getDoc, updateDoc, addDoc, query, where, onSnapshot, deleteDoc, orderBy, serverTimestamp, runTransaction, getDocs, increment } from "firebase/firestore";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged, signOut, updateProfile, EmailAuthProvider, reauthenticateWithCredential, updatePassword, sendEmailVerification } from "firebase/auth";
import { getStorage, ref as storageRef, uploadBytes, getDownloadURL, deleteObject } from "firebase/storage";
import { getDatabase, ref as rtRef, onValue, set, remove, update } from "firebase/database";
import { firebaseConfig } from "./firebase-config";
import { initializeAppCheck, ReCaptchaV3Provider } from "firebase/app-check";
import type { Tournament, TournamentRegistration, PlayerRegistration, TournamentResult, Notice, LiveMatch, CategoryBanners, SpecialScrimBanners, TeamResult, LivePlayer } from "./types";
import { UserProfile } from "@/app/profile/page";


// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize App Check
// TODO: Replace "YOUR_RECAPTCHA_V3_SITE_KEY" with your actual site key from the Google Cloud console.
// Make sure to also update it in src/app/layout.tsx
if (typeof window !== 'undefined') {
    // initializeAppCheck(app, {
    //     provider: new ReCaptchaV3Provider('YOUR_RECAPTCHA_V3_SITE_KEY'),
    //     isTokenAutoRefreshEnabled: true
    // });
}


// Get Firebase services
const db = getFirestore(app);
const auth = getAuth(app);
const storage = getStorage(app);
const realtimeDB = getDatabase(app);


// Firestore management for Banners
const onBannersUpdate = (callback: (banners: { [key: string]: any } | null) => void) => {
    const bannersRef = collection(db, 'banners_v2');
    const q = query(bannersRef, orderBy('id'));

    const unsubscribe = onSnapshot(q, async (snapshot) => {
        if (snapshot.empty) {
            callback({}); // Return an empty object if no banners exist
        } else {
            const bannerData: { [key: string]: any } = {};
            snapshot.forEach((doc) => {
                bannerData[doc.id] = doc.data();
            });
            callback(bannerData);
        }
    }, (error) => {
        console.error("Error fetching banners from Firestore:", error);
        callback(null);
    });

    return unsubscribe;
};


const saveAllBanners = async (banners: { [key: string]: any }) => {
    const batch = runTransaction(db, async (transaction) => {
        // First, delete all existing banners in the new collection
        const bannersRef = collection(db, 'banners_v2');
        const querySnapshot = await getDocs(bannersRef);
        querySnapshot.forEach((doc) => {
            transaction.delete(doc.ref);
        });

        // Now, add the new banners
        for (const key in banners) {
            const bannerRef = doc(db, 'banners_v2', key);
            transaction.set(bannerRef, banners[key]);
        }
    });
    await batch;
};

const deleteBanner = async (bannerId: string) => {
    // Get banner data to find the storage path if it's not a placeholder
    const bannerDocRef = doc(db, 'banners_v2', bannerId);
    const bannerDoc = await getDoc(bannerDocRef);
    const bannerData = bannerDoc.data();
    
    // Delete from Firestore
    await deleteDoc(bannerDocRef);

    // If the image source is from Firebase Storage, delete from storage too
    if (bannerData && bannerData.src && bannerData.src.includes('firebasestorage.googleapis.com')) {
        try {
            const fileRef = storageRef(storage, bannerData.src);
            await deleteObject(fileRef);
        } catch (error: any) {
           // It's okay if the file doesn't exist in storage
           if (error.code !== 'storage/object-not-found') {
                console.error("Error deleting from storage:", error);
           }
        }
    }
};

const getUserProfile = async (userId: string | undefined): Promise<UserProfile | null> => {
    if (!userId) return null;
    const docRef = doc(db, "users", userId);
    try {
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
            const profileData = docSnap.data() as UserProfile;
            let updates: Partial<UserProfile> = {};

            // Backfill tournamentRegId if it's missing
            if (!profileData.tournamentRegId) {
                console.log(`User ${userId} is missing tournamentRegId. Backfilling...`);
                updates.tournamentRegId = await getNextTournamentRegId();
                profileData.tournamentRegId = updates.tournamentRegId;
            }

            if (Object.keys(updates).length > 0) {
                await updateDoc(docRef, updates);
                console.log(`Backfilled missing fields for user ${userId}`);
            }

            return profileData;
        } else {
            console.log("No such user document!");
            return null;
        }
    } catch (error) {
        console.error("Error getting user profile:", error);
        return null;
    }
};

const onUserProfileUpdate = (userId: string, callback: (profile: UserProfile | null) => void) => {
    const docRef = doc(db, "users", userId);
    const unsubscribe = onSnapshot(docRef, (docSnap) => {
        if (docSnap.exists()) {
            callback(docSnap.data() as UserProfile);
        } else {
            callback(null);
        }
    });
    return unsubscribe;
};


const findUserByTournamentRegId = async (regId: number): Promise<UserProfile | null> => {
    const usersRef = collection(db, 'users');
    const q = query(usersRef, where('tournamentRegId', '==', regId));
    
    try {
        const querySnapshot = await getDocs(q);
        if (!querySnapshot.empty) {
            // Assuming tournamentRegId is unique, so we take the first result
            const userDoc = querySnapshot.docs[0];
            return userDoc.data() as UserProfile;
        } else {
            console.log(`No user found with tournamentRegId: ${regId}`);
            return null;
        }
    } catch (error) {
        console.error("Error finding user by tournamentRegId:", error);
        return null;
    }
};

const updateUserProfile = async (userId: string, data: { firstName: string, lastName: string, mobileNumber: string, gender: 'Male' | 'Female' | 'Other', playStyle?: string }) => {
    if (!userId) throw new Error("User ID is required to update profile.");
    const userDocRef = doc(db, "users", userId);
    try {
        await updateDoc(userDocRef, data as any);
    } catch (error) {
        console.error("Error updating user profile in Firestore: ", error);
        throw new Error("Failed to update profile.");
    }
};


// Function to get the next registration number
const getNextRegistrationNumber = async () => {
    const counterRef = doc(db, "counters", "userCounter");
    let newRegNumber;
    try {
        await runTransaction(db, async (transaction) => {
            const counterDoc = await transaction.get(counterRef);
            if (!counterDoc.exists()) {
                // If counter doesn't exist, start from 151
                newRegNumber = 151;
                transaction.set(counterRef, { currentNumber: newRegNumber });
            } else {
                // Otherwise, increment the current number
                const currentNumber = counterDoc.data().currentNumber;
                newRegNumber = currentNumber + 1;
                transaction.update(counterRef, { currentNumber: newRegNumber });
            }
        });
        return newRegNumber;
    } catch (e) {
        console.error("Transaction failed: ", e);
        throw new Error("Could not generate registration number.");
    }
}

// Function to get the next tournament registration ID
const getNextTournamentRegId = async () => {
    const counterRef = doc(db, "counters", "tournamentRegIdCounter");
    let newRegId;
    try {
        await runTransaction(db, async (transaction) => {
            const counterDoc = await transaction.get(counterRef);
            if (!counterDoc.exists()) {
                // If counter doesn't exist, start with the base ID
                newRegId = 18791153;
                transaction.set(counterRef, { currentId: newRegId });
            } else {
                // Otherwise, increment the current ID by 500
                const currentId = counterDoc.data().currentId;
                newRegId = currentId + 500;
                transaction.update(counterRef, { currentId: newRegId });
            }
        });
        return newRegId;
    } catch (e) {
        console.error("Tournament Reg ID transaction failed: ", e);
        throw new Error("Could not generate tournament registration ID.");
    }
}

// Firebase Storage file management
const uploadBanner = async (file: File, bannerId: string) => {
    const fileRef = storageRef(storage, `banners/${bannerId}`);
    await uploadBytes(fileRef, file);
    const downloadURL = await getDownloadURL(fileRef);
    return downloadURL;
};

const uploadProfilePhoto = async (file: File, userId: string) => {
    const user = auth.currentUser;
    if (!user || user.uid !== userId) {
        throw new Error("User not authenticated or incorrect user.");
    }

    const fileRef = storageRef(storage, `profile-photos/${userId}`);
    
    // Upload the file to Firebase Storage
    await uploadBytes(fileRef, file);
    
    // Get the download URL
    const photoURL = await getDownloadURL(fileRef);

    // Update the user's profile in Firebase Auth
    await updateProfile(user, { photoURL });

    // Update the user's document in Firestore
    const userDocRef = doc(db, "users", userId);
    await updateDoc(userDocRef, { photoURL });

    // Force a reload of the user to get the new photoURL in the auth state
    await user.reload();
    
    return photoURL;
}

// Password Change Function
const reauthenticateAndChangePassword = async (currentPassword: string, newPassword: string) => {
    const user = auth.currentUser;
    if (!user || !user.email) {
        throw new Error("No user is currently signed in or user has no email.");
    }

    // Create a credential with the user's email and current password
    const credential = EmailAuthProvider.credential(user.email, currentPassword);

    try {
        // Re-authenticate the user
        await reauthenticateWithCredential(user, credential);

        // If re-authentication is successful, update the password
        await updatePassword(user, newPassword);
    } catch (error) {
        console.error("Error changing password:", error);
        // Rethrow the error to be handled by the calling component
        throw error;
    }
};


// -- Tournament Functions --
const addTournament = async (tournamentData: Omit<Tournament, 'id' | 'createdAt'>) => {
    try {
        await addDoc(collection(db, "tournaments"), {
            ...tournamentData,
            createdAt: serverTimestamp(),
        });
    } catch (error) {
        console.error("Error adding tournament: ", error);
        throw error;
    }
};

const updateTournament = async (id: string, tournamentData: Partial<Tournament>) => {
     try {
        const tournamentRef = doc(db, "tournaments", id);
        await updateDoc(tournamentRef, tournamentData);
    } catch (error) {
        console.error("Error updating tournament: ", error);
        throw error;
    }
};

const deleteTournament = async (id: string) => {
    try {
        // Note: This doesn't delete sub-collections like registrations.
        // For a production app, a Cloud Function would be needed to handle cascading deletes.
        await deleteDoc(doc(db, "tournaments", id));
    } catch (error) {
        console.error("Error deleting tournament: ", error);
        throw error;
    }
};


const onTournamentsUpdate = (callback: (tournaments: Tournament[]) => void) => {
    const q = query(collection(db, "tournaments"), orderBy("createdAt", "desc"));
    
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
        const tournaments: Tournament[] = [];
        querySnapshot.forEach((doc) => {
            const data = doc.data();
            tournaments.push({
                ...data,
                id: doc.id,
                // Convert Firestore Timestamp to JS Date if it exists
                createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : new Date(),
            } as Tournament);
        });
        callback(tournaments);
    }, (error) => {
        console.error("Error listening to tournaments:", error);
    });

    return unsubscribe;
};


// -- Tournament Registration Functions --

// Add a new registration
const addRegistration = async (registrationData: Omit<TournamentRegistration, 'id' | 'date'>, entryFee: number) => {
  const user = auth.currentUser;
  if (!user) throw new Error("User not authenticated");

  const userRef = doc(db, "users", user.uid);
  const registrationRef = collection(db, "registrations");

  try {
    await runTransaction(db, async (transaction) => {
      const userDoc = await transaction.get(userRef);
      if (!userDoc.exists()) {
        throw new Error("User profile not found.");
      }

      const currentCoins = userDoc.data().coins || 0;
      if (currentCoins < entryFee) {
        throw new Error("Insufficient coins for registration.");
      }

      // Deduct coins
      const newCoins = currentCoins - entryFee;
      transaction.update(userRef, { coins: newCoins });

      // Create registration
      const newRegistrationDoc = doc(registrationRef); // Create a new doc reference
      transaction.set(newRegistrationDoc, {
        ...registrationData,
        uid: user.uid,
        date: serverTimestamp(),
      });
    });
  } catch (error) {
    console.error("Error adding registration: ", error);
    throw error;
  }
};


// Update an existing registration
const updateRegistration = async (docId: string, updatedData: any) => {
    try {
        const registrationRef = doc(db, "registrations", docId);
        await updateDoc(registrationRef, updatedData);
    } catch (error) {
        console.error("Error updating registration: ", error);
        throw error;
    }
};

// Delete a registration
const deleteRegistration = async (docId: string) => {
    try {
        await deleteDoc(doc(db, "registrations", docId));
    } catch (error) {
        console.error("Error deleting registration: ", error);
        throw error;
    }
};

// Listen for real-time updates for registrations of a specific tournament
const onRegistrationsUpdate = (tournamentId: string, callback: (players: any[]) => void) => {
    const q = query(collection(db, "registrations"), where("tournamentId", "==", tournamentId));
    
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
        const players: any[] = [];
        querySnapshot.forEach((doc) => {
            const data = doc.data();
            players.push({
                ...data,
                id: doc.id, // Add the document ID to the player object
                // Convert Firestore Timestamp to JS Date if it exists
                date: data.date?.toDate ? data.date.toDate() : new Date(),
            });
        });
        callback(players);
    }, (error) => {
        console.error("Error listening to registrations:", error);
    });

    return unsubscribe; // Return the unsubscribe function to stop listening
};

// Get all registrations made by a specific user, including tournament details and player profiles for badges
const getRegistrationsByUserId = async (userId: string): Promise<TournamentRegistration[]> => {
    const q = query(collection(db, "registrations"), where("uid", "==", userId));
    const querySnapshot = await getDocs(q);

    // Cache for user profiles to avoid refetching
    const userProfilesCache = new Map<string, UserProfile | null>();

    const getPlayerProfile = async (gameUID: string): Promise<UserProfile | null> => {
        if (userProfilesCache.has(gameUID)) {
            return userProfilesCache.get(gameUID)!;
        }
        
        const usersRef = collection(db, "users");
        // This is inefficient if `gameUID` is not the document ID. 
        // Assuming `PlayerRegistration.gameUID` matches a `user.uid` for this to work.
        // If `gameUID` is just an in-game ID, a different query strategy is needed.
        // Let's assume for now that some `gameUID` might correspond to a `user.uid`.
        const userQuery = query(usersRef, where("uid", "==", gameUID));
        const userSnapshot = await getDocs(userQuery);

        if (!userSnapshot.empty) {
            const userDoc = userSnapshot.docs[0];
            const userProfile = userDoc.data() as UserProfile;
            userProfilesCache.set(gameUID, userProfile);
            return userProfile;
        }

        userProfilesCache.set(gameUID, null);
        return null;
    };
    
    const registrationsPromises = querySnapshot.docs.map(async (docSnapshot) => {
        const registrationData = docSnapshot.data() as TournamentRegistration;
        let tournamentDetails: Tournament | null = null;

        // Fetch the corresponding tournament details
        if (registrationData.tournamentId) {
            const tournamentRef = doc(db, "tournaments", registrationData.tournamentId);
            const tournamentSnap = await getDoc(tournamentRef);
            if (tournamentSnap.exists()) {
                tournamentDetails = {
                    id: tournamentSnap.id,
                    ...tournamentSnap.data()
                } as Tournament;
            }
        }
        
        // Fetch profile for each player to get badge info
        const playersWithBadges = await Promise.all(
          registrationData.players.map(async (player) => {
            // We need a way to link a player in a registration to a user account.
            // Let's assume `player.gameUID` can be used to look up a user.
            // This is a big assumption. A better way would be to store the user's UID with each player registration.
            const userProfile = await getPlayerProfile(player.gameUID);
            return {
              ...player,
              badgeText: userProfile?.badgeText || null
            };
          })
        );

        return {
            ...registrationData,
            id: docSnapshot.id,
            date: (registrationData.date as any)?.toDate ? (registrationData.date as any).toDate() : new Date(),
            tournamentDetails: tournamentDetails,
            players: playersWithBadges, // Use players array with badge info
        } as TournamentRegistration;
    });

    const registrations = await Promise.all(registrationsPromises);
    return registrations;
};


// Get all registrations with their tournament details
const getAllRegistrationsWithTournamentDetails = async (): Promise<TournamentRegistration[]> => {
    const registrationsQuery = query(collection(db, "registrations"), orderBy("date", "desc"));
    const registrationsSnapshot = await getDocs(registrationsQuery);

    // Create a map to hold tournament data to avoid re-fetching for the same tournament
    const tournamentsMap = new Map<string, Tournament>();

    const registrationsPromises = registrationsSnapshot.docs.map(async (regDoc) => {
        const registrationData = regDoc.data();
        let tournamentDetails: Tournament | null = null;
        const tournamentId = registrationData.tournamentId;

        if (tournamentId) {
            // Check if tournament data is already fetched
            if (tournamentsMap.has(tournamentId)) {
                tournamentDetails = tournamentsMap.get(tournamentId)!;
            } else {
                // Fetch the corresponding tournament details
                const tournamentRef = doc(db, "tournaments", tournamentId);
                const tournamentSnap = await getDoc(tournamentRef);
                if (tournamentSnap.exists()) {
                    tournamentDetails = { id: tournamentSnap.id, ...tournamentSnap.data() } as Tournament;
                    tournamentsMap.set(tournamentId, tournamentDetails); // Cache the result
                }
            }
        }

        return {
            ...registrationData,
            id: regDoc.id,
            date: (registrationData.date as any)?.toDate ? (registrationData.date as any).toDate() : new Date(),
            tournamentDetails: tournamentDetails,
        } as TournamentRegistration;
    });

    return Promise.all(registrationsPromises);
};

// -- Tournament Results (Leaderboard) Functions --
const addOrUpdateResult = async (resultData: Omit<TournamentResult, 'id'>, docIdToUpdate: string | null) => {
    try {
        const resultsRef = collection(db, "results");
        
        // If an ID is provided, update that document. Otherwise, check for existing and then add.
        if (docIdToUpdate) {
            const docRef = doc(db, "results", docIdToUpdate);
            await updateDoc(docRef, { ...resultData, updatedAt: serverTimestamp() });
        } else {
            await addDoc(resultsRef, { ...resultData, createdAt: serverTimestamp() });
        }

        // Now, update the Realtime Database for any live matches associated with this tournament
        const liveMatchesRef = rtRef(realtimeDB, 'liveMatches');
        onValue(liveMatchesRef, (snapshot) => {
            if (snapshot.exists()) {
                snapshot.forEach((childSnapshot) => {
                    const liveMatch = childSnapshot.val() as LiveMatch;
                    if (liveMatch.tournamentId === resultData.tournamentId) {
                        const matchRef = rtRef(realtimeDB, `liveMatches/${childSnapshot.key}/leaderboard`);
                        set(matchRef, resultData.standings);
                    }
                });
            }
        }, { onlyOnce: true }); // We only need to do this once per update

    } catch (error) {
        console.error("Error saving result: ", error);
        throw error;
    }
};

const deleteResult = async (resultId: string) => {
    try {
        const resultRef = doc(db, "results", resultId);
        await deleteDoc(resultRef);
    } catch (error) {
        console.error("Error deleting result: ", error);
        throw error;
    }
};


const onResultsUpdate = (callback: (results: TournamentResult[]) => void) => {
    const q = query(collection(db, "results"), orderBy("createdAt", "desc"));
    
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
        const results: TournamentResult[] = [];
        querySnapshot.forEach((doc) => {
            const data = doc.data();
            results.push({
                ...data,
                id: doc.id,
            } as TournamentResult);
        });
        callback(results);
    }, (error) => {
        console.error("Error listening to results:", error);
    });

    return unsubscribe;
};

const getResultByTournamentId = async (tournamentId: string): Promise<TournamentResult | null> => {
    const resultsRef = collection(db, "results");
    const q = query(resultsRef, where("tournamentId", "==", tournamentId));
    const querySnapshot = await getDocs(q);
    if (querySnapshot.empty) {
        return null;
    }
    const docData = querySnapshot.docs[0].data();
    return {
        id: querySnapshot.docs[0].id,
        ...docData
    } as TournamentResult;
};

const updateLiveLeaderboard = async (matchId: string, standings: TeamResult[]) => {
    try {
        const leaderboardRef = rtRef(realtimeDB, `liveMatches/${matchId}/leaderboard`);
        await set(leaderboardRef, standings);
    } catch (error) {
        console.error("Error updating live leaderboard: ", error);
        throw error;
    }
};



// Get admin password from Firestore
const getAdminCredentials = async (): Promise<{email: string, password: string}> => {
    const configRef = doc(db, "config", "admin");
    try {
        const docSnap = await getDoc(configRef);
        if (docSnap.exists() && docSnap.data().password && docSnap.data().email) {
            return { email: docSnap.data().email, password: docSnap.data().password };
        } else {
            // If the document or password doesn't exist, create it with a default value
            const defaultCreds = {
                email: "hgbattlezone@gmail.com",
                password: "aradhyaHGbattleZone"
            }
            await setDoc(configRef, defaultCreds);
            return defaultCreds;
        }
    } catch (error) {
        console.error("Error getting admin credentials:", error);
        // Fallback to default password in case of an error
        return { email: "hgbattlezone@gmail.com", password: "aradhyaHGbattleZone" };
    }
};


// Notice Board from Firestore
const onNoticeBoardUpdate = (callback: (data: { notices: Notice[], footer: string } | null) => void) => {
    const noticeBoardRef = doc(db, 'config', 'noticeBoard');

    const unsubscribe = onSnapshot(noticeBoardRef, async (docSnap) => {
        if (docSnap.exists()) {
            callback(docSnap.data() as { notices: Notice[], footer: string });
        } else {
            // Document doesn't exist, create it with default data
            const defaultData = {
                notices: [
                    { id: '1', text: '<span class="font-semibold text-primary">1. Fair Play:</span> Cheating or using hacks will result in a permanent ban.' },
                    { id: '2', text: '<span class="font-semibold text-primary">2. Timeliness:</span> All teams must join the lobby at the scheduled time. No delays will be entertained.' },
                    { id: '3', text: '<span class="font-semibold text-primary">3. Respect:</span> Maintain a respectful attitude towards all players and organizers.' }
                ],
                footer: 'All decisions made by the tournament organizers are final. For detailed rules, please visit the <a href="/rules" class="underline text-primary">Rules</a> page.'
            };
            try {
                await setDoc(noticeBoardRef, defaultData);
                callback(defaultData);
            } catch (error) {
                console.error("Error creating default notice board:", error);
                callback(null);
            }
        }
    }, (error) => {
        console.error("Error fetching notice board data:", error);
        callback(null);
    });

    return unsubscribe;
};

// --- Category Banners ---
const onCategoryBannersUpdate = (callback: (banners: CategoryBanners | null) => void) => {
    const docRef = doc(db, 'config', 'categoryBanners');

    const unsubscribe = onSnapshot(docRef, async (docSnap) => {
        if (docSnap.exists()) {
            callback(docSnap.data() as CategoryBanners);
        } else {
            // Document doesn't exist, create it with default data
            const defaultData: CategoryBanners = {
                free: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                bermuda: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                clashSquad: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                loneWolf: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
            };
            try {
                await setDoc(docRef, defaultData);
                callback(defaultData);
            } catch (error) {
                console.error("Error creating default category banners:", error);
                callback(null);
            }
        }
    }, (error) => {
        console.error("Error fetching category banners:", error);
        callback(null);
    });

    return unsubscribe;
};

const saveCategoryBanners = async (data: CategoryBanners) => {
    const docRef = doc(db, 'config', 'categoryBanners');
    await setDoc(docRef, data, { merge: true });
};

// --- Special Scrim Banners ---
const onSpecialScrimBannersUpdate = (callback: (banners: SpecialScrimBanners | null) => void) => {
    const docRef = doc(db, 'config', 'specialScrimBanners');

    const unsubscribe = onSnapshot(docRef, async (docSnap) => {
        if (docSnap.exists()) {
            callback(docSnap.data() as SpecialScrimBanners);
        } else {
            // Document doesn't exist, create it with default data
            const defaultData: SpecialScrimBanners = {
                special: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                bermuda: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                clashSquad: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                loneWolf: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
            };
            try {
                await setDoc(docRef, defaultData);
                callback(defaultData);
            } catch (error) {
                console.error("Error creating default special scrim banners:", error);
                callback(null);
            }
        }
    }, (error) => {
        console.error("Error fetching special scrim banners:", error);
        callback(null);
    });

    return unsubscribe;
};

const saveSpecialScrimBanners = async (data: SpecialScrimBanners) => {
    const docRef = doc(db, 'config', 'specialScrimBanners');
    await setDoc(docRef, data, { merge: true });
};

// Payment Settings
const getPaymentSettings = async (): Promise<{ upiId: string }> => {
    const docRef = doc(db, "config", "paymentSettings");
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
        return docSnap.data() as { upiId: string };
    } else {
        // If it doesn't exist, create it with the default value
        const defaultSettings = { upiId: "8726120471@ibl" };
        await setDoc(docRef, defaultSettings);
        return defaultSettings;
    }
};

const updatePaymentSettings = async (data: { upiId: string }) => {
    const docRef = doc(db, "config", "paymentSettings");
    await setDoc(docRef, data, { merge: true });
};


// -- Admin Feature Control --
const findUserByUsernameOrId = async (searchTerm: string): Promise<UserProfile | null> => {
    // First, try searching by UID
    try {
        const userDocRef = doc(db, "users", searchTerm);
        const userDoc = await getDoc(userDocRef);
        if (userDoc.exists()) {
            return { uid: userDoc.id, ...userDoc.data() } as UserProfile;
        }
    } catch (error) {
        // This can error if searchTerm is not a valid doc path, which is fine. We'll continue to search by username.
        console.log("Could not find user by UID, will try username. Error:", error);
    }
    
    // If not found by UID, search by username
    const usersRef = collection(db, 'users');
    const q = query(usersRef, where('username', '==', searchTerm));
    try {
        const querySnapshot = await getDocs(q);
        if (!querySnapshot.empty) {
            const userDoc = querySnapshot.docs[0];
            return { uid: userDoc.id, ...userDoc.data() } as UserProfile;
        } else {
            return null;
        }
    } catch (error) {
        console.error("Error finding user by username:", error);
        return null;
    }
};

const updateUserPermissions = async (userId: string, permissions: string[]) => {
    const userDocRef = doc(db, "users", userId);
    try {
        await updateDoc(userDocRef, { adminPermissions: permissions });
    } catch (error) {
        console.error("Error updating user permissions:", error);
        throw new Error("Failed to update permissions.");
    }
};

export { 
    app, db, auth, storage, realtimeDB, onBannersUpdate, uploadBanner, deleteBanner, saveAllBanners, 
    collection, doc, setDoc, getDoc, createUserWithEmailAndPassword, signInWithEmailAndPassword, 
    onAuthStateChanged, signOut, updateProfile, uploadProfilePhoto, updateDoc, increment, addDoc, serverTimestamp,
    addTournament, updateTournament, deleteTournament, onTournamentsUpdate,
    addRegistration, updateRegistration, deleteRegistration, onRegistrationsUpdate,
    getUserProfile, onUserProfileUpdate, getNextRegistrationNumber, getNextTournamentRegId, updateUserProfile, findUserByTournamentRegId,
    reauthenticateAndChangePassword, getRegistrationsByUserId,
    getAllRegistrationsWithTournamentDetails,
    getAdminCredentials,
    addOrUpdateResult, onResultsUpdate, getResultByTournamentId, updateLiveLeaderboard, deleteResult,
    onNoticeBoardUpdate,
    sendEmailVerification,
    onCategoryBannersUpdate, saveCategoryBanners,
    onSpecialScrimBannersUpdate, saveSpecialScrimBanners,
    getPaymentSettings, updatePaymentSettings,
    findUserByUsernameOrId, updateUserPermissions
};

    