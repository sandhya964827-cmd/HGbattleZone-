

export type Tournament = {
  id: string;
  name: string;
  date: string;
  prizePool: string;
  entryFee: number;
  status: 'Upcoming' | 'Ongoing' | 'Completed';
  image: string;
  imageHint: string;
  slots: number;
  registeredCount: number;
  category: 'Free' | 'Bermuda' | 'Clash Squad' | 'Lone Wolf' | 'Special';
  mode: 'Solo' | 'Duo' | 'Squad';
  map: 'Bermuda' | 'Kalahari' | 'Purgatory' | 'Alpine';
  createdAt: any; // Using `any` to be flexible with server timestamps
};

export type PlayerRegistration = {
  name: string;
  gameName: string;
  gameUID: string;
  username?: string;
  mobileNumber?: string;
  email?: string;
  badgeText?: string | null;
  tRegId?: string;
};

export type TournamentRegistration = {
  id: string;
  tournamentId: string;
  squadName: string; 
  slotNumber: number; // Added to explicitly store the chosen slot
  mobileNumber: string;
  players: PlayerRegistration[];
  date: any;
  uid: string; // UID of the user who registered the team
  tournamentDetails?: Tournament | null; // Optional: To hold the details of the tournament
};


export type NewsArticle = {
  id: string;
  title: string;
  date: string;
  excerpt: string;
  image: string;
  imageHint: string;
};

export type Player = {
  id:string;
  name: string;
  skillLevel: 'Rookie' | 'Veteran' | 'Pro';
  playStyle: 'Rusher' | 'Sniper' | 'Support' | 'IGL';
  avatar: string;
};

export type LivePlayer = {
  name: string;
  kills: number;
  isAlive: boolean;
};

export type TeamResult = {
  rank: string;
  teamName: string;
  prize?: string;
  players?: LivePlayer[];
};

export type TournamentResult = {
  id: string;
  tournamentId: string;
  tournamentName: string;
  date: string;
  standings: TeamResult[];
  createdAt: any;
};

export type Banner = {
  id: string;
  src: string;
  alt: string;
  hint: string;
  title: string;
  description: string;
  videoUrl?: string;
};

export type LiveMatch = {
  id: string;
  title: string;
  youtubeUrl: string;
  tournamentId: string;
  leaderboard?: TeamResult[];
};

export type LiveComment = {
  id: string;
  uid: string;
  username: string;
  photoURL: string | null;
  text: string;
  timestamp: number;
  badgeText?: string | null;
};


export type UserProfile = {
    uid: string;
    firstName: string;
    lastName:string;
    username: string;
    email: string;
    mobileNumber: string;
    photoURL?: string | null;
    registrationNumber?: number;
    tournamentRegId?: number;
    createdAt: any; // Can be a Timestamp from Firestore or a Date object
    gender: 'Male' | 'Female' | 'Other';
    playStyle?: 'Rusher' | 'Sniper' | 'Support' | 'IGL';
    badgeText?: string | null;
    coins?: number;
    adminPermissions?: string[]; // Array of feature keys like 'addMatch', 'liveAdmin'
};

export type Notice = {
  id: string;
  text: string;
};

export type CategoryBanners = {
  free: string;
  bermuda: string;
  clashSquad: string;
  loneWolf: string;
};

export type SpecialScrimBanners = {
  special: string;
  bermuda: string;
  clashSquad: string;
  loneWolf: string;
};
