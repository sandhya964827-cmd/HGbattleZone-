import type { NewsArticle, Player, TournamentResult } from './types';

export const newsArticles: NewsArticle[] = [
  {
    id: '1',
    title: 'New Patch v1.5 Notes Released!',
    date: 'August 15, 2024',
    excerpt: 'The latest patch brings significant weapon balancing changes and a new map area. Read on to see how it affects your strategy.',
    image: 'https://picsum.photos/seed/news1/600/400',
    imageHint: 'game character'
  },
  {
    id: '2',
    title: 'Interview with "Viper", Winner of Last Week\'s Solo King',
    date: 'August 12, 2024',
    excerpt: 'We sit down with the champion to discuss his winning tactics, favorite loadouts, and tips for aspiring pros.',
    image: 'https://picsum.photos/seed/news2/600/400',
    imageHint: 'game map'
  },
  {
    id: '3',
    title: 'HGBattleZone Season 2 Announced',
    date: 'August 10, 2024',
    excerpt: 'Get ready for more action! Season 2 is coming with a bigger prize pool and more tournaments than ever before.',
    image: 'https://picsum.photos/seed/news3/600/400',
    imageHint: 'new weapon'
  }
];

export const suggestedPlayers: Player[] = [
  { id: '1', name: 'ShadowStriker', skillLevel: 'Pro', playStyle: 'Rusher', avatar: 'https://picsum.photos/seed/player1/100/100' },
  { id: '2', name: 'EagleEye', skillLevel: 'Pro', playStyle: 'Sniper', avatar: 'https://picsum.photos/seed/player2/100/100' },
  { id: '3', name: 'Guardian', skillLevel: 'Veteran', playStyle: 'Support', avatar: 'https://picsum.photos/seed/player3/100/100' },
  { id: '4', name: 'MasterMind', skillLevel: 'Pro', playStyle: 'IGL', avatar: 'https://picsum.photos/seed/player4/100/100' },
  { id: '5', name: 'Blitz', skillLevel: 'Veteran', playStyle: 'Rusher', avatar: 'https://picsum.photos/seed/player5/100/100' },
];


export const tournamentResults: TournamentResult[] = [
  {
    id: 'summersizzle',
    tournamentName: 'Summer Sizzle Series',
    date: 'July 15, 2024',
    standings: [
      { rank: 1, teamName: 'Team Inferno', kills: 45, prize: '$1,000' },
      { rank: 2, teamName: 'Cyclone Gaming', kills: 38, prize: '$500' },
      { rank: 3, teamName: 'Apex Predators', kills: 32, prize: '$250' },
      { rank: 4, teamName: 'Viper (Solo)', kills: 35, prize: '$100' },
      { rank: 5, teamName: 'Crimson Fury', kills: 28, prize: '$50' },
    ]
  },
  {
    id: 'weekly10',
    tournamentName: 'HGBattleZone Weekly #10 (Completed)',
    date: 'August 5, 2024',
    standings: [
        { rank: 1, teamName: 'Night Raid', kills: 50, prize: '$50' },
        { rank: 2, teamName: 'Solar Flare', kills: 40, prize: '$25' },
        { rank: 3, teamName: 'Ghost (Solo)', kills: 35, prize: '$10' },
    ]
  }
];
