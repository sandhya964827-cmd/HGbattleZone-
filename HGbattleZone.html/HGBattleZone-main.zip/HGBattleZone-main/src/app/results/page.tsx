
"use client";

import React, { useState, useEffect } from "react";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table"
import type { TournamentResult } from "@/lib/types";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Trophy, Shield, Flame, Search, Calendar as CalendarIcon, Loader2, Swords } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { onResultsUpdate } from "@/lib/firebase";

export default function ResultsPage() {
    const [allResults, setAllResults] = useState<TournamentResult[]>([]);
    const [filteredResults, setFilteredResults] = useState<TournamentResult[]>([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState("");
    const [searchDate, setSearchDate] = useState("");

    useEffect(() => {
        setLoading(true);
        const unsubscribe = onResultsUpdate((results) => {
            setAllResults(results);
            setFilteredResults(results); // Initially, show all results
            setLoading(false);
        });
        return () => unsubscribe();
    }, []);

    const handleSearch = () => {
        let results = allResults;

        if (searchTerm) {
            results = results.filter(r => 
                r.tournamentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                r.standings.some(s => s.teamName.toLowerCase().includes(searchTerm.toLowerCase()))
            );
        }

        if (searchDate) {
            results = results.filter(r => r.date.toLowerCase().includes(searchDate.toLowerCase()));
        }

        setFilteredResults(results);
    };

    const getRankIcon = (rank: number) => {
        if (rank === 1) return <Trophy className="h-5 w-5 text-yellow-400" />;
        if (rank === 2) return <Trophy className="h-5 w-5 text-slate-400" />;
        if (rank === 3) return <Trophy className="h-5 w-5 text-amber-700" />;
        return <Shield className="h-5 w-5 text-muted-foreground" />;
    };

    return (
        <div className="container mx-auto px-4 py-16">
            <div className="text-center mb-12">
                <h1 className="text-4xl md:text-5xl font-headline font-bold">Tournament Leaderboards</h1>
                <p className="text-muted-foreground mt-3 max-w-2xl mx-auto">
                    Check out the final standings and celebrate the champions of past tournaments.
                </p>
            </div>

            <div className="max-w-4xl mx-auto">
                <Card>
                    <CardHeader>
                        <CardTitle>Filter Leaderboards</CardTitle>
                        <CardDescription>Search by tournament/team name or date.</CardDescription>
                         <div className="flex flex-col sm:flex-row gap-2 mt-4">
                            <div className="relative flex-grow">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                <Input 
                                    placeholder="Search by name..." 
                                    className="pl-10"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                />
                            </div>
                             <div className="relative">
                                <CalendarIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                <Input 
                                    type="text" 
                                    placeholder="e.g., July 15, 2024" 
                                    className="pl-10"
                                    value={searchDate}
                                    onChange={(e) => setSearchDate(e.target.value)}
                                />
                            </div>
                            <Button onClick={handleSearch}>Search</Button>
                        </div>
                    </CardHeader>
                    <CardContent>
                         <div className="border rounded-lg max-h-[70vh] overflow-auto">
                            {loading ? (
                                <div className="flex justify-center items-center h-64">
                                    <Loader2 className="h-12 w-12 animate-spin text-primary" />
                                </div>
                            ) : (
                                <Table>
                                    <TableHeader>
                                    <TableRow>
                                        <TableHead className="w-[80px]">Rank</TableHead>
                                        <TableHead>Team</TableHead>
                                        <TableHead className="text-center">Kills</TableHead>
                                        <TableHead className="text-right">Prize</TableHead>
                                    </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {filteredResults.length > 0 ? (
                                            filteredResults.map(result => (
                                                <React.Fragment key={result.id}>
                                                    <TableRow className="bg-muted/50">
                                                        <TableCell colSpan={4} className="font-bold text-primary">
                                                            {result.tournamentName} - {result.date}
                                                        </TableCell>
                                                    </TableRow>
                                                    {result.standings.map((team) => {
                                                        const totalKills = (team.players || []).reduce((acc, p) => acc + (p.kills || 0), 0);
                                                        return (
                                                            <TableRow key={`${result.id}-${team.rank}`} className={team.rank === 1 ? 'bg-yellow-400/10' : ''}>
                                                                <TableCell className="font-bold text-lg">
                                                                    <div className="flex items-center gap-2">
                                                                        {getRankIcon(team.rank)}
                                                                        {team.rank}
                                                                    </div>
                                                                </TableCell>
                                                                <TableCell className="font-medium">{team.teamName}</TableCell>
                                                                <TableCell className="text-center">
                                                                    <div className="flex items-center justify-center gap-1">
                                                                        <Swords className="h-4 w-4 text-red-500" />
                                                                        {totalKills}
                                                                    </div>
                                                                </TableCell>
                                                                <TableCell className="text-right font-semibold text-primary">{team.prize || 'N/A'}</TableCell>
                                                            </TableRow>
                                                        );
                                                    })}
                                                </React.Fragment>
                                            ))
                                        ) : (
                                            <TableRow>
                                                <TableCell colSpan={4} className="h-24 text-center">
                                                    No results found. Try adjusting your search or check back later.
                                                </TableCell>
                                            </TableRow>
                                        )}
                                    </TableBody>
                                </Table>
                            )}
                         </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}

