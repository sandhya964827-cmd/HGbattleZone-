
'use server';

import { getResultByTournamentId } from '@/lib/firebase';
import type { TournamentResult } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Trophy, Flame, Shield, AlertTriangle, Swords } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

interface ResultPageProps {
    params: {
        tournamentId: string;
    };
}

const getRankIcon = (rank: number) => {
    if (rank === 1) return <Trophy className="h-5 w-5 text-yellow-400" />;
    if (rank === 2) return <Trophy className="h-5 w-5 text-slate-400" />;
    if (rank === 3) return <Trophy className="h-5 w-5 text-amber-700" />;
    return <Shield className="h-5 w-5 text-muted-foreground" />;
};

export default async function ResultPage({ params }: ResultPageProps) {
    const result: TournamentResult | null = await getResultByTournamentId(params.tournamentId);

    if (!result) {
        return (
            <div className="container mx-auto px-4 py-16 flex justify-center">
                <Alert variant="destructive" className="max-w-lg">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Result Not Found</AlertTitle>
                    <AlertDescription>
                        The result for this tournament has not been published yet. Please check back later.
                    </AlertDescription>
                </Alert>
            </div>
        );
    }
    
    return (
        <div className="container mx-auto px-4 py-16">
            <div className="max-w-4xl mx-auto">
                <Card>
                    <CardHeader className="text-center">
                        <CardTitle className="text-3xl md:text-4xl font-headline font-bold">{result.tournamentName}</CardTitle>
                        <CardDescription>{result.date}</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="border rounded-lg overflow-hidden">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead className="w-[80px]">Rank</TableHead>
                                        <TableHead>Team</TableHead>
                                        <TableHead className="text-center">Kills</TableHead>
                                        <TableHead className="text-right">Prize</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {result.standings.map((team) => {
                                        const totalKills = (team.players || []).reduce((acc, p) => acc + (p.kills || 0), 0);
                                        return (
                                            <TableRow key={`${result.id}-${team.rank}`} className={team.rank === 1 ? 'bg-yellow-400/10' : ''}>
                                                <TableCell className="font-bold text-lg">
                                                    <div className="flex items-center gap-2">
                                                        {getRankIcon(team.rank)}
                                                        {team.rank}
                                                    </div>
                                                </TableCell>
                                                <TableCell className="font-medium">{team.teamName}</TableCell>
                                                <TableCell className="text-center">
                                                    <div className="flex items-center justify-center gap-1">
                                                        <Swords className="h-4 w-4 text-red-500" />
                                                        {totalKills}
                                                    </div>
                                                </TableCell>
                                                <TableCell className="text-right font-semibold text-primary">{team.prize || 'N/A'}</TableCell>
                                            </TableRow>
                                        );
                                    })}
                                </TableBody>
                            </Table>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}

