

"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Search, Loader2, DollarSign, Users, Calendar as CalendarIcon, Gamepad2, Trophy, User as UserIcon, Users2, Swords } from "lucide-react";
import { getRegistrationsByUserId } from "@/lib/firebase";
import type { TournamentRegistration } from "@/lib/types";
import { format } from "date-fns";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import AdminGuard from "@/components/admin-guard";

const months = [
    { value: 1, label: 'January' }, { value: 2, label: 'February' }, { value: 3, label: 'March' },
    { value: 4, label: 'April' }, { value: 5, label: 'May' }, { value: 6, label: 'June' },
    { value: 7, label: 'July' }, { value: 8, label: 'August' }, { value: 9, label: 'September' },
    { value: 10, label: 'October' }, { value: 11, label: 'November' }, { value: 12, label: 'December' }
];

const currentYear = new Date().getFullYear();
const years = Array.from({ length: 5 }, (_, i) => currentYear - i);


function EarnPageContent() {
  const [userId, setUserId] = useState("");
  const [allRegistrations, setAllRegistrations] = useState<TournamentRegistration[] | null>(null);
  const [filteredRegistrations, setFilteredRegistrations] = useState<TournamentRegistration[] | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searched, setSearched] = useState(false);
  
  const [selectedMonth, setSelectedMonth] = useState<string>(String(new Date().getMonth() + 1));
  const [selectedYear, setSelectedYear] = useState<string>(String(new Date().getFullYear()));

  const [totalEarnings, setTotalEarnings] = useState(0);
  const [soloCount, setSoloCount] = useState(0);
  const [duoCount, setDuoCount] = useState(0);
  const [squadCount, setSquadCount] = useState(0);

  const calculateStats = (regs: TournamentRegistration[]) => {
    let earnings = 0;
    let solo = 0;
    let duo = 0;
    let squad = 0;

    regs.forEach(reg => {
      const mode = reg.tournamentDetails?.mode;
      if (mode === 'Solo') {
        earnings += 5;
        solo++;
      } else if (mode === 'Duo') {
        earnings += 10;
        duo++;
      } else if (mode === 'Squad') {
        earnings += 20;
        squad++;
      }
    });
    return { earnings, solo, duo, squad };
  };

  const filterAndCalculate = () => {
    if (!allRegistrations) return;
    
    const month = parseInt(selectedMonth, 10);
    const year = parseInt(selectedYear, 10);

    const filtered = allRegistrations.filter(reg => {
        const regDate = new Date(reg.date);
        return regDate.getMonth() + 1 === month && regDate.getFullYear() === year;
    });

    setFilteredRegistrations(filtered);

    const { earnings, solo, duo, squad } = calculateStats(filtered);
    setTotalEarnings(earnings);
    setSoloCount(solo);
    setDuoCount(duo);
    setSquadCount(squad);
  }

  const handleSearch = async () => {
    if (!userId) {
      setError("Please enter a User ID to search.");
      setSearched(false);
      return;
    }
    setIsLoading(true);
    setError(null);
    setSearched(true);
    setAllRegistrations(null);
    setFilteredRegistrations(null);

    try {
      const results = await getRegistrationsByUserId(userId);
      setAllRegistrations(results as TournamentRegistration[]);
    } catch (e) {
      console.error("Failed to fetch registrations:", e);
      setError("Could not fetch registrations for this User ID. Please check the ID and try again.");
      setAllRegistrations(null);
    } finally {
      setIsLoading(false);
    }
  };

  // Effect to run calculation after initial search or when filters change
  useEffect(() => {
    if (allRegistrations !== null) {
      filterAndCalculate();
    }
  }, [allRegistrations, selectedMonth, selectedYear]);


  const totalRegistrationsCount = soloCount + duoCount + squadCount;

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-4xl mx-auto text-center">
        <h1 className="text-4xl md:text-5xl font-headline font-bold">Registration History</h1>
        <p className="text-muted-foreground mt-3">
          Enter a User ID and select a month to see registrations and total earnings.
        </p>
      </div>

      <div className="max-w-3xl mx-auto mt-12">
        
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Search by User ID & Date</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
              <Input
                placeholder="Enter User ID..."
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                disabled={isLoading}
              />
              <Button onClick={handleSearch} disabled={isLoading} className="w-full sm:w-auto">
                {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Search className="mr-2 h-4 w-4" />}
                Search
              </Button>
            </div>
             <div className="grid grid-cols-2 gap-4">
                 <Select value={selectedMonth} onValueChange={setSelectedMonth} disabled={isLoading || !allRegistrations}>
                    <SelectTrigger>
                        <SelectValue placeholder="Select month" />
                    </SelectTrigger>
                    <SelectContent>
                        {months.map(m => <SelectItem key={m.value} value={String(m.value)}>{m.label}</SelectItem>)}
                    </SelectContent>
                </Select>
                 <Select value={selectedYear} onValueChange={setSelectedYear} disabled={isLoading || !allRegistrations}>
                    <SelectTrigger>
                        <SelectValue placeholder="Select year" />
                    </SelectTrigger>
                    <SelectContent>
                        {years.map(y => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}
                    </SelectContent>
                </Select>
            </div>
          </CardContent>
        </Card>

        {isLoading && (
            <div className="flex justify-center items-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
        )}
        
        {searched && !isLoading && (
          <>
            {error ? (
                 <Alert variant="destructive">
                    <AlertTitle>Search Failed</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                </Alert>
            ) : (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Total Earn ({months.find(m=>m.value === parseInt(selectedMonth))?.label} {selectedYear})</CardTitle>
                            <DollarSign className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">₹{totalEarnings}</div>
                            <p className="text-xs text-muted-foreground">from {totalRegistrationsCount} registrations this month</p>
                        </CardContent>
                    </Card>
                     <Card>
                        <CardHeader>
                            <CardTitle className="text-sm font-medium">Registrations by Mode</CardTitle>
                        </CardHeader>
                        <CardContent className="flex justify-around text-center">
                            <div className="flex flex-col items-center gap-1">
                                <UserIcon className="h-5 w-5 text-muted-foreground"/>
                                <p className="text-xl font-bold">{soloCount}</p>
                                <p className="text-xs text-muted-foreground">Solo</p>
                            </div>
                            <div className="flex flex-col items-center gap-1">
                                <Users className="h-5 w-5 text-muted-foreground"/>
                                <p className="text-xl font-bold">{duoCount}</p>
                                <p className="text-xs text-muted-foreground">Duo</p>
                            </div>
                            <div className="flex flex-col items-center gap-1">
                                <Users2 className="h-5 w-5 text-muted-foreground"/>
                                <p className="text-xl font-bold">{squadCount}</p>
                                <p className="text-xs text-muted-foreground">Squad</p>
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {filteredRegistrations && filteredRegistrations.length > 0 ? (
                    <div className="space-y-6">
                        <h2 className="text-2xl font-headline text-center">Found {filteredRegistrations.length} Registration(s)</h2>
                        {filteredRegistrations.map((reg) => (
                            <Card key={reg.id}>
                                <CardHeader>
                                   <div className="flex justify-between items-start">
                                      <div>
                                        <CardTitle className="font-headline text-xl">{reg.tournamentDetails?.name || "Tournament Details Missing"}</CardTitle>
                                        <CardDescription>
                                            Registration for Squad: <span className="font-semibold text-primary">{reg.squadName}</span>
                                        </CardDescription>
                                      </div>
                                       <Badge variant="secondary">{reg.tournamentDetails?.status}</Badge>
                                   </div>
                                </CardHeader>
                                <CardContent>
                                     <div className="space-y-4">
                                         <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                                            <div className="flex items-center gap-2 text-muted-foreground">
                                                <CalendarIcon className="h-4 w-4"/>
                                                <span>{reg.tournamentDetails?.date || 'N/A'}</span>
                                            </div>
                                            <div className="flex items-center gap-2 text-muted-foreground">
                                                <Trophy className="h-4 w-4"/>
                                                <span>Prize: {reg.tournamentDetails?.prizePool || 'N/A'}</span>
                                            </div>
                                             <div className="flex items-center gap-2 text-muted-foreground">
                                                <DollarSign className="h-4 w-4"/>
                                                <span>Fee: {reg.tournamentDetails?.entryFee || 'N/A'}</span>
                                            </div>
                                            <div className="flex items-center gap-2 text-muted-foreground col-span-2 md:col-span-3">
                                                <Gamepad2 className="h-4 w-4"/>
                                                <span>{reg.tournamentDetails?.mode} ({reg.tournamentDetails?.category})</span>
                                            </div>
                                        </div>
                                        <Separator />
                                         <h4 className="font-semibold text-md">Players Registered ({reg.players.length}):</h4>
                                         <div className="border rounded-lg">
                                            <Table>
                                                <TableHeader>
                                                    <TableRow>
                                                        <TableHead>Name</TableHead>
                                                        <TableHead>Game Name</TableHead>
                                                        <TableHead>Game UID</TableHead>
                                                        <TableHead>Username</TableHead>
                                                        <TableHead>Mobile</TableHead>
                                                    </TableRow>
                                                </TableHeader>
                                                <TableBody>
                                                    {reg.players.map((player, index) => (
                                                    <TableRow key={index}>
                                                        <TableCell>{player.name}</TableCell>
                                                        <TableCell>{player.gameName}</TableCell>
                                                        <TableCell>{player.gameUID}</TableCell>
                                                        <TableCell>
                                                            <div className="flex items-center gap-2">
                                                                {player.username || 'N/A'}
                                                                {player.badgeText && (
                                                                <TooltipProvider>
                                                                    <Tooltip>
                                                                        <TooltipTrigger>
                                                                            <div className="flex items-center justify-center h-5 w-5 bg-amber-950 rounded-full border border-amber-400 animate-pulse-glow">
                                                                                <span className="font-bold text-xs text-amber-400">{player.badgeText}</span>
                                                                            </div>
                                                                        </TooltipTrigger>
                                                                        <TooltipContent>
                                                                            <p>Verified Player</p>
                                                                        </TooltipContent>
                                                                    </Tooltip>
                                                                </TooltipProvider>
                                                                )}
                                                            </div>
                                                        </TableCell>
                                                        <TableCell>{player.mobileNumber || 'N/A'}</TableCell>
                                                    </TableRow>
                                                    ))}
                                                </TableBody>
                                            </Table>
                                        </div>
                                        <div className="text-xs text-muted-foreground pt-2">
                                          Registered on: {format(reg.date, "PPP, p")} by User ID: {reg.uid}
                                        </div>
                                     </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                 ) : (
                    <Card>
                        <CardContent className="pt-6 text-center text-muted-foreground">
                            No registrations found for this User ID in the selected month.
                        </CardContent>
                    </Card>
                 )}
               </>
            )}
          </>
        )}
      </div>
    </div>
  );
}


export default function EarnPage() {
    return (
        <AdminGuard>
            <EarnPageContent />
        </AdminGuard>
    )
}
