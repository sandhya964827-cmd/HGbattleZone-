import Image from "next/image";
import Link from "next/link";
import { newsArticles } from "@/lib/data";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, Calendar } from "lucide-react";

export default function NewsPage() {
    return (
        <div className="container mx-auto px-4 py-16">
            <div className="text-center mb-12">
                <h1 className="text-4xl md:text-5xl font-headline font-bold">News & Announcements</h1>
                <p className="text-muted-foreground mt-3 max-w-2xl mx-auto">
                    Stay updated with the latest happenings in the HGBattleZone and the world of Free Fire.
                </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {newsArticles.map((article) => (
                    <Card key={article.id} className="flex flex-col overflow-hidden transition-transform transform hover:-translate-y-2 hover:shadow-2xl hover:shadow-primary/30">
                         <CardContent className="p-0">
                            <div className="aspect-video w-full overflow-hidden">
                                <Image
                                    src={article.image}
                                    alt={article.title}
                                    width={600}
                                    height={400}
                                    data-ai-hint={article.imageHint}
                                    className="w-full h-full object-cover"
                                />
                            </div>
                        </CardContent>
                        <CardHeader>
                            <CardTitle className="font-headline text-xl h-14">{article.title}</CardTitle>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground pt-2">
                                <Calendar className="w-4 h-4" />
                                <span>{article.date}</span>
                            </div>
                        </CardHeader>
                        <CardContent className="flex-grow">
                            <p className="text-muted-foreground">{article.excerpt}</p>
                        </CardContent>
                        <CardFooter>
                            <Button asChild variant="link" className="p-0 text-accent">
                                <Link href="#">
                                    Read More <ArrowRight className="ml-2 h-4 w-4" />
                                </Link>
                            </Button>
                        </CardFooter>
                    </Card>
                ))}
            </div>
        </div>
    );
}
