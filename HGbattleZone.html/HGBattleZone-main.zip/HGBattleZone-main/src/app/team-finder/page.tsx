"use client";

import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Loader2, Send } from "lucide-react";
import { suggestTeammates } from "@/ai/ai-team-formation";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Terminal } from "lucide-react";

const formSchema = z.object({
  skillLevel: z.string().min(1, "Please select your skill level."),
  playStyle: z.string().min(1, "Please select your play style."),
  availability: z.string().min(1, "Please select your availability."),
});

export default function TeamFinderPage() {
  const [isFinding, setIsFinding] = useState(false);
  const [foundPlayers, setFoundPlayers] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      skillLevel: "",
      playStyle: "",
      availability: "",
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsFinding(true);
    setFoundPlayers([]);
    setError(null);
    try {
      const result = await suggestTeammates(values);
      if (result.suggestedTeammates) {
        setFoundPlayers(result.suggestedTeammates);
      }
    } catch (e) {
      console.error(e);
      setError("We couldn't find teammates at this moment. Please try again later.");
    } finally {
      setIsFinding(false);
    }
  }

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-headline font-bold">Find Your Perfect Squad</h1>
          <p className="text-muted-foreground mt-3 max-w-2xl mx-auto">
            Tell our AI about your play style, and we'll suggest teammates to help you dominate the arena.
          </p>
        </div>

        <Card className="mb-12">
            <CardHeader>
                <CardTitle>Your Player Profile</CardTitle>
            </CardHeader>
            <CardContent>
                <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <FormField
                        control={form.control}
                        name="skillLevel"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Skill Level</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                <SelectTrigger>
                                    <SelectValue placeholder="Select your skill" />
                                </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                    <SelectItem value="Rookie">Rookie</SelectItem>
                                    <SelectItem value="Veteran">Veteran</SelectItem>
                                    <SelectItem value="Pro">Pro</SelectItem>
                                </SelectContent>
                            </Select>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                        <FormField
                        control={form.control}
                        name="playStyle"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Primary Play Style</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                <SelectTrigger>
                                    <SelectValue placeholder="Select your style" />
                                </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                    <SelectItem value="Rusher">Rusher (Aggressive)</SelectItem>
                                    <SelectItem value="Sniper">Sniper (Long-range)</SelectItem>
                                    <SelectItem value="Support">Support (Team Player)</SelectItem>
                                    <SelectItem value="IGL">IGL (In-Game Leader)</SelectItem>
                                </SelectContent>
                            </Select>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                        <FormField
                        control={form.control}
                        name="availability"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Availability</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                <SelectTrigger>
                                    <SelectValue placeholder="Select when you play" />
                                </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                    <SelectItem value="Weekdays">Weekdays</SelectItem>
                                    <SelectItem value="Weekends">Weekends</SelectItem>
                                    <SelectItem value="Flexible">Flexible</SelectItem>
                                </SelectContent>
                            </Select>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                    </div>
                    <Button type="submit" className="w-full md:w-auto" disabled={isFinding}>
                        {isFinding ? (
                            <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Finding...</>
                        ) : (
                            <><Send className="mr-2 h-4 w-4" /> Find Teammates</>
                        )}
                    </Button>
                </form>
                </Form>
            </CardContent>
        </Card>

        {isFinding && (
          <div className="text-center">
            <Loader2 className="mx-auto h-8 w-8 animate-spin text-primary" />
            <p className="mt-2 text-muted-foreground">Searching for your new squad...</p>
          </div>
        )}

        {error && (
            <Alert variant="destructive">
                <Terminal className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>
                    {error}
                </AlertDescription>
            </Alert>
        )}

        {foundPlayers.length > 0 && (
          <div>
            <h2 className="text-2xl font-headline font-bold text-center mb-8">Suggested Teammates</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {foundPlayers.map((player, index) => (
                <Card key={index}>
                  <CardContent className="p-6">
                    <p className="text-muted-foreground">{player}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
