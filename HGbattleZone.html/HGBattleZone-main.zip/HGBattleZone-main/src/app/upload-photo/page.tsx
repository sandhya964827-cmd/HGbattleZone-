
"use client";

import { useState } from "react";
import { useAuth } from "@/context/auth-context";
import { useRouter } from "next/navigation";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Loader2, UploadCloud } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { updateProfile, updateDoc, doc, db, uploadProfilePhoto } from "@/lib/firebase";

export default function UploadPhotoPage() {
    const { user, loading: authLoading } = useAuth();
    const router = useRouter();
    const { toast } = useToast();
    const [file, setFile] = useState<File | null>(null);
    const [previewUrl, setPreviewUrl] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    if (authLoading) {
        return (
            <div className="flex items-center justify-center h-screen w-full">
                <Loader2 className="h-12 w-12 animate-spin text-primary" />
            </div>
        );
    }

    if (!user) {
        // This should theoretically not happen due to AuthGuard, but it's good practice.
        router.push('/login');
        return null;
    }
    
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = e.target.files?.[0] ?? null;
        if (selectedFile) {
            setFile(selectedFile);
            setPreviewUrl(URL.createObjectURL(selectedFile));
        }
    };

    const handleUpload = async () => {
        if (!file || !user) {
            toast({
                variant: "destructive",
                title: "No file selected",
                description: "Please select a photo to upload.",
            });
            return;
        }

        setIsLoading(true);
        try {
            // Upload to storage
            const photoURL = await uploadProfilePhoto(file, user.uid);

            // Update user profile in Firebase Auth
            await updateProfile(user, { photoURL });

            // Update user document in Firestore
            const userDocRef = doc(db, "users", user.uid);
            await updateDoc(userDocRef, { photoURL });

            toast({
                title: "Profile Picture Updated!",
                description: "Your profile is now complete.",
            });
            
            // Force a reload of the user to get the new photoURL in the auth state
            await user.reload();

            // Redirect to home page
            router.push('/');

        } catch (error) {
            console.error("Photo upload failed:", error);
            toast({
                variant: "destructive",
                title: "Upload Failed",
                description: "There was an error uploading your photo. Please try again.",
            });
        } finally {
            setIsLoading(false);
        }
    };

    const handleSkip = () => {
        router.push('/');
         toast({
            title: "Setup Skipped",
            description: "You can add a profile picture later from your profile page.",
        });
    }

    return (
        <div className="container mx-auto px-4 py-16 flex items-center justify-center min-h-screen">
            <div className="max-w-md w-full">
                <Card>
                    <CardHeader className="text-center">
                        <h1 className="text-3xl font-headline font-bold">Almost There!</h1>
                        <CardDescription>Upload a profile picture to complete your registration.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="flex justify-center">
                            <Avatar className="h-32 w-32 border-4 border-primary">
                                <AvatarImage src={previewUrl || undefined} alt="Profile preview" />
                                <AvatarFallback className="text-4xl">{user.email?.[0].toUpperCase()}</AvatarFallback>
                            </Avatar>
                        </div>
                        
                        <Input type="file" accept="image/*" onChange={handleFileChange} disabled={isLoading} />
                        
                        <Button onClick={handleUpload} className="w-full" disabled={isLoading || !file}>
                            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UploadCloud className="mr-2 h-4 w-4"/>}
                            {isLoading ? "Uploading..." : "Upload & Continue"}
                        </Button>

                         <Button variant="link" className="w-full" onClick={handleSkip}>
                            Skip for now
                        </Button>

                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
