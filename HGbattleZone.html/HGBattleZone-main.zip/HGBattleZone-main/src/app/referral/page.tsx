
"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Ban } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function ReferralPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-2xl mx-auto text-center">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-center gap-3 text-3xl">
              <Ban className="h-8 w-8 text-destructive" />
              Referral System Unavailable
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground">
              The referral system is no longer available.
            </p>
            <Button asChild>
                <Link href="/">Return to Homepage</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
