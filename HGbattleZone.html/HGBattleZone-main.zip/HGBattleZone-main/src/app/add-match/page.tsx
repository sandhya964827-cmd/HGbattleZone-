

"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, PlusCircle, CalendarIcon, Edit, Trash2, XCircle } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { Calendar } from "@/components/ui/calendar";
import { format } from "date-fns";
import { addTournament, onTournamentsUpdate, deleteTournament, updateTournament } from "@/lib/firebase";
import { useRouter } from "next/navigation";
import { useState, useEffect } from "react";
import type { Tournament } from "@/lib/types";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import AdminGuard from "@/components/admin-guard";

const formSchema = z.object({
  name: z.string().min(5, "Tournament name must be at least 5 characters."),
  date: z.date({
    required_error: "A date is required.",
  }),
  time: z.string().min(1, "Please enter a time."),
  prizePool: z.string().min(1, "Please enter a prize pool."),
  entryFee: z.coerce.number().min(0, "Please enter an entry fee (can be 0)."),
  mode: z.enum(["Solo", "Duo", "Squad"]),
  map: z.enum(["Bermuda", "Kalahari", "Purgatory", "Alpine"], {
    required_error: "Please select a map.",
  }),
  slots: z.coerce.number().min(1, "Slots must be at least 1."),
  category: z.enum(["Free", "Bermuda", "Clash Squad", "Lone Wolf"], {
    required_error: "Please select a category.",
  }),
  status: z.enum(["Upcoming", "Ongoing", "Completed"]),
  image: z.any().optional(),
});

function AddMatchPageContent() {
  const { toast } = useToast();
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);
  const [editingTournamentId, setEditingTournamentId] = useState<string | null>(null);
  const [allTournaments, setAllTournaments] = useState<Tournament[]>([]);

  useEffect(() => {
    const unsub = onTournamentsUpdate(setAllTournaments);
    return () => unsub();
  }, []);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      time: "",
      prizePool: "",
      entryFee: 0,
      slots: 50,
      category: undefined,
      mode: undefined,
      map: undefined,
      status: "Upcoming",
    },
  });

  const categoryValue = form.watch("category");

  const resetFormAndState = () => {
    form.reset({
      name: "",
      time: "",
      prizePool: "",
      entryFee: 0,
      slots: 50,
      category: undefined,
      mode: undefined,
      map: undefined,
      status: "Upcoming",
      date: undefined,
    });
    setEditingTournamentId(null);
  }

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    try {
      const tournamentDate = `${format(values.date, "MMMM d, yyyy")} - ${values.time}`;
      const tournamentData = {
        name: values.name,
        date: tournamentDate,
        prizePool: values.prizePool,
        entryFee: values.entryFee,
        mode: values.mode,
        map: values.map,
        slots: values.slots,
        category: values.category,
        status: values.status,
        registeredCount: 0, // This might need adjustment based on real count if editing
        image: `https://picsum.photos/seed/${values.name.replace(/\s+/g, '-')}/600/400`,
        imageHint: 'esports tournament',
      };
      
      if (editingTournamentId) {
        await updateTournament(editingTournamentId, tournamentData);
        toast({
          title: "Match Updated!",
          description: `The tournament "${values.name}" has been updated.`,
        });
      } else {
        await addTournament(tournamentData);
        toast({
          title: "Match Added!",
          description: `The tournament "${values.name}" has been created.`,
        });
      }
      
      resetFormAndState();

    } catch (error) {
       console.error("Error processing tournament:", error);
       toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to process the tournament. Please try again.",
      });
    } finally {
        setIsLoading(false);
    }
  }

  const handleEdit = (tournament: Tournament) => {
    // Only allow editing if the tournament belongs to the categories for this page
    const allowedCategories: string[] = ["Free", "Bermuda", "Clash Squad", "Lone Wolf"];
    if (!allowedCategories.includes(tournament.category)) {
        toast({
            variant: "destructive",
            title: "Wrong Page",
            description: `Please go to the "Add Match Mediam" page to edit "${tournament.name}".`
        });
        return;
    }
    
    setEditingTournamentId(tournament.id);
    
    const dateParts = tournament.date ? tournament.date.split(' - ') : [];
    const dateString = dateParts[0] || '';
    const timeString = dateParts[1] || '';
    const parsedDate = new Date(dateString);

    form.reset({
      name: tournament.name,
      date: isNaN(parsedDate.getTime()) ? undefined : parsedDate,
      time: timeString,
      prizePool: tournament.prizePool,
      entryFee: tournament.entryFee,
      slots: tournament.slots,
      category: tournament.category as any,
      mode: tournament.mode,
      map: tournament.map,
      status: tournament.status,
    })
  }

  const handleDelete = async (tournamentId: string) => {
    try {
      await deleteTournament(tournamentId);
      toast({
        variant: "destructive",
        title: "Match Deleted",
        description: "The tournament has been successfully removed.",
      });
    } catch (error) {
       console.error("Error deleting tournament:", error);
       toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to delete the tournament.",
      });
    }
  };

  const filteredTournaments = allTournaments.filter(t => ["Free", "Bermuda", "Clash Squad", "Lone Wolf"].includes(t.category));

  const modeOptions = categoryValue === 'Lone Wolf' 
    ? [{value: "Solo", label: "Solo"}, {value: "Duo", label: "Duo"}]
    : [{value: "Solo", label: "Solo"}, {value: "Duo", label: "Duo"}, {value: "Squad", label: "Squad"}];


  return (
    <div className="container mx-auto px-4 py-16">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-headline font-bold">{editingTournamentId ? "Edit Match" : "Add a New Match"}</h1>
        <p className="text-muted-foreground mt-3 max-w-2xl mx-auto">
          {editingTournamentId ? "Modify the details below to update the tournament." : "Fill in the details below to create a new tournament."}
        </p>
      </div>

      <div className="max-w-4xl mx-auto">
        <Card>
            <CardHeader>
                <CardTitle>Tournament Details</CardTitle>
                <CardDescription>Provide all the necessary information for the match.</CardDescription>
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <FormField
                            control={form.control}
                            name="name"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Tournament Name</FormLabel>
                                <FormControl>
                                    <Input placeholder="e.g., Weekly Solo Challenge" {...field} disabled={isLoading} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                             <FormField
                              control={form.control}
                              name="category"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Category</FormLabel>
                                  <Select onValueChange={field.onChange} value={field.value} disabled={isLoading}>
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select match category" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="Free">Free Matches</SelectItem>
                                      <SelectItem value="Bermuda">Bermuda</SelectItem>
                                      <SelectItem value="Clash Squad">Clash Squad</SelectItem>
                                      <SelectItem value="Lone Wolf">Lone Wolf</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={form.control}
                              name="mode"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Mode</FormLabel>
                                  <Select onValueChange={field.onChange} value={field.value} disabled={isLoading || !categoryValue}>
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select game mode" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      {modeOptions.map(option => (
                                        <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                        </div>
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <FormField
                                control={form.control}
                                name="date"
                                render={({ field }) => (
                                    <FormItem className="flex flex-col">
                                    <FormLabel>Date</FormLabel>
                                    <Popover>
                                        <PopoverTrigger asChild>
                                        <FormControl>
                                            <Button
                                            variant={"outline"}
                                            className={cn(
                                                "w-full pl-3 text-left font-normal",
                                                !field.value && "text-muted-foreground"
                                            )}
                                            disabled={isLoading}
                                            >
                                            {field.value ? (
                                                format(field.value, "PPP")
                                            ) : (
                                                <span>Pick a date</span>
                                            )}
                                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                            </Button>
                                        </FormControl>
                                        </PopoverTrigger>
                                        <PopoverContent className="w-auto p-0" align="start">
                                        <Calendar
                                            mode="single"
                                            selected={field.value}
                                            onSelect={field.onChange}
                                            disabled={(date) =>
                                                date < new Date() || isLoading
                                            }
                                            initialFocus
                                        />
                                        </PopoverContent>
                                    </Popover>
                                    <FormMessage />
                                    </FormItem>
                                )}
                                />
                            <FormField
                                control={form.control}
                                name="time"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>Time</FormLabel>
                                    <FormControl>
                                        <Input type="time" {...field} disabled={isLoading} />
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                           <FormField
                              control={form.control}
                              name="map"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Map</FormLabel>
                                  <Select onValueChange={field.onChange} value={field.value} disabled={isLoading}>
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select map" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="Bermuda">Bermuda</SelectItem>
                                      <SelectItem value="Kalahari">Kalahari</SelectItem>
                                      <SelectItem value="Purgatory">Purgatory</SelectItem>
                                      <SelectItem value="Alpine">Alpine</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                                control={form.control}
                                name="prizePool"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>Prize Pool</FormLabel>
                                    <FormControl>
                                        <Input placeholder="e.g., ₹1,500" {...field} disabled={isLoading}/>
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <FormField
                                control={form.control}
                                name="entryFee"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>Entry Fee (Coins)</FormLabel>
                                    <FormControl>
                                        <Input type="number" placeholder="e.g., 20" {...field} disabled={isLoading}/>
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="slots"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>Slots</FormLabel>
                                    <FormControl>
                                        <Input type="number" placeholder="50" {...field} disabled={isLoading}/>
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                        </div>
                        <FormField
                            control={form.control}
                            name="status"
                            render={({ field }) => (
                            <FormItem>
                                <FormLabel>Status</FormLabel>
                                <Select onValueChange={field.onChange} value={field.value} disabled={isLoading}>
                                <FormControl>
                                    <SelectTrigger>
                                    <SelectValue placeholder="Set the tournament status" />
                                    </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                    <SelectItem value="Upcoming">Upcoming</SelectItem>
                                    <SelectItem value="Ongoing">Ongoing</SelectItem>
                                    <SelectItem value="Completed">Completed</SelectItem>
                                </SelectContent>
                                </Select>
                                <FormMessage />
                            </FormItem>
                            )}
                        />

                         <div className="flex flex-col sm:flex-row gap-2">
                           <Button type="submit" className="w-full" disabled={isLoading}>
                             {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <PlusCircle className="mr-2 h-4 w-4"/>}
                             {isLoading ? (editingTournamentId ? "Updating..." : "Adding...") : (editingTournamentId ? "Update Match" : "Add Match")}
                           </Button>
                           {editingTournamentId && (
                             <Button type="button" variant="outline" className="w-full" onClick={resetFormAndState}>
                               <XCircle className="mr-2 h-4 w-4" />
                               Cancel Edit
                             </Button>
                           )}
                        </div>

                    </form>
                </Form>
            </CardContent>
        </Card>

        <Card className="mt-12">
          <CardHeader>
            <CardTitle>Tournament History</CardTitle>
            <CardDescription>View, edit, or delete previously created tournaments.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="border rounded-lg max-h-[500px] overflow-auto">
              <Table>
                <TableHeader className="sticky top-0 bg-muted">
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTournaments.length > 0 ? filteredTournaments.map(t => (
                    <TableRow key={t.id}>
                      <TableCell className="font-medium">{t.name}</TableCell>
                      <TableCell>{t.date}</TableCell>
                      <TableCell>{t.status}</TableCell>
                      <TableCell className="text-right space-x-2">
                         <Button variant="ghost" size="icon" onClick={() => handleEdit(t)}>
                            <Edit className="h-4 w-4" />
                         </Button>
                         <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive">
                                  <Trash2 className="h-4 w-4"/>
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    This action cannot be undone. This will permanently delete the tournament and all its registrations.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => handleDelete(t.id)}>
                                    Delete
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                          </AlertDialog>
                      </TableCell>
                    </TableRow>
                  )) : (
                     <TableRow>
                        <TableCell colSpan={4} className="h-24 text-center">
                          No tournaments created yet.
                        </TableCell>
                      </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default function AddMatchPage() {
    return (
        <AdminGuard>
            <AddMatchPageContent />
        </AdminGuard>
    )
}
