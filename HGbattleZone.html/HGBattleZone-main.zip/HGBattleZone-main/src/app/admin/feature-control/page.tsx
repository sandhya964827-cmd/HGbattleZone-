

"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Loader2, Search, Save, ShieldCheck } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { findUserByUsernameOrId, updateUserPermissions } from "@/lib/firebase";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import type { UserProfile } from "@/app/profile/page";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Terminal } from "lucide-react";
import AdminGuard from "@/components/admin-guard";

// Defines the features that can be controlled
const adminFeatures = [
  { id: 'addMatch', label: 'Add Match' },
  { id: 'addMatchMediam', label: 'Add Match Mediam' },
  { id: 'liveAdmin', label: 'Live Admin' },
  { id: 'manageResults', label: 'Manage Results' },
  { id: 'coinRequests', label: 'Coin Requests' },
  { id: 'manageBanners', label: 'Manage Banners' },
  { id: 'manageCategoryBanners', label: 'Category Banners' },
  { id: 'manageScrimBanners', label: 'Scrim Banners' },
  { id: 'registrationHistory', label: 'Registration History' },
  { id: 'settings', label: 'Global Settings' },
  { id: 'featureControl', label: 'Feature Control' },
];

function FeatureControlPageContent() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [foundUser, setFoundUser] = useState<UserProfile | null>(null);
  const [permissions, setPermissions] = useState<Record<string, boolean>>({});
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    // When a user is found, initialize the permissions state from their profile
    if (foundUser) {
      const initialPerms: Record<string, boolean> = {};
      adminFeatures.forEach(feature => {
        initialPerms[feature.id] = (foundUser.adminPermissions || []).includes(feature.id);
      });
      setPermissions(initialPerms);
    }
  }, [foundUser]);

  const handleSearch = async () => {
    if (!searchTerm) {
      setError("Please enter a username or User ID to search.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setFoundUser(null);
    setPermissions({});
    try {
      const user = await findUserByUsernameOrId(searchTerm);
      if (user) {
        setFoundUser(user);
      } else {
        setError("No user found with this username or User ID.");
      }
    } catch (e) {
      console.error("Error searching user:", e);
      setError("An error occurred while searching for the user.");
    } finally {
      setIsLoading(false);
    }
  };

  const handlePermissionChange = (featureId: string, checked: boolean) => {
    setPermissions(prev => ({
      ...prev,
      [featureId]: checked,
    }));
  };

  const handleSaveChanges = async () => {
    if (!foundUser) return;
    setIsSaving(true);
    try {
      const grantedPermissions = Object.keys(permissions).filter(key => permissions[key]);
      await updateUserPermissions(foundUser.uid, grantedPermissions);
      toast({
        title: "Permissions Updated!",
        description: `Features for ${foundUser.username} have been saved.`,
      });
    } catch (e) {
      console.error("Error saving permissions:", e);
      toast({
        variant: "destructive",
        title: "Save Failed",
        description: "Could not save the new permissions.",
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-headline font-bold">Admin Feature Control</h1>
        <p className="text-muted-foreground mt-3 max-w-2xl mx-auto">
          Grant or revoke access to specific admin features for any user.
        </p>
      </div>

      <div className="max-w-2xl mx-auto">
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Search for a User</CardTitle>
            <CardDescription>Enter the username or User ID of the user you want to manage.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2">
              <Input
                placeholder="Enter username or User ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                disabled={isLoading}
              />
              <Button onClick={handleSearch} disabled={isLoading}>
                {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Search className="mr-2 h-4 w-4" />}
                Search
              </Button>
            </div>
          </CardContent>
        </Card>

        {error && (
            <Alert variant="destructive" className="mb-8">
                <Terminal className="h-4 w-4" />
                <AlertTitle>Search Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
            </Alert>
        )}

        {foundUser && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShieldCheck className="text-primary"/>
                Permissions for {foundUser.username}
              </CardTitle>
              <CardDescription>Select the features this user can access as an admin.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                {adminFeatures.map(feature => (
                  <div key={feature.id} className="flex items-center space-x-2 p-3 bg-muted rounded-md">
                    <Checkbox
                      id={feature.id}
                      checked={permissions[feature.id] || false}
                      onCheckedChange={(checked) => handlePermissionChange(feature.id, !!checked)}
                    />
                    <Label htmlFor={feature.id} className="cursor-pointer">
                      {feature.label}
                    </Label>
                  </div>
                ))}
              </div>
              <Button onClick={handleSaveChanges} disabled={isSaving} className="w-full">
                {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                Save Permissions
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}


export default function FeatureControlPage() {
    return (
        <AdminGuard>
            <FeatureControlPageContent />
        </AdminGuard>
    )
}
