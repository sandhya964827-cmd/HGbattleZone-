

"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight, PlusCircle, Video, Image as ImageIcon, Award, LayoutGrid, Coins, Settings, User, ShieldCheck } from "lucide-react";
import Link from "next/link";
import { useAuth } from "@/context/auth-context";
import { useRouter } from "next/navigation";
import { onUserProfileUpdate } from "@/lib/firebase";
import { useState, useEffect } from "react";
import type { UserProfile } from "@/app/profile/page";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Terminal } from "lucide-react";
import AdminGuard from "@/components/admin-guard";

const allAdminLinks = [
  { id: 'addMatch', href: "/add-match", label: "Add Match", icon: PlusCircle, description: "Create new free & regular tournaments." },
  { id: 'addMatchMediam', href: "/add-match-mediam", label: "Add Mediam Match", icon: PlusCircle, description: "Create new mid-tier tournaments." },
  { id: 'liveAdmin', href: "/live-admin", label: "Live Admin", icon: Video, description: "Manage live streams and leaderboards." },
  { id: 'manageResults', href: "/manage-results", label: "Manage Results", icon: Award, description: "Post and edit tournament results." },
  { id: 'coinRequests', href: "/admin/coin-requests", label: "Coin Requests", icon: Coins, description: "Approve or decline coin purchase requests." },
  { id: 'manageBanners', href: "/manage-banners", label: "Manage Banners", icon: ImageIcon, description: "Update homepage carousel banners." },
  { id: 'manageCategoryBanners', href: "/manage-category-banners", label: "Category Banners", icon: LayoutGrid, description: "Update tournament category banners." },
  { id: 'manageScrimBanners', href: "/manage-scrim-banners", label: "Scrim Banners", icon: LayoutGrid, description: "Update special scrim category banners." },
  { id: 'registrationHistory', href: "/earn", label: "Registration History", icon: User, description: "View user registration details." },
  { id: 'settings', href: "/admin/settings", label: "Global Settings", icon: Settings, description: "Manage application-wide settings like UPI ID." },
  { id: 'featureControl', href: "/admin/feature-control", label: "Feature Control", icon: ShieldCheck, description: "Manage features for other admins." },
];

function AdminDashboardPageContent() {
    const { user, isAdmin, loading: authLoading } = useAuth();
    const router = useRouter();
    const [profile, setProfile] = useState<UserProfile | null>(null);

    useEffect(() => {
        if (user) {
            const unsubscribe = onUserProfileUpdate(user.uid, (userProfile) => {
                if (userProfile) {
                    setProfile(userProfile as UserProfile);
                }
            });
            return () => unsubscribe();
        } else {
            setProfile(null);
        }
    }, [user]);

    if (authLoading || !profile) {
        return null; // or a loading spinner
    }

    const isHBadgeAdmin = profile.badgeText === 'H';
    const userPermissions = profile.adminPermissions || [];
    
    const accessibleLinks = isHBadgeAdmin 
        ? allAdminLinks 
        : allAdminLinks.filter(link => userPermissions.includes(link.id));

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-headline font-bold">Admin Dashboard</h1>
        <p className="text-muted-foreground mt-3 max-w-2xl mx-auto">
          Manage all aspects of your HGBattleZone application from one central place.
        </p>
      </div>

      {accessibleLinks.length > 0 ? (
        <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6">
            {accessibleLinks.map((link) => (
            <Link href={link.href} key={link.href} className="group">
                <Card className="h-full hover:bg-muted/50 hover:border-primary/50 transition-all">
                    <CardContent className="p-4 flex items-center justify-between">
                        <div className="flex items-center gap-4">
                            <link.icon className="h-8 w-8 text-primary" />
                            <div>
                                <h3 className="font-semibold text-lg">{link.label}</h3>
                                <p className="text-sm text-muted-foreground">{link.description}</p>
                            </div>
                        </div>
                        <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:translate-x-1 transition-transform" />
                    </CardContent>
                </Card>
            </Link>
            ))}
        </div>
      ) : (
        <div className="max-w-2xl mx-auto">
             <Alert variant="destructive">
                <Terminal className="h-4 w-4" />
                <AlertTitle>No Permissions Granted</AlertTitle>
                <AlertDescription>
                    You do not have access to any admin features yet. Please contact the main administrator ('H' badge) to get access.
                </AlertDescription>
            </Alert>
        </div>
      )}
    </div>
  );
}

export default function AdminDashboardPage() {
    return (
        <AdminGuard>
            <AdminDashboardPageContent />
        </AdminGuard>
    )
}
