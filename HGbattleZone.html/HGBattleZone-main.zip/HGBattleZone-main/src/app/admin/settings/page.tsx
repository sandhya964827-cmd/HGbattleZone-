

"use client";

import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Loader2, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { getPaymentSettings, updatePaymentSettings } from "@/lib/firebase";
import AdminGuard from "@/components/admin-guard";

const formSchema = z.object({
  upiId: z.string().min(3, "Please enter a valid UPI ID."),
});

type FormData = z.infer<typeof formSchema>;

function SettingsPageContent() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      upiId: "",
    },
  });

  useEffect(() => {
    async function fetchSettings() {
      setLoading(true);
      try {
        const settings = await getPaymentSettings();
        form.reset({ upiId: settings.upiId });
      } catch (error) {
        console.error("Failed to fetch settings:", error);
        toast({ variant: "destructive", title: "Error", description: "Could not load settings." });
      } finally {
        setLoading(false);
      }
    }
    fetchSettings();
  }, [form, toast]);
  
  const handleSaveChanges = async (data: FormData) => {
    setSaving(true);
    try {
        await updatePaymentSettings(data);
        toast({ title: "Settings Saved!", description: "Your payment settings have been updated."});
    } catch(err) {
        console.error(err);
        toast({ variant: "destructive", title: "Save Failed", description: "Could not save settings." });
    } finally {
        setSaving(false);
    }
  };
  
  if (loading) {
    return <div className="flex justify-center items-center h-screen"><Loader2 className="h-12 w-12 animate-spin text-primary" /></div>;
  }

  return (
    <div className="container mx-auto px-4 py-16">
       <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-headline font-bold">Admin Settings</h1>
        <p className="text-muted-foreground mt-3 max-w-2xl mx-auto">
            Manage your application's global settings.
        </p>
      </div>

      <div className="max-w-2xl mx-auto">
        <Card>
            <CardHeader>
                <CardTitle>Payment Settings</CardTitle>
                <CardDescription>Update the UPI ID used for coin purchases.</CardDescription>
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(handleSaveChanges)} className="space-y-6">
                        <FormField
                            control={form.control}
                            name="upiId"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>UPI ID</FormLabel>
                                <FormControl>
                                    <Input placeholder="yourname@bank" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                        <Button type="submit" disabled={saving}>
                           {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Save className="mr-2 h-4 w-4"/>}
                           Save Changes
                        </Button>
                    </form>
                </Form>
            </CardContent>
        </Card>
      </div>
    </div>
  );
}


export default function SettingsPage() {
    return (
        <AdminGuard>
            <SettingsPageContent />
        </AdminGuard>
    )
}
