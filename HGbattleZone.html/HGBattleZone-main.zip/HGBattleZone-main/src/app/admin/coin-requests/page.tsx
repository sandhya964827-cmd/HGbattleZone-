

"use client";

import { useState, useEffect } from "react";
import { collection, onSnapshot, query, orderBy } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, CheckCircle, XCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { approveCoinRequest, declineCoinRequest } from "@/app/actions/payment";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatDistanceToNow } from 'date-fns';
import AdminGuard from "@/components/admin-guard";

type CoinRequest = {
  id: string;
  userId: string;
  userEmail: string;
  username: string;
  package: {
    amount: number;
    coins: number;
  };
  transactionId: string;
  status: 'pending' | 'approved' | 'declined';
  createdAt: {
    seconds: number;
    nanoseconds: number;
  };
};

function RequestList({ requests, onAction, loadingActionId }: { requests: CoinRequest[], onAction: (requestId: string, action: 'approve' | 'decline') => void, loadingActionId: string | null }) {
    if (requests.length === 0) {
        return <p className="text-muted-foreground text-center py-8">No requests in this category.</p>;
    }

    return (
        <div className="space-y-4">
            {requests.map((req) => (
                <Card key={req.id}>
                    <CardContent className="p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                        <div className="flex-grow space-y-1">
                            <p className="font-semibold text-lg">{req.username || req.userEmail}</p>
                            <p className="text-sm">Requests <span className="font-bold text-primary">{req.package.coins} coins</span> for <span className="font-bold">₹{req.package.amount}</span></p>
                            <p className="text-xs text-muted-foreground">User ID: {req.userId}</p>
                            <p className="text-xs text-muted-foreground">Transaction ID: <span className="font-mono">{req.transactionId}</span></p>
                             <p className="text-xs text-muted-foreground">
                                {formatDistanceToNow(new Date(req.createdAt.seconds * 1000), { addSuffix: true })}
                            </p>
                        </div>
                        <div className="flex gap-2 items-center">
                            {req.status === 'pending' ? (
                                <>
                                    <Button
                                        size="sm"
                                        variant="outline"
                                        className="text-red-500 hover:text-red-600"
                                        onClick={() => onAction(req.id, 'decline')}
                                        disabled={loadingActionId === req.id}
                                    >
                                        {loadingActionId === req.id ? <Loader2 className="h-4 w-4 animate-spin"/> : <XCircle className="h-4 w-4"/>}
                                        <span className="ml-2">Decline</span>
                                    </Button>
                                    <Button
                                        size="sm"
                                        onClick={() => onAction(req.id, 'approve')}
                                        disabled={loadingActionId === req.id}
                                    >
                                        {loadingActionId === req.id ? <Loader2 className="h-4 w-4 animate-spin"/> : <CheckCircle className="h-4 w-4"/>}
                                         <span className="ml-2">Approve</span>
                                    </Button>
                                </>
                            ) : (
                                <Badge variant={req.status === 'approved' ? 'secondary' : 'destructive'} className="capitalize">
                                    {req.status}
                                </Badge>
                            )}
                        </div>
                    </CardContent>
                </Card>
            ))}
        </div>
    );
}

function CoinRequestsPageContent() {
  const [pendingRequests, setPendingRequests] = useState<CoinRequest[]>([]);
  const [approvedRequests, setApprovedRequests] = useState<CoinRequest[]>([]);
  const [declinedRequests, setDeclinedRequests] = useState<CoinRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingActionId, setLoadingActionId] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    setLoading(true);
    const q = query(collection(db, "pendingCoinRequests"), orderBy("createdAt", "desc"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const allReqs: CoinRequest[] = [];
      snapshot.forEach(doc => {
        allReqs.push({ id: doc.id, ...doc.data() } as CoinRequest);
      });
      setPendingRequests(allReqs.filter(r => r.status === 'pending'));
      setApprovedRequests(allReqs.filter(r => r.status === 'approved'));
      setDeclinedRequests(allReqs.filter(r => r.status === 'declined'));
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleAction = async (requestId: string, action: 'approve' | 'decline') => {
    setLoadingActionId(requestId);
    const req = pendingRequests.find(r => r.id === requestId);
    if (!req) return;

    try {
      if (action === 'approve') {
        const result = await approveCoinRequest({
          requestId: req.id,
          userId: req.userId,
          coinsToAdd: req.package.coins,
        });
        if (result.success) {
          toast({ title: 'Request Approved!', description: `${req.package.coins} coins added to ${req.username}.` });
        } else {
          throw new Error(result.error || 'Approval failed');
        }
      } else { // Decline
        const result = await declineCoinRequest(req.id);
        if (result.success) {
          toast({ variant: 'destructive', title: 'Request Declined' });
        } else {
          throw new Error(result.error || 'Decline failed');
        }
      }
    } catch (error) {
      console.error(error);
      toast({ variant: 'destructive', title: 'Action Failed', description: error instanceof Error ? error.message : 'An error occurred.' });
    } finally {
      setLoadingActionId(null);
    }
  };

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-4xl mx-auto">
        <CardHeader className="px-0 text-center">
          <CardTitle className="text-4xl md:text-5xl font-headline font-bold">Coin Requests</CardTitle>
          <CardDescription>Approve or decline user requests for coins.</CardDescription>
        </CardHeader>
        
        <Tabs defaultValue="pending" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="pending">Pending ({pendingRequests.length})</TabsTrigger>
                <TabsTrigger value="approved">Approved</TabsTrigger>
                <TabsTrigger value="declined">Declined</TabsTrigger>
            </TabsList>
            <div className="mt-6">
                {loading ? (
                    <div className="flex justify-center items-center py-16">
                        <Loader2 className="h-8 w-8 animate-spin" />
                    </div>
                ) : (
                    <>
                        <TabsContent value="pending">
                            <RequestList requests={pendingRequests} onAction={handleAction} loadingActionId={loadingActionId} />
                        </TabsContent>
                        <TabsContent value="approved">
                            <RequestList requests={approvedRequests} onAction={handleAction} loadingActionId={loadingActionId} />
                        </TabsContent>
                        <TabsContent value="declined">
                            <RequestList requests={declinedRequests} onAction={handleAction} loadingActionId={loadingActionId} />
                        </TabsContent>
                    </>
                )}
            </div>
        </Tabs>
      </div>
    </div>
  );
}


export default function CoinRequestsPage() {
    return (
        <AdminGuard>
            <CoinRequestsPageContent />
        </AdminGuard>
    )
}
