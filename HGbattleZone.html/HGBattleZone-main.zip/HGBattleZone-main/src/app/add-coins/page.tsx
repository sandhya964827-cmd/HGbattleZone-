
"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Coins, Loader2, QrCode } from "lucide-react";
import { useAuth } from "@/context/auth-context";
import { useToast } from "@/hooks/use-toast";
import type { UserProfile } from "@/app/profile/page";
import { getUserProfile, getPaymentSettings } from "@/lib/firebase";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import Image from "next/image";
import { addDoc, collection, serverTimestamp, getFirestore } from "firebase/firestore";
import { app } from "@/lib/firebase";

const db = getFirestore(app);

const coinPackages = [
  { amount: 10, coins: 10 },
  { amount: 20, coins: 20 },
  { amount: 50, coins: 55 },
  { amount: 100, coins: 115 },
  { amount: 200, coins: 240 },
  { amount: 500, coins: 625 },
];

function PaymentDialog({ pkg, upiId, userProfile }: { pkg: { amount: number, coins: number }, upiId: string, userProfile: UserProfile }) {
    const { toast } = useToast();
    const [transactionId, setTransactionId] = useState("");
    const [isRequesting, setIsRequesting] = useState(false);
    const [dialogOpen, setDialogOpen] = useState(false);

    const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=upi://pay?pa=${upiId}&pn=HGBattleZone&am=${pkg.amount}&cu=INR`;

    const handleRequestCoins = async () => {
        if (!transactionId) {
            toast({ variant: "destructive", title: "Missing ID", description: "Please enter your transaction ID." });
            return;
        }
        setIsRequesting(true);
        try {
            await addDoc(collection(db, "pendingCoinRequests"), {
                userId: userProfile.uid,
                username: userProfile.username,
                userEmail: userProfile.email,
                package: pkg,
                transactionId: transactionId,
                status: 'pending',
                createdAt: serverTimestamp(),
            });
            toast({ title: "Request Sent!", description: "Your request has been sent for approval. Coins will be added shortly." });
            setDialogOpen(false);
        } catch (error) {
            console.error("Failed to send coin request:", error);
            toast({ variant: "destructive", title: "Error", description: "Could not send your request. Please try again." });
        } finally {
            setIsRequesting(false);
        }
    };

    return (
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
                <Button className="w-full">
                    Buy Now
                </Button>
            </DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Complete Your Payment</DialogTitle>
                    <DialogDescription>
                        Scan the QR code or use the UPI ID to pay ₹{pkg.amount}. Then enter the transaction ID below.
                    </DialogDescription>
                </DialogHeader>
                <div className="flex flex-col items-center gap-4 py-4">
                    <Image src={qrCodeUrl} alt="UPI QR Code" width={200} height={200} data-ai-hint="qr code"/>
                    <p className="font-mono bg-muted p-2 rounded-md">{upiId}</p>
                    <div className="w-full space-y-2">
                        <Label htmlFor="txnId">Transaction ID</Label>
                        <Input 
                            id="txnId" 
                            placeholder="Enter the 12-digit UPI transaction ID" 
                            value={transactionId}
                            onChange={(e) => setTransactionId(e.target.value)}
                        />
                    </div>
                </div>
                <Button onClick={handleRequestCoins} disabled={isRequesting} className="w-full">
                    {isRequesting ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : null}
                    {isRequesting ? "Submitting..." : "Request Coins"}
                </Button>
            </DialogContent>
        </Dialog>
    )
}

export default function AddCoinsPage() {
  const { user, loading: authLoading } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [paymentSettings, setPaymentSettings] = useState<{ upiId: string }>({ upiId: '' });
  const [loadingSettings, setLoadingSettings] = useState(true);

  useEffect(() => {
    async function loadData() {
        if (user) {
            getUserProfile(user.uid).then(data => setProfile(data as UserProfile));
        }
        try {
            const settings = await getPaymentSettings();
            setPaymentSettings(settings);
        } catch (error) {
            console.error("Failed to load payment settings", error);
        } finally {
            setLoadingSettings(false);
        }
    }
    loadData();
  }, [user]);

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-headline font-bold">Add Coins to Your Wallet</h1>
        <p className="text-muted-foreground mt-3 max-w-2xl mx-auto">
          Purchase coins to join paid tournaments. Pay via UPI and submit a request for approval.
        </p>
      </div>

      <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {(authLoading || loadingSettings) ? (
            [...Array(6)].map((_, i) => <Card key={i}><CardContent className="p-6"><Loader2 className="animate-spin" /></CardContent></Card>)
        ) : (
            coinPackages.map((pkg) => (
            <Card key={pkg.amount} className="flex flex-col">
                <CardHeader className="text-center">
                <CardTitle className="text-5xl font-bold flex items-center justify-center gap-2">
                    <Coins className="h-10 w-10 text-yellow-400" />
                    {pkg.coins}
                </CardTitle>
                {pkg.coins > pkg.amount && (
                    <CardDescription className="text-green-500 font-bold">
                    You get {pkg.coins - pkg.amount} extra coins!
                    </CardDescription>
                )}
                </CardHeader>
                <CardContent className="flex-grow flex flex-col justify-end items-center pt-6">
                <p className="text-3xl font-bold mb-4">₹{pkg.amount}</p>
                {profile ? (
                    <PaymentDialog pkg={pkg} upiId={paymentSettings.upiId} userProfile={profile} />
                ) : (
                    <Button className="w-full" disabled>Login to Buy</Button>
                )}
                </CardContent>
            </Card>
            ))
        )}
      </div>
    </div>
  );
}
