import type { Metadata } from 'next';
import './globals.css';
import { cn } from '@/lib/utils';
import { Toaster } from '@/components/ui/toaster';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import BottomNav from '@/components/layout/bottom-nav';
import { AuthProvider } from '@/context/auth-context';
import AuthGuard from '@/components/auth-guard';
import Script from 'next/script';

export const metadata: Metadata = {
  title: 'HGBattleZone',
  description: 'The ultimate destination for Free Fire tournaments.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className={cn('font-body antialiased min-h-screen flex flex-col dark')}>
        
          <AuthProvider>
            <AuthGuard>
              <Header />
              <main className="flex-grow pb-20">{children}</main>
              <Footer />
              <BottomNav />
              <Toaster />
            </AuthGuard>
          </AuthProvider>
        
        {/* TODO: Replace "YOUR_RECAPTCHA_V3_SITE_KEY" with your actual site key */}
        <Script src="https://www.google.com/recaptcha/api.js?render=YOUR_RECAPTCHA_V3_SITE_KEY" strategy="lazyOnload" />
      </body>
    </html>
  );
}
