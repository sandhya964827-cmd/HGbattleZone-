

"use client";

import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { onCategoryBannersUpdate, saveCategoryBanners } from "@/lib/firebase";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Loader2, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import Image from "next/image";
import { Label } from "@/components/ui/label";
import AdminGuard from "@/components/admin-guard";

const formSchema = z.object({
  free: z.string().url("Please enter a valid YouTube URL").optional().or(z.literal('')),
  bermuda: z.string().url("Please enter a valid YouTube URL").optional().or(z.literal('')),
  clashSquad: z.string().url("Please enter a valid YouTube URL").optional().or(z.literal('')),
  loneWolf: z.string().url("Please enter a valid YouTube URL").optional().or(z.literal('')),
});

type FormData = z.infer<typeof formSchema>;

const categories = [
    { id: 'free', name: 'Free Matches' },
    { id: 'bermuda', name: 'Bermuda' },
    { id: 'clashSquad', name: 'Clash Squad' },
    { id: 'loneWolf', name: 'Lone Wolf' },
] as const;

function ManageCategoryBannersPageContent() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      free: "",
      bermuda: "",
      clashSquad: "",
      loneWolf: "",
    },
  });

  useEffect(() => {
    setLoading(true);
    const unsub = onCategoryBannersUpdate((data) => {
      if (data) {
        form.reset(data);
      }
      setLoading(false);
    });
    return () => unsub();
  }, [form]);
  
  const watchedValues = form.watch();

  const getThumbnailUrl = (url: string | undefined) => {
    if (!url) return 'https://picsum.photos/seed/placeholder/600/400';
    
    let videoId = null;
    try {
        const urlObj = new URL(url);
        if (urlObj.hostname === 'youtu.be') {
            videoId = urlObj.pathname.slice(1);
        } else if (urlObj.hostname === 'www.youtube.com' || urlObj.hostname === 'youtube.com') {
            videoId = urlObj.searchParams.get('v');
        }
    } catch (e) {
        return 'https://picsum.photos/seed/invalid-url/600/400';
    }

    if (!videoId) return 'https://picsum.photos/seed/invalid-url/600/400';
    
    return `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;
  }

  const handleSaveChanges = async (data: FormData) => {
    setSaving(true);
    try {
        await saveCategoryBanners(data);
        toast({ title: "Banners Saved!", description: `All category banners have been updated.`});
    } catch(err) {
        console.error(err);
        toast({ variant: "destructive", title: "Save Failed", description: "Could not save category banner changes." });
    } finally {
        setSaving(false);
    }
  };
  
  if (loading) {
    return <div className="flex justify-center items-center h-screen"><Loader2 className="h-12 w-12 animate-spin text-primary" /></div>;
  }

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="flex flex-col sm:flex-row justify-between items-center mb-8 gap-4">
        <div className="text-center sm:text-left">
            <h1 className="text-4xl md:text-5xl font-headline font-bold">Manage Category Banners</h1>
            <p className="text-muted-foreground mt-3 max-w-2xl">
            Update the banners displayed for each tournament category on the homepage.
            </p>
        </div>
        <div className="flex gap-2">
            <Button onClick={form.handleSubmit(handleSaveChanges)} disabled={saving}>
               {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Save className="mr-2 h-4 w-4"/>}
               Save All Changes
            </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {categories.map((category) => (
          <Card key={category.id}>
              <CardHeader>
                <CardTitle>{category.name}</CardTitle>
                <CardDescription>Set the YouTube URL to generate the banner.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                    <Label htmlFor={category.id}>YouTube Video URL</Label>
                    <Input id={category.id} {...form.register(category.id)} placeholder="e.g., https://www.youtube.com/watch?v=..."/>
                </div>
                <div>
                    <Label>Banner Preview</Label>
                    <div className="aspect-[4/3] relative w-full rounded-lg overflow-hidden border mt-1">
                         <Image src={getThumbnailUrl(watchedValues[category.id])} alt={`${category.name} Banner Preview`} fill className="object-cover" />
                    </div>
                </div>
              </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}


export default function ManageCategoryBannersPage() {
    return (
        <AdminGuard>
            <ManageCategoryBannersPageContent />
        </AdminGuard>
    )
}
