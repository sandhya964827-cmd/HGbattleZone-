
'use server';

import { doc, runTransaction, getFirestore, updateDoc, increment } from 'firebase/firestore';
import { app } from '@/lib/firebase';
import type { UserProfile } from '@/app/profile/page';

const db = getFirestore(app);

interface ApproveRequestParams {
  requestId: string;
  userId: string;
  coinsToAdd: number;
}

export async function approveCoinRequest(params: ApproveRequestParams) {
  const { requestId, userId, coinsToAdd } = params;

  try {
    const userRef = doc(db, 'users', userId);
    const requestRef = doc(db, 'pendingCoinRequests', requestId);

    await runTransaction(db, async (transaction) => {
      const userDoc = await transaction.get(userRef);
      if (!userDoc.exists()) {
        throw new Error("User does not exist!");
      }
      
      // Update user's coin balance using increment
      transaction.update(userRef, { coins: increment(coinsToAdd) });
      
      // Update the request status to 'approved'
      transaction.update(requestRef, { status: 'approved' });
    });
    
    return { success: true };
  } catch (error) {
    console.error("Error approving coin request:", error);
    if (error instanceof Error) {
        return { success: false, error: error.message };
    }
    return { success: false, error: "An unknown error occurred during approval." };
  }
}

export async function declineCoinRequest(requestId: string) {
    try {
        const requestRef = doc(db, 'pendingCoinRequests', requestId);
        await updateDoc(requestRef, { status: 'declined' });
        return { success: true };
    } catch (error) {
        console.error("Error declining coin request:", error);
        return { success: false, error: "Failed to decline the request." };
    }
}
