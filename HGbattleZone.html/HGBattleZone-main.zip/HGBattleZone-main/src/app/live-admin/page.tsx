

"use client";

import { useState, useEffect } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm, useFieldArray, useWatch } from "react-hook-form";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, PlusCircle, Trash2, Youtube, Award, UserPlus, Swords } from "lucide-react";
import { realtimeDB, onTournamentsUpdate, getResultByTournamentId, updateLiveLeaderboard } from "@/lib/firebase";
import { ref, set, push, onValue, remove } from "firebase/database";
import type { LiveMatch, Tournament, TournamentResult, TeamResult, LivePlayer } from "@/lib/types";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import AdminGuard from "@/components/admin-guard";

const playerSchema = z.object({
  name: z.string().min(1, "Player name is required."),
  kills: z.coerce.number().min(0, "Kills can't be negative.").default(0),
  isAlive: z.boolean().default(true),
});

const standingSchema = z.object({
  rank: z.string().min(1, "Rank is required."),
  teamName: z.string().min(1, "Team name is required."),
  players: z.array(playerSchema).optional(),
});

const leaderboardFormSchema = z.object({
  standings: z.array(standingSchema).min(1, "At least one team standing is required."),
});

type LeaderboardFormData = z.infer<typeof leaderboardFormSchema>;

function LeaderboardDialog({ match, onOpenChange }: { match: LiveMatch, onOpenChange: (open: boolean) => void }) {
  const { toast } = useToast();
  const [isSaving, setIsSaving] = useState(false);
  
  const [newTeamName, setNewTeamName] = useState("");
  const [newTeamRank, setNewTeamRank] = useState("");
  const [numPlayersToAdd, setNumPlayersToAdd] = useState(4);
  const [newPlayerNames, setNewPlayerNames] = useState<string[]>(Array(4).fill(''));


  const sortedLeaderboard = (match.leaderboard || []).map(team => ({
    ...team,
    rank: String(team.rank), // Ensure rank is a string for the form
    players: team.players?.map(p => ({
        ...p,
        kills: p.kills || 0 // Ensure kills is a number
    }))
  })).sort((a, b) => {
      const rankA = parseInt(a.rank, 10);
      const rankB = parseInt(b.rank, 10);
      if (!isNaN(rankA) && !isNaN(rankB)) return rankA - rankB;
      if (!isNaN(rankA)) return -1;
      if (!isNaN(rankB)) return 1;
      return 0;
  });

  const form = useForm<LeaderboardFormData>({
    resolver: zodResolver(leaderboardFormSchema),
    defaultValues: {
      standings: sortedLeaderboard.length > 0 ? sortedLeaderboard : [],
    },
  });

  const { fields: teamFields, append: appendTeam, remove: removeTeam } = useFieldArray({
    control: form.control,
    name: "standings",
  });
  
  const handlePlayerCountChange = (value: string) => {
    const count = parseInt(value, 10);
    setNumPlayersToAdd(count);
    setNewPlayerNames(Array(count).fill(''));
  };

  const handlePlayerNameChange = (index: number, name: string) => {
    const updatedNames = [...newPlayerNames];
    updatedNames[index] = name;
    setNewPlayerNames(updatedNames);
  };
  
  const handleAddTeam = () => {
      if (!newTeamName || !newTeamRank) {
          toast({ variant: 'destructive', title: 'Missing Info', description: 'Please fill out Team Name and Rank.' });
          return;
      }
      
      const filledPlayerNames = newPlayerNames.slice(0, numPlayersToAdd).filter(name => name.trim() !== "");
      if (filledPlayerNames.length !== numPlayersToAdd) {
          toast({ variant: 'destructive', title: 'Missing Players', description: `Please enter names for all ${numPlayersToAdd} players.` });
          return;
      }
      
      const newPlayers: LivePlayer[] = filledPlayerNames.map(name => ({ name, kills: 0, isAlive: true }));
      
      appendTeam({
          rank: newTeamRank,
          teamName: newTeamName,
          players: newPlayers,
      }, { shouldFocus: false }); // Prevent auto-scrolling
      
      // Reset input fields
      setNewTeamName("");
      setNewTeamRank("");
      setNumPlayersToAdd(4);
      setNewPlayerNames(Array(4).fill(''));
  };


  async function onLeaderboardSubmit(values: LeaderboardFormData) {
    setIsSaving(true);
    try {
      const sortedStandings = values.standings.sort((a, b) => {
        const rankA = parseInt(a.rank, 10);
        const rankB = parseInt(b.rank, 10);
        if (!isNaN(rankA) && !isNaN(rankB)) return rankA - rankB;
        if (!isNaN(rankA)) return -1;
        if (!isNaN(rankB)) return 1;
        return 0;
      });
      await updateLiveLeaderboard(match.id, sortedStandings);
      toast({
        title: "Leaderboard Updated!",
        description: `The leaderboard for "${match.title}" has been updated live.`,
      });
    } catch (error) {
      console.error("Error updating leaderboard:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update the live leaderboard.",
      });
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <DialogContent className="max-w-4xl">
      <DialogHeader>
        <DialogTitle>Manage Leaderboard for {match.title}</DialogTitle>
        <DialogDescription>
          Add teams and manage player status. Changes will appear live for viewers.
        </DialogDescription>
      </DialogHeader>
      <div className="max-h-[70vh] overflow-y-auto p-1 pr-4">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onLeaderboardSubmit)} className="space-y-6">
            
            <Card className="bg-muted/50">
              <CardHeader>
                <CardTitle className="text-lg">Add New Team</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Input placeholder="Team Name" value={newTeamName} onChange={(e) => setNewTeamName(e.target.value)} />
                  <Input type="text" placeholder="Rank" value={newTeamRank} onChange={(e) => setNewTeamRank(e.target.value)} />
                  <Select onValueChange={handlePlayerCountChange} defaultValue={String(numPlayersToAdd)}>
                    <SelectTrigger>
                        <SelectValue placeholder="Number of players" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="1">1 Player</SelectItem>
                        <SelectItem value="2">2 Players</SelectItem>
                        <SelectItem value="3">3 Players</SelectItem>
                        <SelectItem value="4">4 Players</SelectItem>
                    </SelectContent>
                </Select>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {Array.from({ length: numPlayersToAdd }).map((_, index) => (
                        <Input 
                            key={index}
                            placeholder={`Player ${index + 1} Name`}
                            value={newPlayerNames[index] || ''}
                            onChange={(e) => handlePlayerNameChange(index, e.target.value)}
                        />
                    ))}
                </div>
                <Button type="button" onClick={handleAddTeam} className="w-full">
                  <PlusCircle className="mr-2 h-4 w-4" /> Add Team to Leaderboard
                </Button>
              </CardContent>
            </Card>

            <div>
              <h3 className="text-lg font-medium mb-4">Current Standings</h3>
              <div className="space-y-4">
                {teamFields.map((teamField, teamIndex) => (
                  <TeamField
                    key={teamField.id}
                    teamIndex={teamIndex}
                    control={form.control}
                    removeTeam={removeTeam}
                  />
                ))}
                {teamFields.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">No teams added yet.</p>}
                <FormMessage>{form.formState.errors.standings?.message}</FormMessage>
              </div>
            </div>

            <DialogFooter>
              <DialogClose asChild><Button type="button" variant="outline">Cancel</Button></DialogClose>
              <Button type="submit" disabled={isSaving}>
                {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Award className="mr-2 h-4 w-4" />}
                Save Leaderboard
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </div>
    </DialogContent>
  );
}

function TeamField({ teamIndex, control, removeTeam }: { teamIndex: number; control: any; removeTeam: (index: number) => void; }) {
  const { fields: playerFields } = useFieldArray({
    control,
    name: `standings.${teamIndex}.players`,
  });

  const playersData = useWatch({
    control,
    name: `standings.${teamIndex}.players`,
  });

  const teamKills = (playersData || []).reduce((acc: number, player: { kills: number | string }) => acc + (Number(player.kills) || 0), 0);

  return (
    <div className="p-4 border rounded-lg relative space-y-4">
      <Button type="button" variant="ghost" size="icon" className="absolute top-1 right-1 text-destructive hover:text-destructive" onClick={() => removeTeam(teamIndex)}>
        <Trash2 className="h-4 w-4" />
      </Button>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <FormField control={control} name={`standings.${teamIndex}.rank`} render={({ field }) => ( <FormItem><FormLabel>Rank</FormLabel><FormControl><Input type="text" placeholder="#" {...field} /></FormControl></FormItem>)} />
        <FormField control={control} name={`standings.${teamIndex}.teamName`} render={({ field }) => ( <FormItem><FormLabel>Team Name</FormLabel><FormControl><Input placeholder="e.g., Team Inferno" {...field} /></FormControl></FormItem>)} />
        <FormItem>
          <FormLabel>Total Kills</FormLabel>
          <FormControl>
            <div className="flex h-10 w-full items-center rounded-md border border-input bg-muted px-3 py-2 text-sm">
                <Swords className="h-4 w-4 mr-2 text-muted-foreground"/>
                {teamKills}
            </div>
          </FormControl>
        </FormItem>
      </div>

      <Separator />

      <div>
        <h4 className="text-sm font-medium mb-2">Players ({playerFields.length})</h4>
        <div className="space-y-2">
          {playerFields.map((playerField, playerIndex) => (
            <div key={playerField.id} className="grid grid-cols-[1fr_80px_auto] items-center gap-4 p-2 bg-muted rounded-md">
              <FormField
                control={control}
                name={`standings.${teamIndex}.players.${playerIndex}.name`}
                render={({ field }) => (
                  <FormItem>
                    <FormControl><Input placeholder={`Player ${playerIndex + 1}`} {...field} /></FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={control}
                name={`standings.${teamIndex}.players.${playerIndex}.kills`}
                render={({ field }) => (
                  <FormItem>
                    <FormControl><Input type="number" placeholder="Kills" {...field} /></FormControl>
                  </FormItem>
                )}
              />
              <div className="flex items-center justify-end gap-2">
                 <FormField
                    control={control}
                    name={`standings.${teamIndex}.players.${playerIndex}.isAlive`}
                    render={({ field }) => (
                    <FormItem className="flex items-center space-x-2">
                        <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} id={`is-alive-${teamIndex}-${playerIndex}`} />
                        </FormControl>
                        <FormLabel htmlFor={`is-alive-${teamIndex}-${playerIndex}`} className={field.value ? 'text-green-500' : 'text-red-500'}>
                            {field.value ? "Alive" : "Out"}
                        </FormLabel>
                    </FormItem>
                    )}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}


function LiveAdminPageContent() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [liveMatches, setLiveMatches] = useState<LiveMatch[]>([]);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [openDialogs, setOpenDialogs] = useState<Record<string, boolean>>({});

  const formSchema = z.object({
    title: z.string().min(5, "Match title must be at least 5 characters."),
    youtubeUrl: z.string().url("Please enter a valid YouTube URL."),
    tournamentId: z.string().min(1, "Please link to a tournament."),
  });

  useEffect(() => {
    const liveMatchesRef = ref(realtimeDB, 'liveMatches');
    const unsubLive = onValue(liveMatchesRef, (snapshot) => {
      const data = snapshot.val();
      const loadedMatches = data ? Object.keys(data).map(key => ({ id: key, ...data[key] })) : [];
      setLiveMatches(loadedMatches);
    });

    const unsubTournaments = onTournamentsUpdate(setTournaments);
    
    return () => {
      unsubLive();
      unsubTournaments();
    };
  }, []);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      youtubeUrl: "",
      tournamentId: "",
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    try {
      const liveMatchesRef = ref(realtimeDB, 'liveMatches');
      const newMatchRef = push(liveMatchesRef);

      const existingResult = await getResultByTournamentId(values.tournamentId);

      await set(newMatchRef, {
        title: values.title,
        youtubeUrl: values.youtubeUrl,
        tournamentId: values.tournamentId,
        leaderboard: existingResult ? existingResult.standings.map(team => ({
            ...team,
            players: (team.players || []).map(p => ({ ...p, kills: 0, isAlive: true }))
        })).sort((a,b) => {
          const rankA = parseInt(a.rank, 10);
          const rankB = parseInt(b.rank, 10);
          if (!isNaN(rankA) && !isNaN(rankB)) return rankA - rankB;
          return 0;
        }) : [],
      });
      
      toast({
        title: "Stream Started!",
        description: `"${values.title}" is now live.`,
      });
      form.reset();

    } catch (error) {
       console.error("Error starting stream:", error);
       toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to start the live stream.",
      });
    } finally {
        setIsLoading(false);
    }
  }

  const handleEndStream = async (matchId: string) => {
    try {
        const matchRef = ref(realtimeDB, `liveMatches/${matchId}`);
        await remove(matchRef);
        toast({
            variant: "destructive",
            title: "Stream Ended",
            description: "The live stream has been removed.",
        });
    } catch (error) {
        console.error("Error ending stream:", error);
        toast({
            variant: "destructive",
            title: "Error",
            description: "Could not end the stream.",
        });
    }
  };
  
  const handleOpenChange = (matchId: string, open: boolean) => {
    setOpenDialogs(prev => ({ ...prev, [matchId]: open }));
  };


  return (
    <div className="container mx-auto px-4 py-16">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-headline font-bold">Live Match Control Center</h1>
        <p className="text-muted-foreground mt-3 max-w-2xl mx-auto">
          Start, stop, and manage live streams and leaderboards from here.
        </p>
      </div>

      <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12">
        <div>
            <Card>
                <CardHeader>
                    <CardTitle>Start a New Live Stream</CardTitle>
                    <CardDescription>Enter the match details below to go live.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Form {...form}>
                        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                            <FormField
                                control={form.control}
                                name="title"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>Match Title</FormLabel>
                                    <FormControl>
                                        <Input placeholder="e.g., Grand Finals - Summer Series" {...field} disabled={isLoading} />
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                             <FormField
                                control={form.control}
                                name="youtubeUrl"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>YouTube Stream URL</FormLabel>
                                    <FormControl>
                                        <Input placeholder="https://www.youtube.com/watch?v=..." {...field} disabled={isLoading} />
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="tournamentId"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>Link to Tournament</FormLabel>
                                     <Select onValueChange={field.onChange} value={field.value} disabled={isLoading}>
                                        <FormControl>
                                        <SelectTrigger>
                                            <SelectValue placeholder="Select a tournament for the leaderboard" />
                                        </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                        {tournaments.map(t => (
                                            <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                                        ))}
                                        </SelectContent>
                                    </Select>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <Button type="submit" className="w-full" disabled={isLoading}>
                                {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <PlusCircle className="mr-2 h-4 w-4"/>}
                                {isLoading ? "Starting..." : "Go Live"}
                            </Button>
                        </form>
                    </Form>
                </CardContent>
            </Card>
        </div>
        <div>
            <Card>
                <CardHeader>
                    <CardTitle>Currently Live Streams</CardTitle>
                    <CardDescription>Manage ongoing matches.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {liveMatches.length > 0 ? liveMatches.map(match => (
                            <div key={match.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                                <div className="flex items-center gap-3">
                                     <Youtube className="h-5 w-5 text-destructive" />
                                     <span className="font-medium truncate flex-1">{match.title}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                     <Dialog open={openDialogs[match.id]} onOpenChange={(open) => handleOpenChange(match.id, open)}>
                                        <DialogTrigger asChild>
                                            <Button variant="outline" size="sm">
                                                <Award className="mr-2 h-4 w-4" />
                                                Board
                                            </Button>
                                        </DialogTrigger>
                                        <LeaderboardDialog match={match} onOpenChange={(open) => handleOpenChange(match.id, open)}/>
                                    </Dialog>
                                    <Button variant="destructive" size="sm" onClick={() => handleEndStream(match.id)}>
                                        <Trash2 className="mr-2 h-4 w-4" />
                                        End
                                    </Button>
                                </div>
                            </div>
                        )) : (
                            <p className="text-center text-sm text-muted-foreground py-4">No streams are live.</p>
                        )}
                    </div>
                </CardContent>
            </Card>
        </div>
      </div>
    </div>
  );
}


export default function LiveAdminPage() {
    return (
        <AdminGuard>
            <LiveAdminPageContent />
        </AdminGuard>
    )
}
