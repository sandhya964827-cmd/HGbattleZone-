
"use client";

import { useState, useEffect } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import Autoplay from "embla-carousel-autoplay";
import { onBannersUpdate, onCategoryBannersUpdate, onNoticeBoardUpdate, onSpecialScrimBannersUpdate } from '@/lib/firebase';
import type { Banner, CategoryBanners, Notice, SpecialScrimBanners } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Carousel, CarouselContent, CarouselItem } from '@/components/ui/carousel';
import { Button } from '@/components/ui/button';
import { Megaphone, PlayCircle, ArrowRight } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';


// Helper function to extract YouTube video ID from various URL formats
const getYouTubeVideoId = (url: string | undefined) => {
    if (!url) return null;
    let videoId = null;
    try {
        const urlObj = new URL(url);
        if (urlObj.hostname === 'youtu.be') {
            videoId = urlObj.pathname.slice(1);
        } else if (urlObj.hostname === 'www.youtube.com' || urlObj.hostname === 'youtube.com') {
             if (urlObj.pathname.startsWith('/live/')) {
                 videoId = urlObj.pathname.split('/live/')[1];
            } else if (urlObj.pathname.startsWith('/embed/')) {
                 videoId = urlObj.pathname.split('/embed/')[1];
            }
            else {
                videoId = urlObj.searchParams.get('v');
            }
        }
        // Remove any extra query params from videoId if they exist
        if(videoId && videoId.includes('?')){
            videoId = videoId.split('?')[0];
        }
    } catch (e) {
        console.error("Invalid YouTube URL", e);
        return null;
    }
    return videoId;
};

// Helper to get thumbnail URL
const getThumbnailUrl = (url: string | undefined) => {
  if (!url) return 'https://picsum.photos/seed/placeholder/1280/720';
  const videoId = getYouTubeVideoId(url);
  return videoId ? `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg` : 'https://picsum.photos/seed/invalid-url/1280/720';
};


function HeroCarousel() {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onBannersUpdate((data) => {
      if (data) {
        setBanners(Object.values(data));
      }
      setLoading(false);
    });
    return () => unsub();
  }, []);

  if (loading) {
    return <Skeleton className="w-full aspect-[16/9] rounded-lg" />;
  }

  if (banners.length === 0) {
    return null; // Don't render anything if there are no banners
  }

  return (
    <Carousel
      className="w-full"
      plugins={[Autoplay({ delay: 5000, stopOnInteraction: true })]}
      opts={{ loop: true }}
    >
      <CarouselContent>
        {banners.map((banner) => {
            const backgroundUrl = getThumbnailUrl(banner.videoUrl) || banner.src;
            return (
              <CarouselItem key={banner.id}>
                <div className="relative w-full aspect-[16/9] rounded-lg overflow-hidden">
                  <Image
                    src={backgroundUrl}
                    alt={banner.alt}
                    fill
                    className="object-cover"
                    data-ai-hint={banner.hint}
                  />
                  <div className="absolute bottom-0 left-0 p-6 md:p-12 text-white max-w-2xl">
                    <h1 
                        className="text-3xl md:text-5xl font-headline font-bold"
                        style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.7), 0 0 5px rgba(0,0,0,0.5)' }}
                    >
                        {banner.title}
                    </h1>
                    <p 
                        className="mt-2 text-sm md:text-lg text-white/95"
                        style={{ textShadow: '1px 1px 3px rgba(0,0,0,0.8)' }}
                    >
                        {banner.description}
                    </p>
                  </div>
                </div>
              </CarouselItem>
            )
        })}
      </CarouselContent>
    </Carousel>
  );
}

function TournamentCategories() {
  const [banners, setBanners] = useState<CategoryBanners | null>(null);
  const [loading, setLoading] = useState(true);

   useEffect(() => {
    const unsub = onCategoryBannersUpdate((data) => {
      setBanners(data);
      setLoading(false);
    });
    return () => unsub();
  }, []);
  
  const categories = [
    { name: 'Free Matches', category: 'Free', bannerUrl: banners?.free },
    { name: 'Bermuda', category: 'Bermuda', bannerUrl: banners?.bermuda },
    { name: 'Clash Squad', category: 'Clash Squad', bannerUrl: banners?.clashSquad },
    { name: 'Lone Wolf', category: 'Lone Wolf', bannerUrl: banners?.loneWolf },
  ];

  if (loading) {
      return (
          <div className="grid grid-cols-2 gap-6">
              {[...Array(4)].map((_, i) => (
                  <div key={i} className="space-y-2">
                    <Skeleton className="w-full aspect-[16/9] rounded-xl"/>
                    <Skeleton className="h-6 w-3/4 mx-auto rounded-md" />
                  </div>
              ))}
          </div>
      )
  }

  return (
    <div className="grid grid-cols-2 gap-x-4 gap-y-6">
        {categories.map((item) => (
            <Link key={item.category} href={`/tournaments?category=${item.category}`} className="group">
                 <div className="space-y-3 text-center">
                    <div className="relative aspect-[16/9] w-full rounded-xl overflow-hidden shadow-lg transition-transform duration-300 group-hover:scale-105">
                        <Image
                            src={getThumbnailUrl(item.bannerUrl)}
                            alt={`${item.name} background`}
                            fill
                            className="object-cover"
                            data-ai-hint="esports tournament"
                        />
                    </div>
                    <h3 className="text-white font-headline text-lg font-bold group-hover:text-primary transition-colors">{item.name}</h3>
                </div>
            </Link>
        ))}
    </div>
  )
}

function DailyScrimsCategories() {
  const [banners, setBanners] = useState<SpecialScrimBanners | null>(null);
  const [loading, setLoading] = useState(true);

   useEffect(() => {
    const unsub = onSpecialScrimBannersUpdate((data) => {
      setBanners(data);
      setLoading(false);
    });
    return () => unsub();
  }, []);
  
  const categories = [
    { name: 'Special', category: 'Special', bannerUrl: banners?.special },
    { name: 'Bermuda', category: 'Bermuda', bannerUrl: banners?.bermuda },
    { name: 'Clash Squad', category: 'Clash Squad', bannerUrl: banners?.clashSquad },
    { name: 'Lone Wolf', category: 'Lone Wolf', bannerUrl: banners?.loneWolf },
  ];

  if (loading) {
      return (
          <div className="grid grid-cols-2 gap-6">
              {[...Array(4)].map((_, i) => (
                  <div key={i} className="space-y-2">
                    <Skeleton className="w-full aspect-[16/9] rounded-xl"/>
                    <Skeleton className="h-6 w-3/4 mx-auto rounded-md" />
                  </div>
              ))}
          </div>
      )
  }

  return (
    <div className="grid grid-cols-2 gap-x-4 gap-y-6">
        {categories.map((item) => (
            <Link key={item.category} href={`/tournaments?category=${item.category}`} className="group">
                 <div className="space-y-3 text-center">
                    <div className="relative aspect-[16/9] w-full rounded-xl overflow-hidden shadow-lg transition-transform duration-300 group-hover:scale-105">
                        <Image
                            src={getThumbnailUrl(item.bannerUrl)}
                            alt={`${item.name} background`}
                            fill
                            className="object-cover"
                            data-ai-hint="esports scrims"
                        />
                    </div>
                    <h3 className="text-white font-headline text-lg font-bold group-hover:text-primary transition-colors">{item.name}</h3>
                </div>
            </Link>
        ))}
    </div>
  )
}

function NoticeBoard() {
  const [noticeData, setNoticeData] = useState<{notices: Notice[], footer: string} | null>(null);

  useEffect(() => {
    const unsub = onNoticeBoardUpdate(setNoticeData);
    return () => unsub();
  }, []);

  return (
     <Card className="bg-card/50 backdrop-blur-sm">
        <CardHeader>
            <CardTitle className="flex items-center gap-2">
                <Megaphone className="text-primary"/>
                Notice Board
            </CardTitle>
        </CardHeader>
        <CardContent>
            {noticeData ? (
                <>
                    <ul className="space-y-2 text-muted-foreground list-inside">
                       {noticeData.notices.map(notice => (
                           <li key={notice.id} dangerouslySetInnerHTML={{ __html: `• ${notice.text}`}} className="text-sm" />
                       ))}
                    </ul>
                    <p className="text-xs text-muted-foreground/80 mt-4 border-t pt-4" dangerouslySetInnerHTML={{ __html: noticeData.footer}} />
                </>
            ) : (
                <div className="space-y-3">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-5/6" />
                    <Skeleton className="h-4 w-full" />
                </div>
            )}
        </CardContent>
    </Card>
  )
}

export default function Home() {
  return (
    <main className="min-h-screen space-y-12 py-8 px-4 md:px-8">
      <HeroCarousel />
      
      <div className="text-center">
        <h2 className="text-3xl font-headline font-bold">Choose Your Battleground</h2>
        <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">Select a category to view available tournaments and start competing.</p>
      </div>

       <div className="max-w-4xl mx-auto">
        <NoticeBoard />
      </div>

      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
            <h2 className="text-4xl font-headline font-bold">Tournaments</h2>
            <p className="text-muted-foreground mt-2">Find your next challenge. Choose a category to begin.</p>
        </div>
        <TournamentCategories/>
      </div>

       <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
            <h2 className="text-4xl font-headline font-bold">MEDIAM PRICE TOURNAMENT</h2>
            <p className="text-muted-foreground mt-2">Compete in tournaments with a medium entry fee for bigger prizes.</p>
        </div>
        <DailyScrimsCategories/>
      </div>
    </main>
  );
}
