
"use client";

import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Send, Youtube, ThumbsUp, Heart, Hand, Flame, Award, Users, Skull, ChevronDown, Swords, ShieldCheck } from "lucide-react";
import { realtimeDB, getUserProfile } from "@/lib/firebase";
import { ref, onValue, push, serverTimestamp, query, orderByChild } from "firebase/database";
import type { LiveMatch, TeamResult, LiveComment, LivePlayer } from "@/lib/types";
import type { UserProfile } from "@/app/profile/page";
import Image from "next/image";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/context/auth-context";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";


function EliminationFeed({ eliminatedPlayer }: { eliminatedPlayer: string | null }) {
    const audioRef = useRef<HTMLAudioElement>(null);

    useEffect(() => {
        if (eliminatedPlayer) {
            // Play sound but catch any errors if autoplay is blocked by the browser.
            audioRef.current?.play().catch(error => {
                console.log("Audio autoplay was prevented for elimination sound.", error);
            });
        }
    }, [eliminatedPlayer]);
    
    // Always render the audio tag so it's available, but hidden.
    const audio = <audio ref={audioRef} src="/sounds/elimination.mp3" preload="auto" className="hidden" />;

    if (!eliminatedPlayer) {
        return audio;
    }

    return (
        <>
            {audio}
            <div className="absolute top-4 left-1/2 -translate-x-1/2 z-20">
                <div className="animate-fade-in-out bg-destructive/80 backdrop-blur-sm text-destructive-foreground font-bold p-3 rounded-lg shadow-lg flex items-center gap-2">
                    <Skull className="h-5 w-5" />
                    <span>{eliminatedPlayer} has been eliminated!</span>
                </div>
            </div>
        </>
    );
}


export default function LiveMatchPage() {
  const [liveMatches, setLiveMatches] = useState<LiveMatch[]>([]);
  const [selectedMatch, setSelectedMatch] = useState<LiveMatch | null>(null);
  const [loading, setLoading] = useState(true);
  
  const [eliminatedPlayer, setEliminatedPlayer] = useState<string | null>(null);
  const previousPlayersRef = useRef<Map<string, LivePlayer>>(new Map());

  
  useEffect(() => {
    const liveMatchesRef = ref(realtimeDB, 'liveMatches');

    const unsubscribe = onValue(liveMatchesRef, (snapshot) => {
      const data = snapshot.val();
      const matchesList: LiveMatch[] = data ? Object.keys(data).map(key => ({ id: key, ...data[key] })) : [];
      setLiveMatches(matchesList);

      // If a match is currently selected, update its data in real-time
      if (selectedMatch) {
          const updatedSelectedMatch = matchesList.find(match => match.id === selectedMatch.id);
          if (updatedSelectedMatch) {
              setSelectedMatch(updatedSelectedMatch);
          } else {
              // The selected match was removed
              setSelectedMatch(null);
          }
      }
      
      setLoading(false);
    }, (error) => {
      console.error("Error fetching live data:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [selectedMatch]);


  useEffect(() => {
    if (!selectedMatch?.leaderboard) {
        // Reset when there's no selected match or leaderboard
        previousPlayersRef.current.clear();
        return;
    }

    const currentPlayers = new Map<string, LivePlayer>();
    selectedMatch.leaderboard.forEach(team => {
        team.players?.forEach(player => {
            currentPlayers.set(player.name, player);
        });
    });

    // Find the eliminated player
    let newlyEliminatedPlayerName: string | null = null;
    for (const [playerName, prevPlayer] of previousPlayersRef.current.entries()) {
        const currentPlayer = currentPlayers.get(playerName);
        // If the player was alive before but is not anymore (or doesn't exist)
        if (prevPlayer.isAlive && (!currentPlayer || !currentPlayer.isAlive)) {
            newlyEliminatedPlayerName = playerName;
            break; // Found one, break the loop
        }
    }

    // Update the previous state for the next render
    previousPlayersRef.current = currentPlayers;

    if (newlyEliminatedPlayerName) {
        setEliminatedPlayer(newlyEliminatedPlayerName);
        // Clear the message after a few seconds
        setTimeout(() => {
            setEliminatedPlayer(null);
        }, 3500); // Should match the animation duration in globals.css
    }
}, [selectedMatch?.leaderboard]);


  const getYouTubeVideoId = (url: string | null) => {
    if (!url) return null;
    let videoId = null;
    try {
        const urlObj = new URL(url);
        if (urlObj.hostname === 'youtu.be') {
            videoId = urlObj.pathname.slice(1);
        } else if (urlObj.hostname === 'www.youtube.com' || urlObj.hostname === 'youtube.com') {
            if (urlObj.pathname.startsWith('/live/')) {
                 videoId = urlObj.pathname.split('/live/')[1];
            } else if (urlObj.pathname.startsWith('/embed/')) {
                 videoId = urlObj.pathname.split('/embed/')[1];
            }
            else {
                videoId = urlObj.searchParams.get('v');
            }
        }
        // Remove any extra query params from videoId if they exist
        if(videoId && videoId.includes('?')){
            videoId = videoId.split('?')[0];
        }
    } catch (e) {
        console.error("Invalid YouTube URL", e);
        return null;
    }
    return videoId;
  };

  const getEmbedUrl = (videoId: string | null) => {
    if (!videoId) return null;
    return `https://www.youtube.com/embed/${videoId}?autoplay=1`;
  };

  const getThumbnailUrl = (videoId: string | null) => {
    if (!videoId) return 'https://picsum.photos/seed/placeholder/1280/720';
    return `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;
  }

  const renderLoadingSkeleton = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {[...Array(3)].map((_, i) => (
        <Card key={i}>
          <CardContent className="p-0">
            <Skeleton className="aspect-video w-full" />
          </CardContent>
          <CardHeader>
            <Skeleton className="h-6 w-3/4" />
          </CardHeader>
        </Card>
      ))}
    </div>
  );

  const renderMatchSelector = () => (
    <div className="max-w-6xl mx-auto">
        {loading ? (
            renderLoadingSkeleton()
        ) : liveMatches.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {liveMatches.map((match) => {
                    const videoId = getYouTubeVideoId(match.youtubeUrl);
                    return (
                        <Card key={match.id} onClick={() => setSelectedMatch(match)} className="cursor-pointer hover:shadow-primary/30 hover:shadow-lg transition-shadow overflow-hidden">
                             <CardContent className="p-0">
                                <div className="aspect-video w-full relative">
                                    <Image 
                                        src={getThumbnailUrl(videoId)} 
                                        alt={match.title || "Live match thumbnail"}
                                        fill
                                        className="object-cover"
                                        data-ai-hint="youtube thumbnail"
                                    />
                                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                                        <Youtube className="h-16 w-16 text-white/80"/>
                                    </div>
                                </div>
                            </CardContent>
                            <CardHeader>
                                <CardTitle className="font-headline text-lg h-12">{match.title}</CardTitle>
                            </CardHeader>
                        </Card>
                    )
                })}
            </div>
        ) : (
            <div className="text-center py-16 bg-card rounded-lg">
                <p className="text-muted-foreground">No matches are currently live.</p>
                <p className="text-sm text-muted-foreground mt-2">Check back later for more action!</p>
            </div>
        )}
    </div>
  );

  const renderSelectedMatch = () => {
    if (!selectedMatch) return null;
    const videoId = getYouTubeVideoId(selectedMatch.youtubeUrl);
    const embedUrl = getEmbedUrl(videoId);
    
    const leaderboardData = (selectedMatch.leaderboard || []).map(team => {
        const playersAlive = (team.players || []).filter(p => p.isAlive).length;
        const totalKills = (team.players || []).reduce((acc, p) => acc + (p.kills || 0), 0);
        const totalPlayers = (team.players || []).length;
        const isEliminated = playersAlive === 0 && totalPlayers > 0;
        return { ...team, playersAlive, totalPlayers, totalKills, isEliminated };
    }).sort((a, b) => {
        const rankA = parseInt(a.rank, 10);
        const rankB = parseInt(b.rank, 10);
        if (!isNaN(rankA) && !isNaN(rankB)) return rankA - rankB;
        if (!isNaN(rankA)) return -1;
        if (!isNaN(rankB)) return 1;
        return 0;
    });

    return (
        <div className="max-w-4xl mx-auto relative">
            <EliminationFeed eliminatedPlayer={eliminatedPlayer} />
            <Button variant="outline" onClick={() => setSelectedMatch(null)} className="mb-4">
                <ArrowLeft className="mr-2 h-4 w-4" /> Back to list
            </Button>
            
            <Card className="overflow-hidden">
                 <CardHeader>
                    <CardTitle className="text-2xl font-headline">{selectedMatch.title}</CardTitle>
                 </CardHeader>
                 <CardContent>
                     <div className="aspect-video bg-black rounded-lg flex items-center justify-center text-muted-foreground overflow-hidden">
                        {embedUrl ? (
                            <iframe 
                                width="100%" 
                                height="100%" 
                                src={embedUrl}
                                title="YouTube video player" 
                                frameBorder="0" 
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
                                allowFullScreen
                            ></iframe>
                        ) : (
                            <p>Could not load YouTube video. Invalid URL.</p>
                        )}
                    </div>
                 </CardContent>
            </Card>

            <Card className="mt-6">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Award className="h-5 w-5 text-primary" />
                      Live Leaderboard
                    </CardTitle>
                    <CardDescription>Match standings are updated in real-time. Click on a team to see player details.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="border rounded-lg max-h-[70vh] overflow-auto">
                      <Accordion type="single" collapsible className="w-full">
                        {leaderboardData.length > 0 ? (
                            leaderboardData.map((team, index) => (
                                <AccordionItem value={`team-${index}`} key={team.teamName} className={cn({ 'bg-red-900/20': team.isEliminated })}>
                                    <AccordionTrigger className="px-4 py-3 hover:no-underline">
                                        <div className="flex items-center justify-between w-full">
                                            <div className="flex items-center gap-4">
                                                <div className={cn("font-bold text-lg w-12 text-center", {
                                                    'text-yellow-400': team.rank === '1' && !team.isEliminated,
                                                    'text-gray-400': team.rank === '2' && !team.isEliminated,
                                                    'text-amber-600': team.rank === '3' && !team.isEliminated,
                                                    'text-red-500': team.isEliminated
                                                })}>
                                                    {team.isEliminated ? 'OUT' : `#${team.rank}`}
                                                </div>
                                                <div className="font-semibold text-left">{team.teamName}</div>
                                            </div>
                                            <div className="flex items-center gap-6 text-sm">
                                                <div className="flex items-center gap-1.5" title="Total Kills">
                                                    <Swords className="h-4 w-4 text-red-500"/>
                                                    <span className="font-bold">{team.totalKills}</span>
                                                </div>
                                                <div className="flex items-center gap-1.5" title="Players Alive">
                                                    <Users className="h-4 w-4"/>
                                                    <span className="font-bold">{team.playersAlive}/{team.totalPlayers}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </AccordionTrigger>
                                    <AccordionContent className="bg-background/40">
                                        <div className="px-4 py-3 border-t border-border">
                                            <div className="grid grid-cols-3 gap-2 text-xs text-muted-foreground mb-2 px-2">
                                                <span>Player</span>
                                                <span className="text-center">Kills</span>
                                                <span className="text-right">Status</span>
                                            </div>
                                            <div className="space-y-1">
                                                {(team.players || []).map((player, pIndex) => (
                                                    <div key={pIndex} className="grid grid-cols-3 gap-2 items-center text-sm p-2 rounded-md bg-muted/50">
                                                        <span className="truncate">{player.name}</span>
                                                        <div className="flex items-center justify-center gap-1">
                                                           <Flame className="h-3 w-3 text-red-500"/>
                                                           <span>{player.kills || 0}</span>
                                                        </div>
                                                        <div className={cn("text-right font-semibold flex items-center justify-end gap-1.5", player.isAlive ? "text-green-400" : "text-red-500")}>
                                                           {player.isAlive ? "Alive" : "Eliminated"}
                                                           {player.isAlive ? <ShieldCheck className="h-4 w-4"/> : <Skull className="h-4 w-4"/>}
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    </AccordionContent>
                                </AccordionItem>
                            ))
                        ) : (
                            <div className="text-center py-10 text-muted-foreground">
                                Leaderboard has not been updated yet.
                            </div>
                        )}
                        </Accordion>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-headline font-bold">Live Matches</h1>
        <p className="text-muted-foreground mt-3 max-w-2xl mx-auto">
          Watch the action unfold in real-time. Select a match to start watching.
        </p>
      </div>
      {selectedMatch ? renderSelectedMatch() : renderMatchSelector()}
    </div>
  );
}

