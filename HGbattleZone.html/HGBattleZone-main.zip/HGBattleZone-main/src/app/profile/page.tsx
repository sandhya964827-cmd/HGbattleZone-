

"use client";

import { useState, useEffect } from "react";
import dynamic from 'next/dynamic';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { getAdminCredentials, getUserProfile } from "@/lib/firebase";
import { useAuth } from "@/context/auth-context";
import { Skeleton } from "@/components/ui/skeleton";
import type { Timestamp } from "firebase/firestore";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import EditProfileForm from "@/components/edit-profile-form";
import UploadPhotoDialog from "@/components/upload-photo-dialog";
import { KeyRound, Mail, ScrollText, ChevronRight, Gamepad2, Copy, Camera, ShieldCheck, LogOut, Loader2, Crown, Gift } from "lucide-react";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Input } from "@/components/ui/input";
import { useRouter } from "next/navigation";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import BadgeAnimation from "@/components/badge-animation";


// Dynamically import IdCard with SSR disabled
const IdCard = dynamic(() => import('@/components/id-card'), { ssr: false });

export type UserProfile = {
    uid: string;
    firstName: string;
    lastName: string;
    username: string;
    email: string;
    mobileNumber: string;
    photoURL?: string | null;
    registrationNumber?: number;
    tournamentRegId?: number;
    createdAt: Timestamp | Date; // Can be a Timestamp from Firestore or a Date object
    gender: 'Male' | 'Female' | 'Other';
    playStyle?: 'Rusher' | 'Sniper' | 'Support' | 'IGL';
    badgeText?: string | null;
    coins?: number;
}

export default function ProfilePage() {
  const { user, loading: authLoading, isAdmin, loginAsAdmin, logoutAdmin } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loadingProfile, setLoadingProfile] = useState(true);
  const [showBadgeAnimation, setShowBadgeAnimation] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isPhotoUploadOpen, setIsPhotoUploadOpen] = useState(false);
  const { toast } = useToast();
  const router = useRouter();
  
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [isAdminLoginOpen, setIsAdminLoginOpen] = useState(false);


  const fetchUserProfile = async () => {
    if (user) {
      setLoadingProfile(true);
      const userProfileData = await getUserProfile(user.uid);
      if (userProfileData) {
        const loadedProfile = userProfileData as UserProfile;
        setProfile(loadedProfile);
        // Trigger animation if the user has a badge
        if (loadedProfile.badgeText) {
          setShowBadgeAnimation(true);
        }
      }
      setLoadingProfile(false);
    } else if (!authLoading) {
      setLoadingProfile(false);
    }
  };

  useEffect(() => {
    fetchUserProfile();
  }, [user, authLoading]);

  const handleUpdateSuccess = async () => {
    setIsEditDialogOpen(false);
    await fetchUserProfile(); // Re-fetch data to show updates
  };

  const handlePhotoUploadSuccess = async (newPhotoURL: string) => {
    // Optimistically update the profile state with the new URL
    if (profile) {
        setProfile({ ...profile, photoURL: newPhotoURL });
    }
    setIsPhotoUploadOpen(false);
  };


  const handleCopy = (text: string | number | undefined, type: string) => {
    if (!text) return;
    navigator.clipboard.writeText(String(text)).then(() => {
      toast({
        title: "Copied!",
        description: `${type} copied to clipboard.`,
      });
    });
  };

  const handleAdminLogin = async () => {
    setIsVerifying(true);
    try {
        const correctCreds = await getAdminCredentials();
        if (adminEmail === correctCreds.email && adminPassword === correctCreds.password) {
            loginAsAdmin();
            toast({
                title: "Admin Access Granted",
                description: "Redirecting to admin dashboard...",
            });
            setIsAdminLoginOpen(false);
            router.push('/admin/dashboard'); // Redirect to dashboard
        } else {
             toast({
                variant: "destructive",
                title: "Incorrect Credentials",
                description: "The admin email or password you entered is wrong.",
            });
        }
    } catch(e) {
        console.error(e);
        toast({ variant: "destructive", title: "Error", description: "Could not verify admin credentials."});
    } finally {
        setIsVerifying(false);
        setAdminPassword("");
        setAdminEmail("");
    }
  }

  const handleAdminLogout = () => {
      logoutAdmin();
      toast({
          title: "Admin Access Revoked",
          description: "You are no longer in admin mode.",
      });
  }

  if (profile && profile.badgeText && showBadgeAnimation) {
    return <BadgeAnimation badgeText={profile.badgeText} onAnimationEnd={() => setShowBadgeAnimation(false)} />;
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <Card>
          <CardHeader className="items-center text-center pt-12">
            {loadingProfile || authLoading ? (
                 <>
                    <Skeleton className="h-24 w-24 rounded-full mb-4" />
                    <Skeleton className="h-7 w-40 mb-2" />
                    <Skeleton className="h-4 w-32" />
                </>
            ) : profile ? (
                <>
                <div className="relative w-fit">
                    <Avatar className="h-24 w-24 mb-4 border-2 border-primary">
                        <AvatarImage src={profile.photoURL || undefined} alt={profile.username} />
                        <AvatarFallback>{profile.username?.[0].toUpperCase()}</AvatarFallback>
                    </Avatar>
                     <Dialog open={isPhotoUploadOpen} onOpenChange={setIsPhotoUploadOpen}>
                        <DialogTrigger asChild>
                            <Button variant="ghost" size="icon" className="absolute bottom-4 right-0 bg-background/50 backdrop-blur-sm rounded-full h-8 w-8">
                                <Camera className="h-4 w-4"/>
                                <span className="sr-only">Change photo</span>
                            </Button>
                        </DialogTrigger>
                        <DialogContent>
                            <UploadPhotoDialog 
                              onUploadSuccess={handlePhotoUploadSuccess} 
                              onDialogClose={() => setIsPhotoUploadOpen(false)}
                            />
                        </DialogContent>
                    </Dialog>
                </div>
                 <div className="flex items-center gap-2">
                    <CardTitle className="text-2xl font-headline">{profile.username}</CardTitle>
                    {profile.badgeText && (
                        <TooltipProvider>
                        <Tooltip>
                            <TooltipTrigger>
                            <div className="flex items-center justify-center h-6 w-6 bg-amber-950 rounded-full border-2 border-amber-400 animate-pulse-glow">
                                    <span className="font-bold text-sm text-amber-400">{profile.badgeText}</span>
                                </div>
                            </TooltipTrigger>
                            <TooltipContent>
                            <p>Verified Player</p>
                            </TooltipContent>
                        </Tooltip>
                        </TooltipProvider>
                    )}
                 </div>
                <div className="flex items-center gap-2">
                    <CardDescription>User ID: {profile.uid}</CardDescription>
                     <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => handleCopy(profile.uid, 'User ID')}>
                        <Copy className="h-4 w-4"/>
                        <span className="sr-only">Copy User ID</span>
                    </Button>
                </div>
                </>
            ) : (
                 <p>Could not load profile.</p>
            )}
            
          </CardHeader>
          <CardContent className="px-6 pb-6">
             {loadingProfile || authLoading ? (
                 <div className="space-y-4 text-sm sm:text-base">
                    <div className="grid grid-cols-3 gap-2 items-center">
                        <span className="font-semibold text-muted-foreground col-span-1">Full Name:</span>
                        <Skeleton className="h-5 w-48" />
                    </div>
                     <div className="grid grid-cols-3 gap-2 items-center">
                        <span className="font-semibold text-muted-foreground col-span-1">Email:</span>
                         <Skeleton className="h-5 w-56" />
                    </div>
                     <div className="grid grid-cols-3 gap-2 items-center">
                        <span className="font-semibold text-muted-foreground col-span-1">Mobile:</span>
                         <Skeleton className="h-5 w-32" />
                    </div>
                     <div className="grid grid-cols-3 gap-2 items-center">
                        <span className="font-semibold text-muted-foreground col-span-1">Play Style:</span>
                         <Skeleton className="h-5 w-24" />
                    </div>
                 </div>
             ) : profile && (
                 <>
                    <div className="space-y-4 text-sm sm:text-base">
                        <div className="grid grid-cols-3 gap-2 items-center">
                            <span className="font-semibold text-muted-foreground col-span-1">Full Name:</span>
                            <span className="col-span-2">{profile.firstName} {profile.lastName}</span>
                        </div>
                        <div className="grid grid-cols-3 gap-2 items-center">
                            <span className="font-semibold text-muted-foreground col-span-1">Email:</span>
                            <span className="col-span-2">{profile.email}</span>
                        </div>
                        <div className="grid grid-cols-3 gap-2 items-center">
                            <span className="font-semibold text-muted-foreground col-span-1">Mobile:</span>
                            <span className="col-span-2">{profile.mobileNumber}</span>
                        </div>
                        <div className="grid grid-cols-3 gap-2 items-center">
                            <span className="font-semibold text-muted-foreground col-span-1">Tournament ID:</span>
                            <div className="col-span-2 flex items-center gap-2">
                                <span>{profile.tournamentRegId}</span>
                                 <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => handleCopy(profile.tournamentRegId, 'Tournament ID')}>
                                    <Copy className="h-4 w-4"/>
                                    <span className="sr-only">Copy Tournament ID</span>
                                </Button>
                            </div>
                        </div>
                         <div className="grid grid-cols-3 gap-2 items-center">
                            <span className="font-semibold text-muted-foreground col-span-1">Play Style:</span>
                            <span className="col-span-2">
                                {profile.playStyle ? (
                                    <Badge variant="outline" className="flex items-center gap-1 w-fit">
                                        <Gamepad2 className="h-3 w-3"/>
                                        {profile.playStyle}
                                    </Badge>
                                ) : "Not set"}
                            </span>
                        </div>
                    </div>
                    <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                      <DialogTrigger asChild>
                         <Button variant="outline" className="w-full max-w-sm mx-auto mt-6 block">Edit Profile</Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Edit Your Profile</DialogTitle>
                          <DialogDescription>
                            Update your personal details below.
                          </DialogDescription>
                        </DialogHeader>
                        <EditProfileForm profile={profile} onUpdateSuccess={handleUpdateSuccess} />
                      </DialogContent>
                    </Dialog>
                 </>
             )}
          </CardContent>
        </Card>

        <div className="my-8 grid grid-cols-1 gap-4">
            <Card className="hover:bg-muted/50 transition-colors">
              <Link href="/change-password" className="block w-full h-full">
                <CardContent className="p-4 flex items-center">
                  <KeyRound className="h-6 w-6 mr-4 text-primary" />
                  <div className="flex-grow">
                    <h3 className="font-semibold">Change Password</h3>
                    <p className="text-sm text-muted-foreground">Update your login password for security.</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-muted-foreground" />
                </CardContent>
              </Link>
            </Card>

            <Card className="hover:bg-muted/50 transition-colors">
              <Link href="/contact" className="block w-full h-full">
                <CardContent className="p-4 flex items-center">
                  <Mail className="h-6 w-6 mr-4 text-primary" />
                  <div className="flex-grow">
                    <h3 className="font-semibold">Contact Us</h3>
                    <p className="text-sm text-muted-foreground">Get in touch with our support team.</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-muted-foreground" />
                </CardContent>
              </Link>
            </Card>

            <Card className="hover:bg-muted/50 transition-colors">
              <Link href="/rules" className="block w-full h-full">
                <CardContent className="p-4 flex items-center">
                  <ScrollText className="h-6 w-6 mr-4 text-primary" />
                  <div className="flex-grow">
                    <h3 className="font-semibold">Rules &amp; Regulations</h3>
                    <p className="text-sm text-muted-foreground">Read the tournament and community guidelines.</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-muted-foreground" />
                </CardContent>
              </Link>
            </Card>
            
            {(profile?.badgeText === 'H' || profile?.badgeText === 'A') && (
              <AlertDialog open={isAdminLoginOpen} onOpenChange={setIsAdminLoginOpen}>
                  <Card className="hover:bg-muted/50 transition-colors cursor-pointer">
                      {isAdmin ? (
                          <div className="p-4 flex items-center" onClick={handleAdminLogout}>
                              <LogOut className="h-6 w-6 mr-4 text-destructive" />
                              <div className="flex-grow">
                                  <h3 className="font-semibold">Admin Logout</h3>
                                  <p className="text-sm text-muted-foreground">Log out of the admin session.</p>
                              </div>
                              <ChevronRight className="h-5 w-5 text-muted-foreground" />
                          </div>
                      ) : (
                          <AlertDialogTrigger asChild>
                            <div className="p-4 flex items-center">
                                  <ShieldCheck className="h-6 w-6 mr-4 text-primary" />
                                  <div className="flex-grow">
                                      <h3 className="font-semibold">Admin Login</h3>
                                      <p className="text-sm text-muted-foreground">Access admin functionalities.</p>
                                  </div>
                                  <ChevronRight className="h-5 w-5 text-muted-foreground" />
                              </div>
                          </AlertDialogTrigger>
                      )}
                  </Card>
                  <AlertDialogContent>
                      <AlertDialogHeader>
                          <AlertDialogTitle>Admin Verification</AlertDialogTitle>
                          <AlertDialogDescription>
                              Please enter the admin credentials to access restricted functionalities.
                          </AlertDialogDescription>
                      </AlertDialogHeader>
                      <div className="space-y-4">
                          <Input
                              type="email"
                              placeholder="Admin Email"
                              value={adminEmail}
                              onChange={(e) => setAdminEmail(e.target.value)}
                              disabled={isVerifying}
                          />
                          <Input
                              type="password"
                              placeholder="Admin Password"
                              value={adminPassword}
                              onChange={(e) => setAdminPassword(e.target.value)}
                              onKeyDown={(e) => e.key === 'Enter' && handleAdminLogin()}
                              disabled={isVerifying}
                          />
                      </div>
                      <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={handleAdminLogin} disabled={isVerifying}>
                              {isVerifying ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                              Verify
                          </AlertDialogAction>
                      </AlertDialogFooter>
                  </AlertDialogContent>
              </AlertDialog>
            )}
        </div>
        
        {/* Render ID Card if profile is loaded and user has a badge */}
        {profile && profile.badgeText && <IdCard profile={profile} />}

      </div>
    </div>
  );
}

    