

"use client";

import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { onBannersUpdate, saveAllBanners, deleteBanner, uploadBanner } from "@/lib/firebase";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, PlusCircle, Trash2, Upload, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import Image from "next/image";
import AdminGuard from "@/components/admin-guard";

type Banner = {
  id: string;
  src: string;
  alt: string;
  hint: string;
  title: string;
  description: string;
  videoUrl?: string;
};

const bannerSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  hint: z.string().min(1, "Image hint is required"),
  alt: z.string().min(1, "Image alt text is required"),
  videoUrl: z.string().optional(),
  file: z.any().optional(),
});

type BannerFormData = z.infer<typeof bannerSchema>;

function ManageBannersPageContent() {
  const [banners, setBanners] = useState<Record<string, Banner>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState<Record<string, boolean>>({});
  const { toast } = useToast();

  useEffect(() => {
    const unsub = onBannersUpdate((data) => {
      setBanners(data || {});
      setLoading(false);
    });
    return () => unsub();
  }, []);
  
  const getYouTubeVideoId = (url: string | undefined) => {
    if (!url) return null;
    let videoId = null;
    try {
        const urlObj = new URL(url);
        if (urlObj.hostname === 'youtu.be') {
            videoId = urlObj.pathname.slice(1);
        } else if (urlObj.hostname === 'www.youtube.com' || urlObj.hostname === 'youtube.com') {
             if (urlObj.pathname.startsWith('/live/')) {
                 videoId = urlObj.pathname.split('/live/')[1];
            } else if (urlObj.pathname.startsWith('/embed/')) {
                 videoId = urlObj.pathname.split('/embed/')[1];
            }
            else {
                videoId = urlObj.searchParams.get('v');
            }
        }
        if(videoId && videoId.includes('?')){
            videoId = videoId.split('?')[0];
        }
    } catch (e) {
        console.error("Invalid YouTube URL", e);
        return null;
    }
    return videoId;
  };
  
  const getThumbnailUrl = (url: string | undefined) => {
    if (!url) return null;
    const videoId = getYouTubeVideoId(url);
    if (!videoId) return null;
    return `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;
  }


  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>, bannerId: string) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploading(prev => ({...prev, [bannerId]: true}));
      try {
        const url = await uploadBanner(file, bannerId);
        setBanners(prev => ({
          ...prev,
          [bannerId]: { ...prev[bannerId], src: url }
        }));
        toast({ title: "Image Uploaded", description: "The new banner image is ready. Click 'Save Changes' to apply." });
      } catch (err) {
        console.error(err);
        toast({ variant: "destructive", title: "Upload Failed", description: "Could not upload the image." });
      } finally {
        setUploading(prev => ({...prev, [bannerId]: false}));
      }
    }
  };

  const handleUpdateBannerField = (bannerId: string, field: keyof Banner, value: string) => {
    setBanners(prev => ({
      ...prev,
      [bannerId]: { ...prev[bannerId], [field]: value }
    }));
  };

  const handleSaveChanges = async () => {
    setSaving(true);
    try {
        await saveAllBanners(banners);
        toast({ title: "Banners Saved!", description: `All changes have been saved.`});
    } catch(err) {
        console.error(err);
        toast({ variant: "destructive", title: "Save Failed", description: "Could not save banner changes." });
    } finally {
        setSaving(false);
    }
  };
  
  const handleAddNewBanner = () => {
    const newId = `banner${Date.now()}`;
    const newBanner: Banner = {
      id: newId,
      src: "https://picsum.photos/seed/new-banner/1920/1080",
      alt: "New Banner",
      hint: "esports action",
      title: "New Promotion",
      description: "Exciting new event coming soon!",
      videoUrl: "",
    };
    setBanners(prev => ({ ...prev, [newId]: newBanner }));
    toast({ title: "New Banner Added", description: "A new banner draft has been added. Click 'Save All Changes' to finalize." });
  }
  
  const handleDeleteBanner = (bannerId: string) => {
    const { [bannerId]: _, ...remainingBanners } = banners;
    setBanners(remainingBanners);
    toast({ variant: "destructive", title: "Banner Removed", description: "The banner draft has been removed. Click 'Save All Changes' to finalize." });
  }

  if (loading) {
    return <div className="flex justify-center items-center h-screen"><Loader2 className="h-12 w-12 animate-spin text-primary" /></div>;
  }

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="flex flex-col sm:flex-row justify-between items-center mb-8 gap-4">
        <div className="text-center sm:text-left">
            <h1 className="text-4xl md:text-5xl font-headline font-bold">Manage Banners</h1>
            <p className="text-muted-foreground mt-3 max-w-2xl">
            Add, edit, or remove the banners displayed on the homepage carousel.
            </p>
        </div>
        <div className="flex gap-2">
            <Button onClick={handleAddNewBanner}>
                <PlusCircle className="mr-2"/> Add New Banner
            </Button>
            <Button onClick={handleSaveChanges} disabled={saving}>
               {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Save className="mr-2 h-4 w-4"/>}
               Save All Changes
            </Button>
        </div>
      </div>

      <div className="space-y-8">
        {Object.keys(banners).length === 0 && (
          <Card className="text-center py-12">
            <CardContent>
              <p className="text-muted-foreground">No banners found. Click "Add New Banner" to get started.</p>
            </CardContent>
          </Card>
        )}
        {Object.values(banners).map((banner) => {
          const bannerImageUrl = getThumbnailUrl(banner.videoUrl) || banner.src;
          
          return (
          <Card key={banner.id}>
              <CardHeader>
                <div className="flex justify-between items-center">
                    <CardTitle>{banner.title || "New Banner"}</CardTitle>
                    <Button type="button" variant="destructive" size="sm" onClick={() => handleDeleteBanner(banner.id)}>
                        <Trash2 className="mr-2 h-4 w-4"/> Delete
                    </Button>
                </div>
                <CardDescription>ID: {banner.id}</CardDescription>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
                <div className="space-y-6">
                    <div>
                        <label htmlFor={`title-${banner.id}`} className="block text-sm font-medium mb-1">Title</label>
                        <Input id={`title-${banner.id}`} value={banner.title} onChange={(e) => handleUpdateBannerField(banner.id, 'title', e.target.value)} />
                    </div>
                    <div>
                        <label htmlFor={`description-${banner.id}`} className="block text-sm font-medium mb-1">Description</label>
                        <Textarea id={`description-${banner.id}`} value={banner.description} onChange={(e) => handleUpdateBannerField(banner.id, 'description', e.target.value)} />
                    </div>
                    <div>
                        <label htmlFor={`videoUrl-${banner.id}`} className="block text-sm font-medium mb-1">YouTube Video URL (Optional)</label>
                        <Input id={`videoUrl-${banner.id}`} value={banner.videoUrl} onChange={(e) => handleUpdateBannerField(banner.id, 'videoUrl', e.target.value)} placeholder="e.g., https://www.youtube.com/watch?v=..."/>
                    </div>
                    <div>
                        <label htmlFor={`alt-${banner.id}`} className="block text-sm font-medium mb-1">Image Alt Text (if no video)</label>
                         <Input id={`alt-${banner.id}`} value={banner.alt} onChange={(e) => handleUpdateBannerField(banner.id, 'alt', e.target.value)} />
                    </div>
                    <div>
                        <label htmlFor={`hint-${banner.id}`} className="block text-sm font-medium mb-1">Image AI Hint (if no video)</label>
                        <Input id={`hint-${banner.id}`} value={banner.hint} onChange={(e) => handleUpdateBannerField(banner.id, 'hint', e.target.value)} />
                    </div>
                </div>
                <div className="space-y-4">
                    <p className="text-sm font-medium">Banner Preview</p>
                    <div className="aspect-video relative w-full rounded-lg overflow-hidden border">
                         <Image src={bannerImageUrl} alt={banner.alt} fill className="object-cover" />
                         {(uploading[banner.id]) && (
                            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                                <Loader2 className="h-8 w-8 animate-spin text-white" />
                            </div>
                         )}
                    </div>
                    <div>
                        <label htmlFor={`file-${banner.id}`} className="block text-sm font-medium mb-1">Upload New Image (Fallback)</label>
                        <div className="flex items-center gap-2">
                             <Input id={`file-${banner.id}`} type="file" accept="image/*" className="flex-grow" onChange={(e) => handleFileChange(e, banner.id)} />
                        </div>
                    </div>
                </div>
              </CardContent>
          </Card>
          )}
        )}
      </div>
    </div>
  );
}


export default function ManageBannersPage() {
    return (
        <AdminGuard>
            <ManageBannersPageContent />
        </AdminGuard>
    )
}
