
"use client";

import { useState, useEffect, useMemo } from 'react';
import { onTournamentsUpdate, onRegistrationsUpdate } from '@/lib/firebase';
import type { Tournament, TournamentRegistration } from '@/lib/types';
import { Users, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useParams, useRouter } from 'next/navigation';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';


export default function TournamentPlayersPage() {
  const params = useParams();
  const tournamentId = params.tournamentId as string;
  const router = useRouter();
  const [tournament, setTournament] = useState<Tournament | null>(null);
  const [registrations, setRegistrations] = useState<TournamentRegistration[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!tournamentId) return;

    setLoading(true);
    const unsubTournaments = onTournamentsUpdate((allTournaments) => {
        const currentTournament = allTournaments.find(t => t.id === tournamentId);
        setTournament(currentTournament || null);
    });

    const unsubRegistrations = onRegistrationsUpdate(tournamentId, (regs) => {
      setRegistrations(regs);
      setLoading(false); // Stop loading once we have registrations (or an empty list)
    });
    
    return () => {
      unsubTournaments();
      unsubRegistrations();
    };
  }, [tournamentId]);

  const playersPerTeam = useMemo(() => {
    if (!tournament) return 1;
    switch (tournament.mode) {
      case 'Duo': return 2;
      case 'Squad': return 4;
      default: return 1;
    }
  }, [tournament]);

  const totalPlayersRegistered = registrations.reduce((acc, reg) => acc + reg.players.length, 0);
  const totalPlayerSlots = (tournament?.slots || 0) * playersPerTeam;
  const isEnoughPlayers = totalPlayersRegistered >= playersPerTeam;
  const totalTeams = tournament?.slots || 48; // Default to 48 teams

  const registrationMap = useMemo(() => {
    const map = new Map<number, TournamentRegistration>();
    registrations.forEach(reg => {
      if (reg.slotNumber) {
        map.set(reg.slotNumber, reg);
      }
    });
    return map;
  }, [registrations]);


  const renderSkeletons = () => (
    <div className="grid grid-cols-2 gap-x-6 gap-y-4">
      {Array.from({ length: totalTeams }).map((_, index) => {
         const teamNumber = index + 1;
         return (
             <div key={teamNumber} className="flex gap-3 items-start">
              <Skeleton className="w-8 h-full rounded-md bg-gray-700" />
              <div className="flex-1 space-y-1.5">
                {Array.from({ length: playersPerTeam }).map((_, playerIndex) => (
                  <Skeleton key={playerIndex} className="bg-gray-700 rounded-md h-9 w-full" />
                ))}
              </div>
            </div>
        )
      })}
    </div>
  );
  

  return (
    <div className="bg-background min-h-screen text-foreground p-4 font-sans">
      <div className="flex justify-between items-center mb-4 sticky top-0 bg-background py-2 z-10 border-b border-border">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <div className="flex items-center gap-2 text-lg font-bold">
          <Users className="h-5 w-5" />
          <span>{totalPlayersRegistered}/{totalPlayerSlots}</span>
        </div>
        <div className="text-lg font-bold uppercase text-muted-foreground">
          {isEnoughPlayers ? `ENOUGH PLAYERS` : `NOT ENOUGH PLAYERS`}
        </div>
        <div></div> {/* Empty div for spacing */}
      </div>

      {loading ? renderSkeletons() : (
        <div className="grid grid-cols-2 gap-x-6 gap-y-4">
          {Array.from({ length: totalTeams }).map((_, index) => {
            const teamNumber = index + 1;
            const reg = registrationMap.get(teamNumber);

            return (
              <div key={teamNumber} className="flex gap-3 items-start">
                <div className="w-8 flex-shrink-0 h-full flex items-center justify-center bg-gray-800/50 border border-gray-700/50 rounded-md font-bold text-lg text-gray-100 py-2">
                  {teamNumber}
                </div>
                <div className="flex-1 space-y-1.5">
                  {Array.from({ length: playersPerTeam }).map((_, playerIndex) => {
                    const player = reg?.players?.[playerIndex];
                    return (
                      <div key={playerIndex} className="bg-gray-800/50 border border-gray-700/50 rounded-md h-9 flex items-center justify-between px-3">
                        <p className="text-sm font-medium truncate text-gray-100">{player?.gameName || ''}</p>
                        {player?.badgeText && (
                            <div className={cn(
                                "flex items-center justify-center h-5 w-5 bg-amber-950 rounded-full border border-amber-400 animate-pulse-glow flex-shrink-0"
                            )}>
                                <span className="font-bold text-sm text-amber-400">{player.badgeText}</span>
                            </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
