
"use client";

import Image from "next/image";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { CircleDollarSign, Eye, Loader2, Award, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState, useEffect, Suspense, useMemo } from "react";
import { onTournamentsUpdate, getUserProfile, onRegistrationsUpdate as onAllRegistrationsUpdateForTournament, addRegistration, updateRegistration, deleteRegistration } from "@/lib/firebase";
import { useSearchParams, useRouter } from "next/navigation";
import type { Tournament, TournamentRegistration, PlayerRegistration } from "@/lib/types";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/context/auth-context";
import type { UserProfile } from "@/app/profile/page";
import { Logo } from "@/components/icons";
import Link from 'next/link';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import TournamentRegistrationForm from "@/components/tournament-registration-form";
import { useToast } from "@/hooks/use-toast";

function TournamentsComponent() {
  const searchParams = useSearchParams();
  const categoryFilter = searchParams.get('category');
  const { user } = useAuth();
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);

  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [loading, setLoading] = useState(true);
  const [registrations, setRegistrations] = useState<Record<string, TournamentRegistration[]>>({});
  const [statusFilter, setStatusFilter] = useState('upcoming');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  
  const [openRegistrationDialog, setOpenRegistrationDialog] = useState<Record<string, boolean>>({});

  useEffect(() => {
    setLoading(true);
    const unsubTournaments = onTournamentsUpdate((tournamentsData) => {
      setTournaments(tournamentsData);
      setLoading(false);
    });

    return () => unsubTournaments();
  }, []);

  useEffect(() => {
    if (tournaments.length > 0) {
      // For each tournament, set up a listener for its registrations
      const unsubscribers = tournaments.map(t => {
        return onAllRegistrationsUpdateForTournament(t.id, (regs) => {
          setRegistrations(prev => ({ ...prev, [t.id]: regs }));
        });
      });

      return () => {
        unsubscribers.forEach(unsub => unsub());
      };
    }
  }, [tournaments]);

  useEffect(() => {
    async function fetchProfile() {
      if (user) {
        const profile = await getUserProfile(user.uid);
        setUserProfile(profile as UserProfile);
      }
    }
    fetchProfile();
  }, [user]);

  const handleRegistrationSubmit = async (values: Omit<TournamentRegistration, 'id' | 'tournamentId' | 'uid' | 'date'>, tournamentId: string, entryFee: number) => {
      if (!user || !userProfile) {
        toast({ variant: 'destructive', title: 'Not Logged In', description: 'You must be logged in to register.' });
        return;
      }

      if ((userProfile.coins || 0) < entryFee) {
        toast({
          variant: 'destructive',
          title: 'Insufficient Coins',
          description: `You need ${entryFee} coins to register, but you only have ${userProfile.coins || 0}. Please add more coins.`,
        });
        return;
      }

      setIsSubmitting(true);
      try {
        await addRegistration({
          ...values,
          tournamentId: tournamentId,
          date: new Date(),
          uid: user.uid,
        }, entryFee);

        toast({ title: 'Registration Successful!', description: `Your squad "${values.squadName}" is registered and ${entryFee} coins have been deducted.` });
        setOpenRegistrationDialog(prev => ({...prev, [tournamentId]: false}));
      } catch (error) {
         console.error(error);
         toast({ variant: 'destructive', title: 'Registration Failed', description: error instanceof Error ? error.message : 'Could not complete registration.' });
      } finally {
        setIsSubmitting(false);
      }
  };


  const categoryFilteredTournaments = tournaments.filter(t => 
    !categoryFilter || t.category === categoryFilter
  );

  const finalFilteredTournaments = categoryFilteredTournaments.filter(t => {
    const isUserRegisteredInThisTournament = user ? (registrations[t.id] || []).some(reg => reg.uid === user.uid) : false;

    switch (statusFilter) {
        case 'upcoming':
            return t.status === 'Upcoming';
        case 'ongoing':
            // Show only if user is registered
            return t.status === 'Ongoing' && isUserRegisteredInThisTournament;
        case 'result':
            // Show only if user is registered
            return t.status === 'Completed' && isUserRegisteredInThisTournament;
        default:
            return true;
    }
  });


  const pageTitles: { [key: string]: string } = {
    'Free': "Free Matches",
    'Bermuda': "Bermuda Tournaments",
    'Clash Squad': "Clash Squad Battles",
    'Lone Wolf': "Lone Wolf Challenges",
  };
  
  const currentPageTitle = categoryFilter ? pageTitles[categoryFilter] : "All Tournaments";
  const currentPageDescription = categoryFilter 
    ? `Browse all available tournaments in the ${categoryFilter} category.`
    : "Browse all available tournaments and register your team to compete.";


  return (
    <div className="container mx-auto px-4 py-16">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-headline font-bold">
          {currentPageTitle}
        </h1>
        <p className="text-muted-foreground mt-3 max-w-2xl mx-auto">
          {currentPageDescription}
        </p>
      </div>

        <Tabs defaultValue="upcoming" onValueChange={setStatusFilter} className="w-full mb-8">
            <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
                <TabsTrigger value="ongoing">Ongoing</TabsTrigger>
                <TabsTrigger value="result">Result</TabsTrigger>
            </TabsList>
        </Tabs>
        
         {loading ? (
            <div className="flex justify-center items-center h-64">
                <Loader2 className="h-12 w-12 animate-spin text-primary" />
            </div>
        ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {finalFilteredTournaments.length > 0 ? finalFilteredTournaments.map((tournament) => {
                    const regsForTournament = registrations[tournament.id] || [];
                    const registeredSlots = regsForTournament.map(reg => reg.slotNumber);
                    const currentRegisteredCount = regsForTournament.length;
                    const isFull = currentRegisteredCount >= tournament.slots;
                    const registrationPercentage = (currentRegisteredCount / tournament.slots) * 100;
                    const isUserRegistered = user ? regsForTournament.some(reg => reg.uid === user.uid) : false;

                    return (
                      <Card key={tournament.id} className="bg-white text-black p-4 flex flex-col gap-4 rounded-lg shadow-md">
                        {/* Header */}
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-black rounded-full flex items-center justify-center">
                              <Logo className="h-6 w-6 text-white"/>
                          </div>
                          <div className="flex-grow">
                              <h3 className="font-bold text-base leading-tight">{tournament.name}</h3>
                              <p className="text-xs text-gray-500">{tournament.date}</p>
                          </div>
                        </div>
                        
                        {/* Details Grid */}
                        <div className="grid grid-cols-3 gap-4 text-center">
                            <div className="space-y-1">
                              <p className="text-xs text-gray-500 uppercase">Prize Pool</p>
                               <p className="font-bold text-sm flex items-center justify-center gap-1">
                                <CircleDollarSign className="w-4 h-4 text-yellow-500"/>
                                {tournament.prizePool}
                               </p>
                            </div>
                            <div className="space-y-1">
                               <p className="text-xs text-gray-500 uppercase">Per Kill</p>
                               <p className="font-bold text-sm flex items-center justify-center gap-1">
                                  <CircleDollarSign className="w-4 h-4 text-yellow-500"/>
                                  5 
                               </p>
                            </div>
                            <div className="space-y-1">
                               <p className="text-xs text-gray-500 uppercase">Entry Fee</p>
                               <p className="font-bold text-sm flex items-center justify-center gap-1">
                                <CircleDollarSign className="w-4 h-4 text-yellow-500"/>
                                {tournament.entryFee > 0 ? `${tournament.entryFee} coins` : 'Free'}
                              </p>
                            </div>
                             <div className="space-y-1">
                               <p className="text-xs text-gray-500 uppercase">Type</p>
                               <p className="font-bold text-sm">{tournament.mode}</p>
                            </div>
                             <div className="space-y-1">
                               <p className="text-xs text-gray-500 uppercase">Version</p>
                               <p className="font-bold text-sm">TPP</p>
                            </div>
                             <div className="space-y-1">
                               <p className="text-xs text-gray-500 uppercase">Map</p>
                               <p className="font-bold text-sm flex items-center justify-center gap-1">
                                <MapPin className="w-4 h-4"/>
                                {tournament.map}
                               </p>
                            </div>
                        </div>
                        
                        { statusFilter !== 'result' && (
                          <>
                            <div className="space-y-1">
                              <Progress value={registrationPercentage} className="h-2 bg-gray-200" />
                              <div className="flex justify-between items-center">
                                  <p className="text-xs text-gray-500">
                                    {isFull ? "Registration Full" : `${tournament.slots - currentRegisteredCount} spots left`}
                                  </p>
                                  <p className="text-xs font-mono text-gray-500">{currentRegisteredCount}/{tournament.slots}</p>
                              </div>
                            </div>

                            <div className="flex items-center gap-2 mt-auto">
                              <Dialog open={openRegistrationDialog[tournament.id]} onOpenChange={(isOpen) => setOpenRegistrationDialog(prev => ({...prev, [tournament.id]: isOpen}))}>
                                <DialogTrigger asChild>
                                  <Button
                                      className="w-full font-bold bg-primary/10 text-primary hover:bg-primary hover:text-white transition-colors"
                                      disabled={tournament.status !== "Upcoming" || isFull || isUserRegistered}
                                  >
                                      {isUserRegistered ? "Registered" : (isFull ? "Full" : "Join")}
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="max-w-xl">
                                    <DialogHeader>
                                        <DialogTitle>Register for {tournament.name}</DialogTitle>
                                        <DialogDescription>
                                            Fill in your team details to compete. The entry fee is {tournament.entryFee} coins. You need {tournament.mode === 'Squad' ? 4 : tournament.mode === 'Duo' ? 2 : 1} players.
                                        </DialogDescription>
                                    </DialogHeader>
                                    <TournamentRegistrationForm 
                                        tournament={tournament}
                                        userProfile={userProfile}
                                        onRegistrationSuccess={(values) => handleRegistrationSubmit(values, tournament.id, tournament.entryFee)}
                                        registeredSlots={registeredSlots}
                                    />
                                </DialogContent>
                              </Dialog>

                              <Button asChild
                                  className="w-full font-bold bg-primary/10 text-primary hover:bg-green-500 hover:text-white transition-colors"
                              >
                                  <Link href={`/tournaments/${tournament.id}/players`}>
                                    <Eye className="mr-2 h-4 w-4"/> View
                                  </Link>
                              </Button>
                            </div>
                          </>
                        )}
                        { statusFilter === 'result' && (
                           <Button asChild
                              className="w-full font-bold bg-blue-500/10 text-blue-600 hover:bg-blue-500 hover:text-white transition-colors mt-auto"
                            >
                              <Link href={`/results/${tournament.id}`}>
                                <Award className="mr-2 h-4 w-4"/> View Result
                              </Link>
                            </Button>
                        )}
                      </Card>
                    )
                }) : (
                <div className="col-span-full text-center py-16 bg-card rounded-lg">
                    <p className="text-muted-foreground">No tournaments found for this category and status.</p>
                    <p className="text-sm text-muted-foreground mt-2">Check back later or try another filter!</p>
                </div>
                )}
            </div>
        )}
    </div>
  );
}

export default function TournamentsPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <TournamentsComponent />
    </Suspense>
  );
}
