
import {
    Accordion,
    AccordionContent,
    AccordionItem,
    AccordionTrigger,
} from "@/components/ui/accordion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function RulesPage() {
    return (
        <div className="container mx-auto px-4 py-16">
            <div className="text-center mb-12">
                <h1 className="text-4xl md:text-5xl font-headline font-bold">नियम और विनियम</h1>
                <p className="text-muted-foreground mt-3 max-w-2xl mx-auto">
                    एक निष्पक्ष और प्रतिस्पर्धी माहौल सुनिश्चित करने के लिए सभी खिलाड़ियों को इन नियमों का पालन करना आवश्यक है।
                </p>
            </div>

            <div className="max-w-4xl mx-auto">
                <Card>
                    <CardHeader>
                        <CardTitle>टूर्नामेंट दिशानिर्देश</CardTitle>
                        <CardDescription>कृपया खेलने से पहले सभी नियमों को ध्यान से पढ़ें।</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Accordion type="single" collapsible className="w-full">
                            <AccordionItem value="item-1">
                                <AccordionTrigger className="text-lg font-semibold">1. सामान्य आचार संहिता</AccordionTrigger>
                                <AccordionContent className="space-y-2 text-muted-foreground">
                                    <p>• सभी खिलाड़ियों से अपेक्षा की जाती है कि वे अन्य खिलाड़ियों, आयोजकों और स्टाफ के प्रति सम्मानजनक व्यवहार करें।</p>
                                    <p>• किसी भी प्रकार की गाली-गलौज, उत्पीड़न, नस्लवाद या भेदभावपूर्ण भाषा का प्रयोग सख्त वर्जित है।</p>
                                    <p>• किसी भी खिलाड़ी या टीम का नाम आपत्तिजनक या अपमानजनक नहीं होना चाहिए।</p>
                                </AccordionContent>
                            </AccordionItem>
                            <AccordionItem value="item-2">
                                <AccordionTrigger className="text-lg font-semibold">2. निष्पक्ष खेल (Fair Play)</AccordionTrigger>
                                <AccordionContent className="space-y-2 text-muted-foreground">
                                    <p>• किसी भी प्रकार के हैक, स्क्रिप्ट, या थर्ड-पार्टी सॉफ्टवेयर का उपयोग जो गेमप्ले को अनुचित लाभ पहुंचाता है, पूरी तरह से प्रतिबंधित है।</p>
                                    <p>• गेम के बग्स या ग्लिच का जानबूझकर फायदा उठाना (Exploiting) मना है।</p>
                                    <p>• टीमों के बीच मैच फिक्सिंग या किसी भी तरह की मिलीभगत की अनुमति नहीं है।</p>
                                    <p>• पकड़े जाने पर टीम को तुरंत अयोग्य घोषित कर दिया जाएगा और भविष्य के टूर्नामेंटों से प्रतिबंधित किया जा सकता है।</p>
                                </AccordionContent>
                            </AccordionItem>
                            <AccordionItem value="item-3">
                                <AccordionTrigger className="text-lg font-semibold">3. पंजीकरण और टीम</AccordionTrigger>
                                <AccordionContent className="space-y-2 text-muted-foreground">
                                    <p>• पंजीकरण की अंतिम तिथि से पहले सभी खिलाड़ियों को अपनी टीम को पंजीकृत करना होगा।</p>
                                    <p>• टीम में खिलाड़ियों की संख्या टूर्नामेंट के मोड (Solo, Duo, Squad) के अनुसार होनी चाहिए।</p>
                                    <p>• एक खिलाड़ी एक ही टूर्नामेंट में एक से अधिक टीम के लिए नहीं खेल सकता है।</p>
                                    <p>• रजिस्ट्रेशन के दौरान प्रदान की गई सभी जानकारी (जैसे Game UID) सही होनी चाहिए। गलत जानकारी देने पर टीम को अयोग्य घोषित किया जा सकता है।</p>
                                </AccordionContent>
                            </AccordionItem>
                             <AccordionItem value="item-4">
                                <AccordionTrigger className="text-lg font-semibold">4. मैच प्रक्रिया</AccordionTrigger>
                                <AccordionContent className="space-y-2 text-muted-foreground">
                                    <p>• मैच का रूम आईडी और पासवर्ड मैच शुरू होने से 10-15 मिनट पहले ऐप में प्रदान किया जाएगा।</p>
                                    <p>• सभी टीमों को निर्धारित समय पर लॉबी में शामिल होना अनिवार्य है। देर से आने वाली टीमों को खेलने की अनुमति नहीं दी जाएगी।</p>
                                    <p>• तकनीकी समस्याओं (जैसे डिस्कनेक्शन) के मामले में, मैच को फिर से शुरू नहीं किया जाएगा जब तक कि आयोजकों द्वारा अन्यथा निर्णय न लिया जाए।</p>
                                </AccordionContent>
                            </AccordionItem>
                             <AccordionItem value="item-5">
                                <AccordionTrigger className="text-lg font-semibold">5. निर्णय और दंड</AccordionTrigger>
                                <AccordionContent className="space-y-2 text-muted-foreground">
                                    <p>• किसी भी नियम के उल्लंघन पर टीम को चेतावनी, पॉइंट कटौती या टूर्नामेंट से तत्काल अयोग्यता का सामना करना पड़ सकता है।</p>
                                    <p>• सभी विवादों और नियमों की व्याख्या पर आयोजकों का निर्णय अंतिम और बाध्यकारी होगा।</p>
                                    <p>• आयोजक किसी भी समय नियमों को संशोधित करने का अधिकार सुरक्षित रखते हैं।</p>
                                </AccordionContent>
                            </AccordionItem>
                        </Accordion>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
