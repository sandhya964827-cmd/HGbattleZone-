
import { NextResponse } from 'next/server';
import Razorpay from 'razorpay';
import shortid from 'shortid';

// Initialize razorpay
// Next.js automatically loads environment variables from .env.local, .env.development, etc.
// No need for dotenv.config()
const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
});

export async function POST(req: Request) {
  const body = await req.json();

  if (!body.amount || !body.userId || !body.coins) {
    return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
  }

  const payment_capture = 1;
  const amount = body.amount;
  const currency = 'INR';

  const options = {
    amount: (amount * 100).toString(),
    currency,
    receipt: `receipt_${shortid.generate()}`,
    payment_capture,
    notes: {
        userId: body.userId,
        coins: body.coins,
    }
  };

  try {
    const response = await razorpay.orders.create(options);
    return NextResponse.json({
      keyId: process.env.RAZORPAY_KEY_ID,
      order: response,
    });
  } catch (error) {
    console.error('Razorpay order creation failed:', error);
    const errorMessage = error instanceof Error ? error.message : 'Failed to create order';
    return NextResponse.json({ error: errorMessage }, { status: 500 });
  }
}
