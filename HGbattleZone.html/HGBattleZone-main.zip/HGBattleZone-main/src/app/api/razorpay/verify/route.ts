
import { NextResponse } from 'next/server';
import crypto from 'crypto';
import { doc, getFirestore, runTransaction, increment } from 'firebase/firestore';
import { app } from '@/lib/firebase';

const db = getFirestore(app);

export async function POST(req: Request) {
  const { 
    razorpay_order_id, 
    razorpay_payment_id, 
    razorpay_signature,
    userId,
    coins
  } = await req.json();
  
  if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature || !userId || !coins) {
    return NextResponse.json({ error: 'Missing required fields for verification' }, { status: 400 });
  }

  const body = razorpay_order_id + "|" + razorpay_payment_id;

  const expectedSignature = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET!)
    .update(body.toString())
    .digest('hex');

  const isAuthentic = expectedSignature === razorpay_signature;

  if (isAuthentic) {
    // Payment is authentic, now credit coins to user
    try {
        const userRef = doc(db, 'users', userId);
        
        await runTransaction(db, async (transaction) => {
            const userDoc = await transaction.get(userRef);
            if (!userDoc.exists()) {
                throw new Error("User does not exist!");
            }
            
            // Use increment to safely add coins
            transaction.update(userRef, { coins: increment(coins) });
        });

        // Optionally, you could also save the payment details in a 'payments' collection here
        
        return NextResponse.json({ success: true, message: "Payment verified successfully" });

    } catch (error) {
        console.error("Failed to credit coins:", error);
        return NextResponse.json({ success: false, error: 'Failed to update user coin balance.' }, { status: 500 });
    }

  } else {
    return NextResponse.json({ success: false, error: 'Invalid signature' }, { status: 400 });
  }
}
