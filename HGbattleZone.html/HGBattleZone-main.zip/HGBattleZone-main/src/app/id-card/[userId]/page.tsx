
import { getUserProfile } from "@/lib/firebase";
import IdCard from "@/components/id-card";
import type { UserProfile } from "@/app/profile/page";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Terminal } from "lucide-react";

interface PublicIdCardPageProps {
  params: {
    userId: string;
  };
}

export default async function PublicIdCardPage({ params }: PublicIdCardPageProps) {
  const { userId } = params;
  const profile = (await getUserProfile(userId)) as UserProfile | null;

  if (!profile) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-100 dark:bg-gray-900">
        <Alert variant="destructive" className="max-w-md">
            <Terminal className="h-4 w-4" />
            <AlertTitle>Error: User Not Found</AlertTitle>
            <AlertDescription>
                The user ID you are looking for does not exist or the profile could not be loaded.
            </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center h-screen bg-gray-100 dark:bg-gray-900">
      {/* We pass `isPublicView` to hide the download button */}
      <IdCard profile={profile} isPublicView={true} />
    </div>
  );
}
