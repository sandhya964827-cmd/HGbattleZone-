
// This layout ensures that the public ID card page doesn't have the main header/footer.
export default function IdCardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <section>
        {children}
    </section>
  );
}
