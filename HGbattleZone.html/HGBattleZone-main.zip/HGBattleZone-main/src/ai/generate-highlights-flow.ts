
'use server';
/**
 * @fileOverview An AI agent for generating exciting summaries of Free Fire tournament results.
 *
 * - generateHighlights - A function that takes tournament results and generates a narrative summary.
 * - GenerateHighlightsInput - The input type for the generateHighlights function.
 * - GenerateHighlightsOutput - The return type for the generateHighlights function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const StandingSchema = z.object({
  rank: z.number(),
  teamName: z.string(),
  kills: z.number(),
  prize: z.string().optional(),
});

const GenerateHighlightsInputSchema = z.object({
  tournamentName: z.string().describe('The name of the tournament.'),
  standings: z
    .array(StandingSchema)
    .describe('An array of the final team standings, sorted by rank.'),
});

export type GenerateHighlightsInput = z.infer<
  typeof GenerateHighlightsInputSchema
>;

const GenerateHighlightsOutputSchema = z.object({
  highlights: z
    .string()
    .describe(
      'An exciting, narrative summary of the tournament results, written in an engaging and dramatic style suitable for social media or news announcements. It should be in Hindi.'
    ),
});

export type GenerateHighlightsOutput = z.infer<
  typeof GenerateHighlightsOutputSchema
>;

export async function generateHighlights(
  input: GenerateHighlightsInput
): Promise<GenerateHighlightsOutput> {
  return generateHighlightsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateHighlightsPrompt',
  input: {schema: GenerateHighlightsInputSchema},
  output: {schema: GenerateHighlightsOutputSchema},
  prompt: `You are a professional esports commentator for Free Fire tournaments. Your task is to generate an exciting and dramatic summary of a finished tournament in Hindi, based on the results provided. Make it sound thrilling, like a real match report.

  - Announce the winner dramatically.
  - Mention the top 2-3 teams.
  - Highlight any player/team with a very high number of kills.
  - Keep the language engaging and use esports-related slang if appropriate.

  Tournament Name: {{{tournamentName}}}

  Final Standings:
  {{#each standings}}
  - Rank {{rank}}: {{teamName}} ({{kills}} kills{{#if prize}}, Prize: {{prize}}{{/if}})
  {{/each}}

  Generate the highlights summary based on this data.`,
});

const generateHighlightsFlow = ai.defineFlow(
  {
    name: 'generateHighlightsFlow',
    inputSchema: GenerateHighlightsInputSchema,
    outputSchema: GenerateHighlightsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
