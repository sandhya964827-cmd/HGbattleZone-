'use server';
// This file can be used for development-specific AI configurations.
// The .env file is automatically loaded by Next.js in development,
// so `dotenv.config()` is not needed here.
