// src/ai/ai-team-formation.ts
'use server';

/**
 * @fileOverview An AI agent for suggesting potential Free Fire teammates.
 *
 * - suggestTeammates - A function that suggests teammates based on player skill, style and availability.
 * - SuggestTeammatesInput - The input type for the suggestTeammates function.
 * - SuggestTeammatesOutput - The return type for the suggestTeammates function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestTeammatesInputSchema = z.object({
  skillLevel: z
    .string()
    .describe('The player skill level (e.g., beginner, intermediate, advanced).'),
  playStyle: z
    .string()
    .describe(
      'The player play style (e.g., aggressive, defensive, strategic, support).'
    ),
  availability: z
    .string()
    .describe('The player availability (e.g., evenings, weekends, weekdays).'),
  pastPerformance: z
    .string()
    .optional()
    .describe(
      'A description of the player past performance in previous tournaments.'
    ),
  teamSize: z
    .number()
    .default(4)
    .describe('The size of the team (e.g. 4 for squad).'),
});

export type SuggestTeammatesInput = z.infer<typeof SuggestTeammatesInputSchema>;

const SuggestTeammatesOutputSchema = z.object({
  suggestedTeammates: z
    .array(z.string())
    .describe(
      'A list of potential teammates, including their Free Fire ID, a short description of their skills and playstyle, and their contact information.'
    ),
  reasoning: z
    .string()
    .optional()
    .describe('The reasoning behind the teammate suggestions.'),
});

export type SuggestTeammatesOutput = z.infer<typeof SuggestTeammatesOutputSchema>;

export async function suggestTeammates(
  input: SuggestTeammatesInput
): Promise<SuggestTeammatesOutput> {
  return suggestTeammatesFlow(input);
}

const prompt = ai.definePrompt({
  name: 'suggestTeammatesPrompt',
  input: {schema: SuggestTeammatesInputSchema},
  output: {schema: SuggestTeammatesOutputSchema},
  prompt: `You are an AI assistant designed to suggest potential teammates for Free Fire tournaments.

  Given the player's skill level, play style, and availability, suggest a list of teammates that would be a good fit.
  Take into account the team size, trying to fulfill the team with the right number of players.
  Consider past performance of the player when possible.

  Player Skill Level: {{{skillLevel}}}
  Player Play Style: {{{playStyle}}}
  Player Availability: {{{availability}}}
  Player Past Performance: {{{pastPerformance}}}
  Team Size: {{{teamSize}}}

  Suggested Teammates:`,
});

const suggestTeammatesFlow = ai.defineFlow(
  {
    name: 'suggestTeammatesFlow',
    inputSchema: SuggestTeammatesInputSchema,
    outputSchema: SuggestTeammatesOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
