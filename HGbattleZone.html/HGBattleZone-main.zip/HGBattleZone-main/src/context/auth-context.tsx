
"use client";

import { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth, getUserProfile } from '@/lib/firebase';

interface AuthContextType {
  isLoggedIn: boolean;
  user: User | null;
  loading: boolean;
  isAdmin: boolean;
  login: () => void; 
  logout: () => void;
  loginAsAdmin: () => void;
  logoutAdmin: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        // When user logs in, immediately check and backfill their profile if needed
        await getUserProfile(currentUser.uid);
      }
      setUser(currentUser);
      setLoading(false);
      // Reset admin status on user change
      setIsAdmin(false); 
      sessionStorage.removeItem('isAdmin');
    });

    // Cleanup subscription on unmount
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    // Check session storage on initial load to maintain admin state
    const storedIsAdmin = sessionStorage.getItem('isAdmin');
    if (storedIsAdmin === 'true') {
      setIsAdmin(true);
    }
  }, []);


  const login = () => {
    if(auth.currentUser) setUser(auth.currentUser);
  };

  const logout = () => {
    setUser(null);
    logoutAdmin(); // Also log out from admin
  };

  const loginAsAdmin = () => {
    setIsAdmin(true);
    sessionStorage.setItem('isAdmin', 'true');
  }

  const logoutAdmin = () => {
    setIsAdmin(false);
    sessionStorage.removeItem('isAdmin');
  }

  const isLoggedIn = !!user;
  const value = { isLoggedIn, user, loading, login, logout, isAdmin, loginAsAdmin, logoutAdmin };

  // The main loader is now in the AuthGuard, so the provider can render its children.
  // This allows the router to access the path and AuthGuard to perform redirects.
  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

    