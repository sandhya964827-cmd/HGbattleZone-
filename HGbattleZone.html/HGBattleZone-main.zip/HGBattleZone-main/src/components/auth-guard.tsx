
"use client";

import { useAuth } from '@/context/auth-context';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';

const publicPaths = ['/login', '/signup', '/upload-photo'];

export default function AuthGuard({ children }: { children: React.ReactNode }) {
  const { user, isLoggedIn, loading: authLoading } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const [isNavigating, setIsNavigating] = useState(true);

  useEffect(() => {
    if (authLoading) {
      return; // Wait for Firebase auth to initialize
    }

    const pathIsPublic = publicPaths.includes(pathname);

    if (!isLoggedIn && !pathIsPublic) {
      router.push('/login');
    } else if (isLoggedIn && pathIsPublic) {
      router.push('/');
    } else {
      setIsNavigating(false); // We are on the correct page, no navigation needed
    }
  }, [isLoggedIn, authLoading, pathname, router]);

  if (authLoading || isNavigating) {
    // Show a loader while checking auth state or navigating
    return (
        <div className="flex items-center justify-center h-screen w-full">
            <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
    );
  }
  
  // After checks, render the page content
  return <>{children}</>;
}
