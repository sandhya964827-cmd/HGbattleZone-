
"use client";

import { useEffect, useRef } from 'react';

interface BadgeAnimationProps {
  badgeText: string;
  onAnimationEnd: () => void;
}

export default function BadgeAnimation({ badgeText, onAnimationEnd }: BadgeAnimationProps) {
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    // Play sound but catch any errors if autoplay is blocked by the browser.
    audioRef.current?.play().catch(error => {
      console.log("Audio autoplay was prevented by the browser. This is expected behavior.", error);
    });

    // Set a timer to end the animation and show the profile page.
    const timer = setTimeout(() => {
      onAnimationEnd();
    }, 3500); // This duration should match the animation duration.

    return () => clearTimeout(timer);
  }, [onAnimationEnd]);

  return (
    <div className="fixed inset-0 bg-background/90 backdrop-blur-sm flex items-center justify-center z-50 animate-fade-in-out">
      <div className="flex flex-col items-center justify-center space-y-4">
        <div 
          className="flex items-center justify-center h-24 w-24 bg-amber-950 rounded-full border-2 border-yellow-400 animate-pulse-glow animate-spin-and-grow"
          style={{ textShadow: '0 0 15px rgba(252, 211, 77, 0.8)' }}
        >
            <span className="font-bold text-5xl text-yellow-400">
                {badgeText}
            </span>
        </div>
      </div>
      <audio ref={audioRef} src="/sounds/badge-reveal.mp3" preload="auto" />
    </div>
  );
}

    