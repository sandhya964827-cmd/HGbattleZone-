

"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { ArrowLeft, Menu, X, LogIn, LogOut, Home, BarChart3, Star, DollarSign, User, PlusCircle, Video, Image as ImageIcon, Award, LayoutGrid, Loader2, Coins, Settings, ShieldCheck } from "lucide-react";
import { useState, useEffect } from "react";

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Logo } from "@/components/icons";
import { useAuth } from "@/context/auth-context";
import { auth, signOut, onUserProfileUpdate } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import type { UserProfile as UserProfileType } from "@/app/profile/page";

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuGroup,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";



const navItems = [
  { href: "/", label: "Home", icon: Home },
  { href: "/results", label: "Leaderboard", icon: BarChart3 },
  { href: "/live", label: "Live", icon: Star },
  { href: "/profile", label: "Profile", icon: User },
];

const allAdminLinks = {
  addMatch: { href: "/add-match", label: "Add Match", icon: PlusCircle },
  addMatchMediam: { href: "/add-match-mediam", label: "Add Mediam Match", icon: PlusCircle },
  liveAdmin: { href: "/live-admin", label: "Live Admin", icon: Video },
  manageResults: { href: "/manage-results", label: "Manage Results", icon: Award },
  coinRequests: { href: "/admin/coin-requests", label: "Coin Requests", icon: Coins },
  manageBanners: { href: "/manage-banners", label: "Manage Banners", icon: ImageIcon },
  manageCategoryBanners: { href: "/manage-category-banners", label: "Category Banners", icon: LayoutGrid },
  manageScrimBanners: { href: "/manage-scrim-banners", label: "Scrim Banners", icon: LayoutGrid },
  registrationHistory: { href: "/earn", label: "Registration History", icon: User },
  settings: { href: "/admin/settings", label: "Global Settings", icon: Settings },
  featureControl: { href: "/admin/feature-control", label: "Feature Control", icon: ShieldCheck },
};


export default function Header() {
  const pathname = usePathname();
  const router = useRouter();
  const { isLoggedIn, logout, isAdmin, user } = useAuth();
  const { toast } = useToast();
  const [profile, setProfile] = useState<UserProfileType | null>(null);
  const [loadingProfile, setLoadingProfile] = useState(false);

  useEffect(() => {
    if (user) {
        setLoadingProfile(true);
        const unsubscribe = onUserProfileUpdate(user.uid, (userProfile) => {
            if (userProfile) {
                setProfile(userProfile as UserProfileType);
            }
            setLoadingProfile(false);
        });
        return () => unsubscribe();
    } else {
        setProfile(null);
    }
  }, [user]);
  
  // Don't show back button on main pages, only on sub-pages if needed.
  const showBackButton = !["/", "/login", "/signup"].includes(pathname);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      logout(); // This updates the context state
      router.push('/login');
      toast({
        title: "Logged Out",
        description: "You have been successfully logged out.",
      });
    } catch (error) {
      console.error("Logout Error:", error);
      toast({
        variant: "destructive",
        title: "Logout Failed",
        description: "An error occurred while logging out.",
      });
    }
  };

  const renderTopRightContent = () => {
    if (loadingProfile && isLoggedIn) {
      return (
        <Button variant="ghost" size="icon" disabled>
          <Loader2 className="animate-spin" />
        </Button>
      );
    }

    if (!isLoggedIn) {
       if (!["/login", "/signup"].includes(pathname)) {
        return (
          <>
            {/* Desktop Login */}
            <Button asChild variant="ghost" className="hidden md:flex">
                <Link href="/login">
                <LogIn className="mr-2"/>
                Login
                </Link>
            </Button>
            {/* Mobile Login */}
            <Button asChild variant="ghost" size="icon" className="flex md:hidden">
                <Link href="/login">
                    <LogIn />
                    <span className="sr-only">Login</span>
                </Link>
            </Button>
          </>
        );
      }
      return null;
    }
    
    // User is logged in, show coin balance and menu
    return (
        <div className="flex items-center gap-2">
            <Button asChild variant="outline" className="h-9 px-3">
              <Link href="/add-coins" className="flex items-center gap-2">
                  <Coins className="h-4 w-4 text-yellow-500" />
                  <span className="font-bold">{profile?.coins ?? 0}</span>
                  <PlusCircle className="h-4 w-4 text-green-500" />
              </Link>
            </Button>
            
            <DropdownMenu>
                <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                    <Menu />
                    <span className="sr-only">Open menu</span>
                    </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                    <DropdownMenuGroup>
                    <DropdownMenuLabel>Navigation</DropdownMenuLabel>
                    {navItems.map((item) => (
                        <DropdownMenuItem key={item.href} asChild>
                        <Link href={item.href} className={cn(pathname === item.href && "bg-accent")}>
                            <item.icon className="mr-2 h-4 w-4" />
                            {item.label}
                        </Link>
                        </DropdownMenuItem>
                    ))}
                    </DropdownMenuGroup>
                    
                    {isAdmin && profile?.badgeText && (
                        <>
                            <DropdownMenuSeparator />
                            <DropdownMenuGroup>
                                <DropdownMenuLabel>Admin</DropdownMenuLabel>
                                {profile?.badgeText === 'H' ? (
                                    <DropdownMenuItem asChild>
                                        <Link href="/admin/dashboard">
                                            <LayoutGrid className="mr-2 h-4 w-4" />
                                            Dashboard
                                        </Link>
                                    </DropdownMenuItem>
                                ) : (
                                    profile?.adminPermissions?.map(permissionKey => {
                                        const feature = allAdminLinks[permissionKey as keyof typeof allAdminLinks];
                                        if (!feature) return null;
                                        return (
                                            <DropdownMenuItem key={feature.href} asChild>
                                                <Link href={feature.href}>
                                                    <feature.icon className="mr-2 h-4 w-4" />
                                                    {feature.label}
                                                </Link>
                                            </DropdownMenuItem>
                                        );
                                    })
                                )}
                            </DropdownMenuGroup>
                        </>
                    )}

                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout}>
                        <LogOut className="mr-2 h-4 w-4" />
                        <span>Logout</span>
                    </DropdownMenuItem>
                </DropdownMenuContent>
            </DropdownMenu>
        </div>
    )
  }


  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center">
        <div className="mr-4 flex flex-1 items-center">
          {showBackButton && (
            <Button
              variant="ghost"
              size="icon"
              className="mr-2"
              onClick={() => router.back()}
            >
              <ArrowLeft />
              <span className="sr-only">Back</span>
            </Button>
          )}
          <Link href="/" className="flex items-center gap-2 font-bold font-headline">
            <Logo className="h-6 w-6 text-primary" />
            <span className="text-lg"><span className="text-primary">HG</span>BattleZone</span>
          </Link>
        </div>

        <div className="flex flex-1 items-center justify-end space-x-2">
            {renderTopRightContent()}
        </div>
      </div>
    </header>
  );
}

    