

"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, BarChart3, User, Star } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/auth-context";

const navItems = [
  { href: "/", label: "Home", icon: Home },
  { href: "/results", label: "Leaderboard", icon: BarChart3 },
  { href: "/live", label: "Live", icon: Star },
  { href: "/profile", label: "Profile", icon: User },
];

export default function BottomNav() {
  const pathname = usePathname();
  const { isLoggedIn } = useAuth();

  if (!isLoggedIn) {
    return null;
  }

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-secondary border-t border-border/50 h-16 flex md:hidden z-50">
      {navItems.map((item) => {
        const isActive = pathname === item.href;
        return (
          <Link
            key={item.href}
            href={item.href}
            className="flex-1 flex flex-col items-center justify-center text-xs gap-1 transition-colors group"
          >
            <div className={cn(
              "h-8 w-12 flex items-center justify-center rounded-full transition-all duration-300",
              isActive ? "bg-primary/10" : "group-hover:bg-primary/5"
            )}>
              <item.icon className={cn(
                  "h-5 w-5 transition-colors",
                  isActive ? "text-primary" : "text-muted-foreground group-hover:text-primary/80"
              )} />
            </div>
            <span className={cn(
              "transition-colors",
              isActive ? "text-primary font-bold" : "text-muted-foreground"
            )}>
              {item.label}
            </span>
          </Link>
        );
      })}
    </nav>
  );
}
