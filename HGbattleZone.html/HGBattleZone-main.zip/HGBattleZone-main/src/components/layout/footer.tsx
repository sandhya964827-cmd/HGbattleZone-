import Link from 'next/link';
import { Logo } from '@/components/icons';

const Footer = () => {
  return (
    <footer className="bg-card border-t hidden md:block">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center text-center md:text-left">
          <div className="flex items-center gap-2 mb-4 md:mb-0">
            <Logo className="h-6 w-6 text-primary" />
            <span className="font-headline font-bold text-lg"><span className="text-primary">HG</span>BattleZone</span>
          </div>
          <p className="text-sm text-muted-foreground mt-4 md:mt-0">
            &copy; {new Date().getFullYear()} HGBattleZone. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
