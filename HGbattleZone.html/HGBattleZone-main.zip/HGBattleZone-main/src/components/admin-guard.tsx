"use client";

import { useAuth } from '@/context/auth-context';
import { useRouter } from 'next/navigation';
import { Loader2, ShieldAlert } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import Link from 'next/link';

export default function AdminGuard({ children }: { children: React.ReactNode }) {
  const { isAdmin, loading: authLoading } = useAuth();
  const router = useRouter();

  if (authLoading) {
    // Show a loader while checking auth state
    return (
        <div className="flex items-center justify-center h-screen w-full">
            <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
    );
  }

  if (!isAdmin) {
    // If user is not an admin, show a permission denied message
    return (
      <div className="container mx-auto px-4 py-16 flex items-center justify-center">
        <Card className="max-w-md w-full text-center">
          <CardHeader>
            <CardTitle className="flex items-center justify-center gap-2 text-destructive">
                <ShieldAlert className="h-7 w-7"/>
                Permission Denied
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <CardDescription>
              You do not have permission to view this page. This area is restricted to administrators only.
            </CardDescription>
            <Button asChild>
                <Link href="/admin/dashboard">Go to Dashboard</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  // If user is an admin, render the page content
  return <>{children}</>;
}
