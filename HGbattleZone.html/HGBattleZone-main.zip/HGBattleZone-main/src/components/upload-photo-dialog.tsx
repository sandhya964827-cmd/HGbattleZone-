
"use client";

import { useState } from "react";
import { useAuth } from "@/context/auth-context";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, UploadCloud } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { uploadProfilePhoto } from "@/lib/firebase";
import { DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";

interface UploadPhotoDialogProps {
  onUploadSuccess: (newPhotoUrl: string) => void;
  onDialogClose: () => void;
}

export default function UploadPhotoDialog({ onUploadSuccess, onDialogClose }: UploadPhotoDialogProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(user?.photoURL || null);
  const [isLoading, setIsLoading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0] ?? null;
    if (selectedFile) {
      setFile(selectedFile);
      const localUrl = URL.createObjectURL(selectedFile);
      setPreviewUrl(localUrl);
    }
  };

  const handleUpload = async () => {
    if (!file || !user) {
      toast({
        variant: "destructive",
        title: "No file selected",
        description: "Please select a photo to upload.",
      });
      return;
    }

    // Optimistically update the UI on the profile page
    if (previewUrl) {
      onUploadSuccess(previewUrl);
    }

    setIsLoading(true);

    try {
      // The actual upload happens here
      const finalPhotoURL = await uploadProfilePhoto(file, user.uid);

      toast({
        title: "Profile Picture Updated!",
        description: "Your new photo has been saved.",
      });

      // Update with the final URL once upload is complete
      onUploadSuccess(finalPhotoURL);
      onDialogClose(); // Close the dialog on success

    } catch (error) {
      console.error("Photo upload failed:", error);
      toast({
        variant: "destructive",
        title: "Upload Failed",
        description: "There was an error uploading your photo. Please try again.",
      });
      // Revert the optimistic update on failure by re-fetching profile
      onUploadSuccess(user.photoURL || '');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
        <DialogHeader>
            <DialogTitle>Change Profile Picture</DialogTitle>
            <DialogDescription>
            Choose a new photo and click upload to save it.
            </DialogDescription>
        </DialogHeader>
        <div className="space-y-6 pt-6">
            <div className="flex justify-center">
                <Avatar className="h-32 w-32 border-4 border-primary">
                    <AvatarImage src={previewUrl || undefined} alt="Profile preview" />
                    <AvatarFallback className="text-4xl">{user?.displayName?.[0].toUpperCase() || user?.email?.[0].toUpperCase()}</AvatarFallback>
                </Avatar>
            </div>
            
            <Input type="file" accept="image/*" onChange={handleFileChange} disabled={isLoading} />
            
            <Button onClick={handleUpload} className="w-full" disabled={isLoading || !file}>
                {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UploadCloud className="mr-2 h-4 w-4"/>}
                {isLoading ? "Uploading..." : "Upload Photo"}
            </Button>
        </div>
    </div>
  );
}
