
"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm, useFieldArray } from "react-hook-form";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useEffect, useMemo, useState } from "react";
import type { TournamentRegistration, PlayerRegistration, Tournament } from "@/lib/types";
import { Separator } from "./ui/separator";
import type { UserProfile } from "@/app/profile/page";
import { findUserByTournamentRegId } from "@/lib/firebase";
import { Loader2, UserPlus, XCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Card } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";

const playerSchema = z.object({
  name: z.string().min(1, "Name is required."),
  gameName: z.string().min(1, "Game name is required."),
  gameUID: z.string().min(1, "Game UID is required."),
  username: z.string().optional(),
  mobileNumber: z.string().min(1, "Mobile number is required."),
  email: z.string().email("A valid email is required."),
  badgeText: z.string().optional().nullable(),
});

const formSchema = z.object({
  slotNumber: z.coerce.number().min(1, "Please select a slot."),
  squadName: z.string().min(3, "Squad name must be at least 3 characters."),
  mobileNumber: z.string().min(10, "Please enter a valid 10-digit mobile number.").max(10, "Please enter a valid 10-digit mobile number."),
  players: z.array(playerSchema),
});

type RegistrationFormData = z.infer<typeof formSchema>;

interface TournamentRegistrationFormProps {
  tournament: Tournament;
  onRegistrationSuccess: (values: Omit<TournamentRegistration, 'id' | 'tournamentId' | 'uid' | 'date'>) => void;
  initialData?: TournamentRegistration | null;
  userProfile?: UserProfile | null;
  registeredSlots: number[];
}

export default function TournamentRegistrationForm({ tournament, onRegistrationSuccess, initialData, userProfile, registeredSlots }: TournamentRegistrationFormProps) {
  const { toast } = useToast();
  const [isSearching, setIsSearching] = useState(false);
  const [searchId, setSearchId] = useState('');
  
  const requiredPlayerCount = useMemo(() => {
    switch (tournament.mode) {
      case 'Duo': return 2;
      case 'Squad': return 4;
      default: return 1;
    }
  }, [tournament.mode]);

  const availableSlots = useMemo(() => {
    return Array.from({ length: tournament.slots }, (_, i) => i + 1)
      .filter(slot => !registeredSlots.includes(slot));
  }, [tournament.slots, registeredSlots]);

  const form = useForm<RegistrationFormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      slotNumber: undefined,
      squadName: "",
      mobileNumber: "",
      players: [],
    },
  });

  const { fields, append, remove, replace } = useFieldArray({
    control: form.control,
    name: "players"
  });

  useEffect(() => {
    if (initialData) {
      form.reset({
        slotNumber: initialData.slotNumber,
        squadName: initialData.squadName,
        mobileNumber: initialData.mobileNumber,
      });
      replace(initialData.players);
    } else if (userProfile) {
        form.reset({
            slotNumber: undefined,
            squadName: `${userProfile.username}'s Squad`,
            mobileNumber: userProfile.mobileNumber,
            players: []
        });
    }
  }, [initialData, userProfile, form, replace]);

  const handleSearchAndAdd = async () => {
    if (!searchId) {
      toast({ variant: 'destructive', title: 'Error', description: 'Please enter a Tournament Registration ID.' });
      return;
    }
    if (fields.length >= requiredPlayerCount) {
       toast({ variant: 'destructive', title: 'Team Full', description: `You can only add ${requiredPlayerCount} player(s) for ${tournament.mode} mode.` });
       return;
    }

    // Check if player is already in the team by tournamentRegId
    const foundUserByRegId = await findUserByTournamentRegId(Number(searchId));
    if (foundUserByRegId && fields.some(p => p.username === foundUserByRegId.username)) {
        toast({ variant: 'destructive', title: 'Player Already Added', description: `${foundUserByRegId.username} is already on your team.` });
        return;
    }

    setIsSearching(true);
    try {
      if (foundUserByRegId) {
        append({
          name: `${foundUserByRegId.firstName} ${foundUserByRegId.lastName}`,
          gameName: foundUserByRegId.username || "",
          gameUID: "", // Let user fill this
          username: foundUserByRegId.username,
          mobileNumber: foundUserByRegId.mobileNumber,
          email: foundUserByRegId.email,
          badgeText: foundUserByRegId.badgeText || null,
        });
        toast({ title: 'Player Added', description: `${foundUserByRegId.username} has been added to your team.` });
        setSearchId(''); // Clear search input
      } else {
        toast({ variant: 'destructive', title: 'Not Found', description: 'No player found with that registration ID.' });
      }
    } catch (e) {
      console.error(e);
      toast({ variant: 'destructive', title: 'Error', description: 'An error occurred while searching.' });
    } finally {
      setIsSearching(false);
    }
  };

  function onSubmit(values: RegistrationFormData) {
    if (values.players.length !== requiredPlayerCount) {
        toast({
            variant: "destructive",
            title: "Incorrect Team Size",
            description: `You must have exactly ${requiredPlayerCount} player(s) for a ${tournament.mode} match.`
        });
        return;
    }
    onRegistrationSuccess(values);
    form.reset();
  }

  const isEditing = !!initialData;
  const canAddMorePlayers = fields.length < requiredPlayerCount;

  return (
    <div className="max-h-[70vh] overflow-y-auto p-1 pr-4">
        <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="space-y-4">
                    <FormField
                      control={form.control}
                      name="slotNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Select a Slot</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={String(field.value)} disabled={isEditing}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Choose an available slot" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {availableSlots.length > 0 ? availableSlots.map(slot => (
                                <SelectItem key={slot} value={String(slot)}>Slot {slot}</SelectItem>
                              )) : <div className="p-2 text-sm text-muted-foreground text-center">No slots available</div>}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                        control={form.control}
                        name="squadName"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Squad Name</FormLabel>
                            <FormControl>
                                <Input placeholder="Your squad's name" {...field} />
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={form.control}
                        name="mobileNumber"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Contact Mobile Number</FormLabel>
                            <FormControl>
                                <Input type="tel" placeholder="Main contact number" {...field} />
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                    />
                </div>
                
                <Separator/>

                {!isEditing && canAddMorePlayers && (
                    <div className="space-y-2">
                        <Label>Add Teammates</Label>
                        <div className="flex gap-2">
                            <Input 
                                placeholder="Enter Player's Tournament Reg ID" 
                                value={searchId}
                                onChange={(e) => setSearchId(e.target.value)}
                            />
                            <Button type="button" onClick={handleSearchAndAdd} disabled={isSearching}>
                                {isSearching ? <Loader2 className="h-4 w-4 animate-spin" /> : <UserPlus className="h-4 w-4" />}
                                <span className="ml-2 hidden sm:inline">Add</span>
                            </Button>
                        </div>
                        <p className="text-xs text-muted-foreground">You need to add {requiredPlayerCount - fields.length} more player(s) for a {tournament.mode} match.</p>
                    </div>
                )}
                
                <div className="space-y-4">
                     <h3 className="font-medium text-lg">Team Roster ({fields.length}/{requiredPlayerCount})</h3>
                    {fields.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">Your team is empty. Add players using the search bar above.</p>}
                    {fields.map((field, index) => (
                        <Card key={field.id} className="p-4">
                            <div className="flex justify-between items-start">
                                <div className="flex items-center gap-3 mb-4">
                                     <Avatar className="h-8 w-8">
                                        <AvatarImage src={(field as PlayerRegistration & {photoURL?: string}).photoURL} />
                                        <AvatarFallback>{(field.name || "P")[0].toUpperCase()}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <h4 className="font-semibold flex items-center gap-1.5">
                                            {field.name}
                                            {field.badgeText && (
                                                <div className="flex items-center justify-center h-4 w-4 bg-amber-950 rounded-full border border-amber-400">
                                                <span className="font-bold text-xs text-amber-400">{field.badgeText}</span>
                                                </div>
                                            )}
                                        </h4>
                                        <p className="text-xs text-muted-foreground">{field.username}</p>
                                    </div>
                                </div>
                                {!isEditing && (
                                    <Button type="button" variant="ghost" size="icon" className="text-destructive h-8 w-8" onClick={() => remove(index)}>
                                        <XCircle className="h-4 w-4" />
                                    </Button>
                                )}
                            </div>
                            <div className="space-y-4">
                                 <FormField
                                    control={form.control}
                                    name={`players.${index}.gameName`}
                                    render={({ field }) => (
                                        <FormItem>
                                        <FormLabel>Game Name</FormLabel>
                                        <FormControl>
                                            <Input placeholder="Player's in-game name" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name={`players.${index}.gameUID`}
                                    render={({ field }) => (
                                        <FormItem>
                                        <FormLabel>Game UID</FormLabel>
                                        <FormControl>
                                            <Input placeholder="Player's Free Fire UID" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name={`players.${index}.mobileNumber`}
                                    render={({ field }) => (
                                        <FormItem>
                                        <FormLabel>Mobile Number</FormLabel>
                                        <FormControl>
                                            <Input placeholder="Player's mobile number" {...field} disabled />
                                        </FormControl>
                                        <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name={`players.${index}.email`}
                                    render={({ field }) => (
                                        <FormItem>
                                        <FormLabel>Email</FormLabel>
                                        <FormControl>
                                            <Input placeholder="Player's email" {...field} disabled />
                                        </FormControl>
                                        <FormMessage />
                                        </FormItem>
                                    )}
                                />
                            </div>
                        </Card>
                    ))}
                </div>
                
                <Button type="submit" className="w-full" disabled={fields.length !== requiredPlayerCount}>
                    {isEditing ? 'Update Registration' : `Submit ${tournament.mode} Registration`}
                </Button>
            </form>
        </Form>
    </div>
  );
}

    