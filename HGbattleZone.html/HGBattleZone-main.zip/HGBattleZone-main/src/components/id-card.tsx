
"use client";

import { useRef } from 'react';
import { toPng } from 'html-to-image';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Download, Mars, Venus, PersonStanding } from 'lucide-react';
import type { UserProfile } from '@/app/profile/page';
import Image from 'next/image';
import { format } from 'date-fns';

interface IdCardProps {
    profile: UserProfile;
    isPublicView?: boolean; // New prop to control view
}

const GenderIcon = ({ gender }: { gender: 'Male' | 'Female' | 'Other' }) => {
    switch (gender) {
        case 'Male':
            return <Mars className="inline h-4 w-4 ml-2 text-blue-500" />;
        case 'Female':
            return <Venus className="inline h-4 w-4 ml-2 text-pink-500" />;
        default:
            return <PersonStanding className="inline h-4 w-4 ml-2 text-gray-500" />;
    }
};


export default function IdCard({ profile, isPublicView = false }: IdCardProps) {
    const idCardRef = useRef<HTMLDivElement>(null);

    const handleDownload = async () => {
        if (idCardRef.current === null) {
            return;
        }

        try {
            const dataUrl = await toPng(idCardRef.current, { cacheBust: true, quality: 1.0, pixelRatio: 2 });
            const link = document.createElement('a');
            link.download = `HGBattleZone_ID_Card_${profile.username}.png`;
            link.href = dataUrl;
            link.click();
        } catch (err) {
            console.error('Failed to download ID card image', err);
        }
    };

    // Construct the absolute URL for the QR code.
    const getAbsoluteUrl = (path: string) => {
      // This will only run on the client side, so window is available.
      if (typeof window !== 'undefined') {
        return `${window.location.origin}${path}`;
      }
      // Provide a fallback for SSR, though QR code generation is client-side.
      return path;
    }

    const publicIdCardUrl = getAbsoluteUrl(`/id-card/${profile.uid}`);
    const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=${encodeURIComponent(publicIdCardUrl)}`;

    const getCreationDate = () => {
        if (!profile.createdAt) return 'N/A';
        // Firestore timestamp objects have a toDate() method
        if (typeof (profile.createdAt as any).toDate === 'function') {
            return format((profile.createdAt as any).toDate(), 'dd MMM, yyyy');
        }
        // If it's already a Date object
        return format(new Date(profile.createdAt), 'dd MMM, yyyy');
    }

    return (
        <div className="mt-8">
            <div ref={idCardRef} className="bg-white text-black rounded-xl p-6 shadow-lg max-w-sm mx-auto font-sans relative overflow-hidden">
                
                {/* Header */}
                <div className="text-center border-b-2 border-gray-200 pb-4 mb-4">
                    <div className="flex justify-center items-center mb-2">
                        <div className="bg-red-500 rounded-full h-12 w-12 flex items-center justify-center">
                            <span className="text-white font-bold text-xl">HG</span>
                        </div>
                    </div>
                    <h2 className="text-2xl font-bold">
                        <span className="text-red-500">HG</span>
                        <span className="text-black">BattleZone</span>
                    </h2>
                    <p className="text-xs text-gray-500">Official Player ID Card</p>
                </div>

                <div className="flex justify-between items-center mb-4">
                    <div className="w-16">
                        <p className="font-bold text-lg">{profile.registrationNumber || 'N/A'}</p>
                        <p className="text-xs text-gray-500">Reg. No.</p>
                    </div>
                    <div className="flex-grow flex justify-center">
                        <Avatar className="h-24 w-24 border-4 border-gray-200 rounded-lg">
                            <AvatarImage src={profile.photoURL || undefined} alt={profile.username} className="rounded-md"/>
                            <AvatarFallback className="text-3xl bg-gray-300 text-gray-700 rounded-lg">{profile.username?.[0].toUpperCase()}</AvatarFallback>
                        </Avatar>
                    </div>
                    <div className="w-16"></div>
                </div>

                <div className="text-center mb-6">
                    <h3 className="text-xl font-bold">{profile.username}</h3>
                    <p className="text-sm text-gray-600">{profile.firstName} {profile.lastName}</p>
                </div>

                {/* Main details */}
                 <div className="w-full text-left space-y-2 text-sm mb-4">
                     <div className="grid grid-cols-3">
                        <span className="font-semibold text-gray-500 col-span-1">T-Reg ID:</span>
                        <span className="font-mono col-span-2 break-all">{profile.tournamentRegId}</span>
                    </div>
                    <div className="grid grid-cols-3">
                        <span className="font-semibold text-gray-500 col-span-1">UID:</span>
                        <span className="font-mono col-span-2 break-all">{profile.uid}</span>
                    </div>
                    <div className="grid grid-cols-3">
                        <span className="font-semibold text-gray-500 col-span-1">Issued:</span>
                        <span className="font-mono col-span-2">{getCreationDate()}</span>
                    </div>
                     <div className="grid grid-cols-3 items-center">
                        <span className="font-semibold text-gray-500 col-span-1">Gender:</span>
                        <span className="font-mono col-span-2 flex items-center">
                            {profile.gender}
                            <GenderIcon gender={profile.gender} />
                        </span>
                    </div>
                    <div className="grid grid-cols-3">
                        <span className="font-semibold text-gray-500 col-span-1">Mobile:</span>
                        <span className="font-mono col-span-2">{profile.mobileNumber}</span>
                    </div>
                </div>

                 {/* QR Code */}
                <div className="flex justify-center mt-4">
                    <Image
                        src={qrCodeUrl}
                        alt="Player QR Code"
                        width={100}
                        height={100}
                        data-ai-hint="qr code"
                    />
                </div>
            </div>
            
            {/* Hide download button on public view */}
            {!isPublicView && (
                <Button onClick={handleDownload} className="w-full max-w-sm mx-auto mt-4 flex justify-center">
                    <Download className="mr-2 h-4 w-4" />
                    Download ID Card
                </Button>
            )}
        </div>
    );
}
